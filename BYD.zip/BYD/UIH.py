"""
优化版Excel数据处理系统UI
基于文档1的功能进行修改
"""

import os
from tkinter import ttk, filedialog, messagebox, scrolledtext
import threading
import time
import tkinter as tk
from tkinter import simpledialog, messagebox
import sys

# 添加当前目录到路径
sys.path.append(os.path.dirname(os.path.abspath(__file__)))


# 按需导入函数，避免不必要的内存占用
def import_necessary_functions():
    """按需导入必要的函数"""
    try:
        # 导入文档1中的核心处理函数
        from ALL_H import (
            integrated_full_process,
            gongkuang,
            save_excel_range,
            load_excel_range,
            save_condition_col,
            # 移除不存在的函数
            # load_condition_col,
            # get_condition_col_from_input,
            display_full_results,
            save_mianya_results,
            # 添加文档1中实际存在的函数
            get_excel_range_from_input
        )
        return {
            'integrated_full_process': integrated_full_process,
            'gongkuang': gongkuang,
            'save_excel_range': save_excel_range,
            'load_excel_range': load_excel_range,
            'save_condition_col': save_condition_col,
            # 注释掉不存在的函数
            # 'load_condition_col': load_condition_col,
            # 'get_condition_col_from_input': get_condition_col_from_input,
            'get_excel_range_from_input': get_excel_range_from_input,
            'display_full_results': display_full_results,
            'save_mianya_results': save_mianya_results
        }
    except ImportError as e:
        print(f"导入错误: {e}")
        # 返回空字典而不是None，避免后续错误
        return {}


def main():
    """主函数 - 修改为适配集成环境"""
    print("启动系统...")

    # 延迟导入函数
    imported_funcs = import_necessary_functions()
    if not imported_funcs:
        messagebox.showerror("错误", "无法导入必要的函数库")
        return

    class ExcelDataProcessorUI:
        def __init__(self, root):
            self.root = root
            self.root.title("面压计算(H)")
            self.root.geometry("1000x800")

            # 设置你自己的图片作为程序图标
            self.set_custom_icon("7.ico")  # 替换为你的图片路径

            # 存储变量
            self.file_path = tk.StringVar()
            self.start_row = tk.StringVar(value="1")
            self.end_row = tk.StringVar(value="120")
            self.start_col = tk.StringVar(value="7")
            self.end_col = tk.StringVar(value="9")
            self.condition_col = tk.StringVar(value="1")  # 工况名称列

            # 角度数据变量 - 3组，每组3个角度
            self.angle_vars = []
            for i in range(9):  # 3组×3个角度=9个
                self.angle_vars.append(tk.StringVar(value="0.0"))

            # 设置默认角度值（文档1中的默认值）
            default_angles = [
                "35.937", "65.656", "114.694",  # 第一组
                "111.825", "100.987", "155.306",  # 第二组
                "62.991", "152.997", "89.939"  # 第三组
            ]
            for i, value in enumerate(default_angles):
                self.angle_vars[i].set(value)

            # 投影面值变量
            self.proj_a = tk.StringVar(value="100.0")
            self.proj_b = tk.StringVar(value="150.0")
            self.proj_c = tk.StringVar(value="200.0")

            # 输出文件路径
            self.output_file = tk.StringVar()

            # 处理状态
            self.processing = False
            self.current_result = None

            self.create_widgets()
            # 初始日志
            self.log("系统启动完成")

        def set_custom_icon(self, image_path):
            """设置自定义图片作为程序图标"""
            try:
                # 检查图片文件是否存在
                if not os.path.exists(image_path):
                    print(f"警告: 图片文件不存在: {image_path}")
                    return

                # 使用PIL库处理图片（支持多种格式）
                from PIL import Image, ImageTk

                # 打开并处理图片
                image = Image.open(image_path)

                # 调整图片大小
                icon_size = (32, 32)
                image = image.resize(icon_size, Image.Resampling.LANCZOS)

                # 转换为Tkinter可用的格式
                icon = ImageTk.PhotoImage(image)

                # 设置窗口图标
                self.root.iconphoto(True, icon)

                # 保存引用，防止被垃圾回收
                self.app_icon = icon

                print(f"成功设置自定义图标: {image_path}")

            except ImportError:
                # 如果PIL未安装，直接使用ICO文件
                print("PIL库未安装，尝试使用ICO文件")
                self.try_ico_icon()
            except Exception as e:
                print(f"设置自定义图标失败: {e}")

        def try_ico_icon(self):
            """尝试使用ICO图标"""
            try:
                ico_paths = ["7.ico", "app_icon.ico", "icon.ico"]
                for ico_path in ico_paths:
                    if os.path.exists(ico_path):
                        self.root.iconbitmap(ico_path)
                        print(f"使用ICO图标: {ico_path}")
                        return
            except Exception as e:
                print(f"设置ICO图标失败: {e}")

        def create_widgets(self):
            """创建界面组件"""
            # 主框架
            main_frame = ttk.Frame(self.root, padding="10")
            main_frame.pack(fill=tk.BOTH, expand=True)

            # 文件选择
            file_frame = ttk.LabelFrame(main_frame, text="1. 文件选择", padding="5")
            file_frame.pack(fill=tk.X, pady=5)

            file_subframe = ttk.Frame(file_frame)
            file_subframe.pack(fill=tk.X)

            ttk.Button(file_subframe, text="选择Excel文件",
                       command=self.select_file).pack(side=tk.LEFT, padx=5)
            ttk.Label(file_subframe, textvariable=self.file_path,
                      background="white", relief="sunken", width=80).pack(
                side=tk.LEFT, fill=tk.X, expand=True, padx=5)

            # 数据范围
            range_frame = ttk.LabelFrame(main_frame, text="2. 数据范围设置", padding="5")
            range_frame.pack(fill=tk.X, pady=5)

            range_subframe = ttk.Frame(range_frame)
            range_subframe.pack(fill=tk.X)

            # 行范围
            ttk.Label(range_subframe, text="起始行:").pack(side=tk.LEFT, padx=5)
            ttk.Entry(range_subframe, textvariable=self.start_row, width=8).pack(side=tk.LEFT, padx=2)
            ttk.Label(range_subframe, text="结束行:").pack(side=tk.LEFT, padx=5)
            ttk.Entry(range_subframe, textvariable=self.end_row, width=8).pack(side=tk.LEFT, padx=2)

            # 列范围
            ttk.Label(range_subframe, text="起始列:").pack(side=tk.LEFT, padx=(20, 5))
            ttk.Entry(range_subframe, textvariable=self.start_col, width=8).pack(side=tk.LEFT, padx=2)
            ttk.Label(range_subframe, text="结束列:").pack(side=tk.LEFT, padx=5)
            ttk.Entry(range_subframe, textvariable=self.end_col, width=8).pack(side=tk.LEFT, padx=2)

            # 工况名称列
            ttk.Label(range_subframe, text="工况名称列:").pack(side=tk.LEFT, padx=(20, 5))
            ttk.Entry(range_subframe, textvariable=self.condition_col, width=8).pack(side=tk.LEFT, padx=2)

            # 角度输入框架 - 修改角度名称
            angle_frame = ttk.LabelFrame(main_frame, text="3. 角度输入（轴向和径向方向角度）", padding="5")
            angle_frame.pack(fill=tk.X, pady=5)

            # 创建3组角度输入，修改组名和角度标签
            angle_groups = [
                ("轴向与方向角度", 0, ["与X方向的角度", "与Y方向的角度", "与Z方向的角度"]),
                ("径向1与方向角度", 3, ["与X方向的角度", "与Y方向的角度", "与Z方向的角度"]),
                ("径向2与方向角度", 6, ["与X方向的角度", "与Y方向的角度", "与Z方向的角度"])
            ]

            for group_name, start_idx, angle_labels in angle_groups:
                group_frame = ttk.LabelFrame(angle_frame, text=group_name, padding="5")
                group_frame.pack(fill=tk.X, pady=2)

                group_subframe = ttk.Frame(group_frame)
                group_subframe.pack(fill=tk.X)

                for i in range(3):
                    angle_idx = start_idx + i
                    ttk.Label(group_subframe, text=f"{angle_labels[i]}:").pack(side=tk.LEFT, padx=5)
                    ttk.Entry(group_subframe, textvariable=self.angle_vars[angle_idx], width=12).pack(side=tk.LEFT, padx=2)
                    if i < 2:  # 前两个角度后面加分隔符
                        ttk.Label(group_subframe, text="|").pack(side=tk.LEFT, padx=5)

            # 投影面值
            proj_frame = ttk.LabelFrame(main_frame, text="4. 投影面值设置", padding="5")
            proj_frame.pack(fill=tk.X, pady=5)

            proj_subframe = ttk.Frame(proj_frame)
            proj_subframe.pack(fill=tk.X)

            ttk.Label(proj_subframe, text="轴拉投影面 (a):").pack(side=tk.LEFT, padx=5)
            ttk.Entry(proj_subframe, textvariable=self.proj_a, width=10).pack(side=tk.LEFT, padx=2)

            ttk.Label(proj_subframe, text="轴压投影面 (b):").pack(side=tk.LEFT, padx=(20, 5))
            ttk.Entry(proj_subframe, textvariable=self.proj_b, width=10).pack(side=tk.LEFT, padx=2)

            ttk.Label(proj_subframe, text="径向投影面 (c):").pack(side=tk.LEFT, padx=(20, 5))
            ttk.Entry(proj_subframe, textvariable=self.proj_c, width=10).pack(side=tk.LEFT, padx=2)

            # 输出设置
            output_frame = ttk.LabelFrame(main_frame, text="5. 输出设置", padding="5")
            output_frame.pack(fill=tk.X, pady=5)

            output_subframe = ttk.Frame(output_frame)
            output_subframe.pack(fill=tk.X)

            ttk.Button(output_subframe, text="选择输出文件",
                       command=self.select_output_file).pack(side=tk.LEFT, padx=5)
            ttk.Label(output_subframe, textvariable=self.output_file,
                      background="white", relief="sunken").pack(
                side=tk.LEFT, fill=tk.X, expand=True, padx=5)

            # 控制按钮
            button_frame = ttk.Frame(main_frame)
            button_frame.pack(fill=tk.X, pady=10)

            self.process_button = ttk.Button(button_frame, text="开始处理",
                                             command=self.process_data)
            self.process_button.pack(side=tk.LEFT, padx=10)

            ttk.Button(button_frame, text="测试读取",
                       command=self.test_read).pack(side=tk.LEFT, padx=10)

            ttk.Button(button_frame, text="清除",
                       command=self.clear_inputs).pack(side=tk.LEFT, padx=10)

            ttk.Button(button_frame, text="退出",
                       command=self.root.quit).pack(side=tk.LEFT, padx=10)

            # 进度条
            progress_frame = ttk.Frame(main_frame)
            progress_frame.pack(fill=tk.X, pady=5)

            self.progress_label = ttk.Label(progress_frame, text="就绪")
            self.progress_label.pack(fill=tk.X)

            self.progress_bar = ttk.Progressbar(progress_frame, mode='determinate')
            self.progress_bar.pack(fill=tk.X, pady=2)

            # 笔记本（选项卡）
            notebook = ttk.Notebook(main_frame)
            notebook.pack(fill=tk.BOTH, expand=True, pady=5)

            # 日志标签页
            log_frame = ttk.Frame(notebook, padding="5")
            notebook.add(log_frame, text="处理日志")

            self.log_text = scrolledtext.ScrolledText(log_frame, wrap=tk.WORD, height=15)
            self.log_text.pack(fill=tk.BOTH, expand=True)

            # 结果标签页
            result_frame = ttk.Frame(notebook, padding="5")
            notebook.add(result_frame, text="计算结果")

            self.result_text = scrolledtext.ScrolledText(result_frame, wrap=tk.WORD, height=15)
            self.result_text.pack(fill=tk.BOTH, expand=True)

            # 初始日志
            self.log("系统启动完成")

        def select_file(self):
            """选择Excel文件"""
            file_path = filedialog.askopenfilename(
                title="选择Excel文件",
                filetypes=[("Excel files", "*.xlsx *.xls"), ("All files", "*.*")]
            )
            if file_path:
                self.file_path.set(file_path)
                base_name = os.path.splitext(file_path)[0]
                self.output_file.set(f"{base_name}_结果.xlsx")
                self.log(f"已选择文件: {file_path}")

        def select_output_file(self):
            """选择输出文件"""
            file_path = filedialog.asksaveasfilename(
                title="选择输出文件",
                defaultextension=".xlsx",
                filetypes=[("Excel files", "*.xlsx"), ("All files", "*.*")]
            )
            if file_path:
                self.output_file.set(file_path)
                self.log(f"输出文件设置为: {file_path}")

        def clear_inputs(self):
            """清除输入"""
            self.file_path.set("")
            self.start_row.set("1")
            self.end_row.set("120")
            self.start_col.set("7")
            self.end_col.set("9")
            self.condition_col.set("1")

            # 重置角度为默认值
            default_angles = [
                "35.937", "65.656", "114.694",
                "111.825", "100.987", "155.306",
                "62.991", "152.997", "89.939"
            ]
            for i, value in enumerate(default_angles):
                self.angle_vars[i].set(value)

            self.proj_a.set("100.0")
            self.proj_b.set("150.0")
            self.proj_c.set("200.0")
            self.output_file.set("")

            self.log_text.delete(1.0, tk.END)
            self.result_text.delete(1.0, tk.END)
            self.log("输入已清除")
            self.update_progress(0, "就绪")

        def log(self, message):
            """添加日志"""
            timestamp = time.strftime("%H:%M:%S")
            self.log_text.insert(tk.END, f"[{timestamp}] {message}\n")
            self.log_text.see(tk.END)
            self.root.update_idletasks()

        def update_progress(self, value, message):
            """更新进度"""
            self.progress_bar['value'] = value
            self.progress_label['text'] = message
            self.root.update_idletasks()

        def validate_inputs(self):
            """验证输入"""
            if not self.file_path.get():
                messagebox.showerror("错误", "请选择Excel文件")
                return False

            if not os.path.exists(self.file_path.get()):
                messagebox.showerror("错误", "文件不存在")
                return False

            try:
                start_r = int(self.start_row.get())
                end_r = int(self.end_row.get())
                start_c = int(self.start_col.get())
                end_c = int(self.end_col.get())
                condition_c = int(self.condition_col.get())

                if start_r <= 0 or end_r <= 0 or start_c <= 0 or end_c <= 0 or condition_c <= 0:
                    messagebox.showerror("错误", "行和列必须为正整数")
                    return False

                if start_r > end_r:
                    messagebox.showerror("错误", "起始行不能大于结束行")
                    return False

                if start_c > end_c:
                    messagebox.showerror("错误", "起始列不能大于结束列")
                    return False

            except ValueError:
                messagebox.showerror("错误", "行和列必须是整数")
                return False

            try:
                for i, var in enumerate(self.angle_vars):
                    angle_val = float(var.get())
                    if angle_val < 0 or angle_val > 180:
                        messagebox.showerror("错误", f"角度{i + 1}必须在0-180度之间")
                        return False

            except ValueError:
                messagebox.showerror("错误", "角度必须是数字")
                return False

            try:
                a = float(self.proj_a.get())
                b = float(self.proj_b.get())
                c = float(self.proj_c.get())

                if a <= 0 or b <= 0 or c <= 0:
                    messagebox.showerror("错误", "投影面值必须为正数")
                    return False

            except ValueError:
                messagebox.showerror("错误", "投影面值必须是数字")
                return False

            return True

        def test_read(self):
            """测试读取Excel数据"""
            if not self.file_path.get():
                messagebox.showerror("错误", "请先选择Excel文件")
                return

            try:
                start_r = int(self.start_row.get())
                end_r = int(self.end_row.get())
                start_c = int(self.start_col.get())
                end_c = int(self.end_col.get())

                self.log("开始测试读取Excel数据...")

                # 使用导入的函数进行测试读取
                data = imported_funcs['gongkuang'](
                    file_path=self.file_path.get(),
                    excel_range=(start_r, end_r, start_c, end_c),
                    condition_col=int(self.condition_col.get())
                )

                self.log(f"读取成功! 找到 {len(data)} 个工况")
                for i, name in enumerate(data):
                    self.log(f"  工况{i + 1}: {name}")

            except Exception as e:
                self.log(f"测试读取失败: {str(e)}")
                messagebox.showerror("错误", f"读取失败: {str(e)}")

        def process_data_thread(self):
            """处理数据的线程"""
            try:
                # 获取参数
                file_path = self.file_path.get()
                start_row = int(self.start_row.get())
                end_row = int(self.end_row.get())
                start_col = int(self.start_col.get())
                end_col = int(self.end_col.get())
                condition_col = int(self.condition_col.get())

                excel_range = (start_row, end_row, start_col, end_col)

                # 角度数据 - 分为三组
                angle_data = []
                for i in range(0, 9, 3):
                    group = [
                        float(self.angle_vars[i].get()),
                        float(self.angle_vars[i + 1].get()),
                        float(self.angle_vars[i + 2].get())
                    ]
                    angle_data.append(group)

                # 投影面值
                a = float(self.proj_a.get())
                b = float(self.proj_b.get())
                c = float(self.proj_c.get())
                projection_areas = (a, b, c)

                # 输出文件
                output_file = self.output_file.get()
                if not output_file:
                    base_name = os.path.splitext(file_path)[0]
                    output_file = f"{base_name}_结果.xlsx"
                    self.output_file.set(output_file)

                # 进度模拟
                steps = [
                    (10, "读取Excel数据..."),
                    (20, "验证数据格式..."),
                    (30, "计算角度余弦值..."),
                    (40, "执行分解计算..."),
                    (50, "执行求和计算..."),
                    (60, "计算径向数组..."),
                    (70, "计算面压值..."),
                    (80, "计算最大值..."),
                    (90, "生成结果表格..."),
                    (95, "保存Excel文件..."),
                    (100, "完成!")
                ]

                for progress, message in steps:
                    if not self.processing:
                        break
                    self.update_progress(progress, message)
                    self.log(message)
                    time.sleep(0.5)

                # 执行处理
                self.log("开始完整处理流程...")
                result = imported_funcs['integrated_full_process'](
                    file_path=file_path,
                    excel_range=excel_range,
                    angle_data=angle_data,
                    projection_areas=projection_areas,
                    output_file=output_file,
                    condition_col=condition_col
                )

                self.current_result = result
                self.log("处理完成!")

                # 在主线程显示结果
                self.root.after(0, self.show_results)
                self.root.after(0, lambda: self.process_complete(output_file))

            except Exception as e:
                error_msg = f"处理错误: {str(e)}"
                self.log(error_msg)
                self.root.after(0, lambda: self.process_error(error_msg))

        def show_results(self):
            """显示结果"""
            if not self.current_result:
                return

            self.result_text.delete(1.0, tk.END)

            result = self.current_result
            stats = result.get('statistics', {})

            # 显示基本信息
            self.result_text.insert(tk.END, "处理结果摘要\n")
            self.result_text.insert(tk.END, "=" * 50 + "\n\n")

            self.result_text.insert(tk.END, f"数据形状: {stats.get('excel_data_shape', '未知')}\n")
            self.result_text.insert(tk.END, f"计算成功率: {stats.get('success_rate', 0):.1f}%\n\n")

            # 最大值信息
            axial_max = result.get('axial_max', {})
            radial_max = result.get('radial_max', {})

            if axial_max:
                self.result_text.insert(tk.END, f"轴向最大值: {axial_max.get('value', 0):.6f}\n")
                self.result_text.insert(tk.END, f"轴向最大值位置: {axial_max.get('position', '未知')}\n\n")

            if radial_max:
                self.result_text.insert(tk.END, f"径向最大值: {radial_max.get('value', 0):.6f}\n")
                self.result_text.insert(tk.END, f"径向最大值位置: {radial_max.get('position', '未知')}\n\n")

            # 面压结果统计
            if 'axial_mianya' in result and 'radial_mianya' in result:
                axial_mianya = result['axial_mianya']
                radial_mianya = result['radial_mianya']

                if axial_mianya:
                    self.result_text.insert(tk.END, f"轴向面压最大值: {max(axial_mianya):.6f}\n")
                    self.result_text.insert(tk.END, f"轴向面压最小值: {min(axial_mianya):.6f}\n\n")

                if radial_mianya:
                    self.result_text.insert(tk.END, f"径向面压最大值: {max(radial_mianya):.6f}\n")
                    self.result_text.insert(tk.END, f"径向面压最小值: {min(radial_mianya):.6f}\n\n")

            # 文件路径
            saved_file = result.get('saved_file', '')
            if saved_file:
                self.result_text.insert(tk.END, f"结果文件: {saved_file}\n")

            self.result_text.see(tk.END)

        def process_complete(self, output_file):
            """处理完成"""
            self.processing = False
            self.process_button['state'] = 'normal'
            self.update_progress(100, "完成!")
            messagebox.showinfo("成功", f"处理完成!\n结果文件: {output_file}")

        def process_error(self, error_msg):
            """处理错误"""
            self.processing = False
            self.process_button['state'] = 'normal'
            self.update_progress(0, "错误")
            messagebox.showerror("错误", error_msg)

        def process_data(self):
            """开始处理"""
            if not self.validate_inputs():
                return

            if self.processing:
                return

            self.processing = True
            self.process_button['state'] = 'disabled'
            self.log_text.delete(1.0, tk.END)
            self.result_text.delete(1.0, tk.END)

            self.log("开始处理数据...")
            self.update_progress(0, "初始化...")

            # 保存配置（只保存存在的函数）
            try:
                excel_range = (
                    int(self.start_row.get()),
                    int(self.end_row.get()),
                    int(self.start_col.get()),
                    int(self.end_col.get())
                )
                if 'save_excel_range' in imported_funcs:
                    imported_funcs['save_excel_range'](excel_range)

                condition_col = int(self.condition_col.get())
                if 'save_condition_col' in imported_funcs:
                    imported_funcs['save_condition_col'](condition_col)

                self.log("配置已保存")
            except Exception as e:
                self.log(f"保存配置失败: {e}")

            # 启动处理线程
            thread = threading.Thread(target=self.process_data_thread)
            thread.daemon = True
            thread.start()

    # 创建Toplevel窗口（适配集成环境）
    win = tk.Toplevel()
    win.title("面压计算(H)")
    win.geometry("1000x800")

    # 创建应用实例
    app = ExcelDataProcessorUI(win)

    # 确保窗口显示和焦点
    win.focus_set()
    win.grab_set()  # 模态窗口，确保用户先处理此窗口

    # 等待窗口关闭
    win.wait_window(win)


if __name__ == "__main__":
    main()