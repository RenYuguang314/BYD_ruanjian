import pandas as pd
import math
from typing import List, Union, Optional, Tuple
import numpy as np


def read_excel_data(
        file_path: str,
        start_row: int,
        end_row: int,
        start_col: int,
        end_col: int,
        sheet_name: Union[str, int] = 0,
        header: Optional[int] = None
) -> List[List[Union[float, int, str]]]:
    """
    读取Excel文件中指定行和列范围的数据，按横向（先行后列）顺序读取

    注意：行和列编号都从1开始（符合Excel习惯）

    参数:
    ----------
    file_path : str
        Excel文件路径
    start_row : int
        起始行编号（从1开始）- 数据行起始位置
    end_row : int
        结束行编号（包含该行，从1开始）- 数据行结束位置
    start_col : int
        起始列编号（从1开始）
    end_col : int
        结束列编号（包含该列，从1开始）
    sheet_name : Union[str, int], default=0
        工作表名称或索引
    header : Optional[int], default=None
        表头行，None表示无表头

    返回:
    ----------
    List[List[Union[float, int, str]]]
        读取的数据列表，每个子列表代表一行的数据
    """
    try:
        # 读取整个工作表
        df = pd.read_excel(file_path, sheet_name=sheet_name, header=header)

        # 将Excel行列编号(1-based)转换为Python索引(0-based)
        start_row_idx = start_row - 1
        end_row_idx = end_row - 1
        start_col_idx = start_col - 1
        end_col_idx = end_col - 1

        # 验证行列范围是否有效
        if start_row_idx < 0 or end_row_idx >= len(df) or start_row_idx > end_row_idx:
            raise ValueError(f"行范围无效: start_row={start_row}, end_row={end_row}, 数据行数={len(df)}")

        if start_col_idx < 0 or end_col_idx >= len(df.columns) or start_col_idx > end_col_idx:
            raise ValueError(f"列范围无效: start_col={start_col}, end_col={end_col}, 数据列数={len(df.columns)}")

        # 计算需要读取的数据行（第3行、第6行、第9行等）
        data_rows = []
        current_row = start_row_idx

        # 找到第一个数据行（第3行或其后第一个3的倍数的行）
        while current_row <= end_row_idx:
            # 计算当前行相对于起始行的偏移量
            row_offset = current_row - start_row_idx + 1
            # 如果行号是3的倍数，则读取该行
            if row_offset % 3 == 0:
                data_rows.append(current_row)
            current_row += 1

        print(f"检测到 {len(data_rows)} 个数据行: {[r + 1 for r in data_rows]}")

        # 创建空列表来存储数据（按行存储）
        all_data = []

        # 横向读取：先遍历行，再遍历列
        for row_idx in data_rows:
            row_data = []

            # 遍历当前行的所有列
            for col in range(start_col_idx, end_col_idx + 1):
                value = df.iloc[row_idx, col]

                # 处理NaN值（空单元格）
                if pd.isna(value):
                    row_data.append(None)
                else:
                    row_data.append(value)

            all_data.append(row_data)

        print(f"读取的数据（按行存储）2222222222222222222: {all_data}")
        return all_data

    except FileNotFoundError:
        raise FileNotFoundError(f"文件未找到: {file_path}")
    except Exception as e:
        raise Exception(f"读取Excel文件时出错: {str(e)}")


def input_angles_batch() -> List[List[float]]:
    """
    批量输入角度信息（按组输入）

    返回:
    ----------
    List[List[float]]
        角度信息，格式为 [[角度1, 角度2, 角度3], [角度4, 角度5, 角度6], [角度7, 角度8, 角度9]]
    """
    print("=" * 50)
    print("批量角度输入系统")
    print("=" * 50)
    print("请按组输入角度值，每组3个角度")

    result = []

    for group_num in range(1, 4):
        while True:
            try:
                input_str = input(f"请输入第{group_num}组的3个角度值（用逗号分隔）: ").strip()

                values = input_str.split(',')

                if len(values) != 3:
                    print(f"错误：每组需要3个角度值，您输入了{len(values)}个")
                    continue

                # 转换为浮点数
                angles = []
                for value in values:
                    angle = float(value.strip())
                    angles.append(angle)

                result.append(angles)
                break

            except ValueError:
                print("输入格式错误，请确保输入的是数字，并用逗号分隔")
            except Exception as e:
                print(f"发生错误: {e}")

    print("\n输入的角度信息:")
    for i, group in enumerate(result):
        print(f"  第{i + 1}组: {group}")

    return result

def calculate_cosines_from_manual(manual_angles: List[List[float]] = None) -> List[List[float]]:
    """
    从手动指定的角度数据计算余弦值

    参数:
    ----------
    manual_angles : List[List[float]], optional
        手动指定的3x3角度数据

    返回:
    ----------
    List[List[float]]
        3x3格式的余弦值数据
    """
    if manual_angles is None:
        # 使用默认测试数据
        manual_angles = [
            [35.937, 65.656, 114.694],
            [111.825, 100.987, 155.306],
            [111.825, 100.987, 155.306]
        ]

    print("使用的手动角度数据:")
    for i, row in enumerate(manual_angles):
        print(f"  第{i + 1}行: {row}")

    cosine_data = []

    for row in manual_angles:
        cosine_row = []
        for angle in row:
            cosine_value = math.cos(math.radians(angle))
            cosine_row.append(cosine_value)
        cosine_data.append(cosine_row)

    return manual_angles, cosine_data


def convert_to_numeric(data_list: List[List]) -> List[List]:
    """
    将读取的数据转换为数值类型（如果可能）

    参数:
    ----------
    data_list : List[List]
        原始数据列表

    返回:
    ----------
    List[List]
        转换后的数据列表
    """
    converted_data = []

    for column in data_list:
        converted_column = []
        for value in column:
            if value is None:
                converted_column.append(None)
            else:
                # 尝试转换为数值
                try:
                    if isinstance(value, (int, float, np.integer, np.floating)):
                        converted_column.append(float(value))
                    else:
                        # 尝试从字符串转换
                        converted_column.append(float(str(value).replace(',', '')))
                except (ValueError, TypeError):
                    # 无法转换，保留原值
                    converted_column.append(value)
        converted_data.append(converted_column)

    return converted_data

def integrated_process(file_path: str,
                       excel_range: Tuple[int, int, int, int],
                       angle_data: List[List[float]] = None) -> dict:
    """
    集成流程函数：将文件读取、角度输入、余弦计算和分解计算整合到一个函数中

    参数:
    ----------
    file_path : str
        Excel文件路径
    excel_range : Tuple[int, int, int, int]
        Excel数据范围 (start_row, end_row, start_col, end_col)
    angle_data : List[List[float]], optional
        角度数据，如果为None则使用默认值

    返回:
    ----------
    dict
        包含所有结果和信息的字典
    """
    try:
        # 1. 读取Excel数据
        start_row, end_row, start_col, end_col = excel_range
        print("=" * 60)
        print("开始集成处理流程")
        print("=" * 60)

        print(f"1. 读取Excel数据: {file_path}")
        print(f"   范围: 行{start_row}-{end_row}, 列{start_col}-{end_col}")

        raw_excel_data = read_excel_data(
            file_path=file_path,
            start_row=start_row,
            end_row=end_row,
            start_col=start_col,
            end_col=end_col
        )

        # 转换为数值类型
        excel_data = convert_to_numeric(raw_excel_data)

        if not excel_data or len(excel_data) == 0:
            raise ValueError("Excel数据为空")

        print(f"   Excel数据形状: {len(excel_data)}列 × {len(excel_data[0]) if excel_data[0] else 0}行")

        # 2. 使用角度数据
        print("\n2. 使用角度数据")
        if angle_data is None:
            # 使用默认角度数据
            angle_data = [[35.937,65.656,114.694],
                          [111.825,100.987,155.306],
                          [62.991,152.997,89.939]]
            print("使用默认角度数据")
        else:
            print("使用传入的角度数据")

        # 3. 计算余弦值
        print("\n3. 计算余弦值")
        _, cosine_data = calculate_cosines_from_manual(angle_data)

        # 4. 执行分解计算
        print("\n4. 执行分解计算")
        result = fenjie_simplified(excel_data, cosine_data)

        return result

    except Exception as e:
        raise Exception(f"集成处理流程出错: {str(e)}")


def fenjie_simplified(excel_data: List[List[Union[float, int, str]]],
                      cosine_data: List[List[float]]) -> dict:
    """
    简化版分解函数：只需要Excel数据和余弦值数据

    参数:
    ----------
    excel_data : List[List[Union[float, int, str]]]
        从Excel读取的数据
    cosine_data : List[List[float]]
        余弦值数据，必须是3x3格式

    返回:
    ----------
    dict
        包含所有结果和信息的字典
    """
    try:
        # 验证余弦值数据是否为3x3格式
        if len(cosine_data) != 3 or any(len(row) != 3 for row in cosine_data):
            raise ValueError(
                f"余弦值数据必须是3x3格式，当前形状: {len(cosine_data)}x{len(cosine_data[0]) if cosine_data else 0}")

        # 验证Excel数据
        if not excel_data or len(excel_data) == 0:
            raise ValueError("Excel数据为空")

        print("余弦值数据:")
        for i, row in enumerate(cosine_data):
            print(f"  第{i + 1}行: {[f'{x:.6f}' for x in row]}")

        print("232423511531515151515151515155",excel_data)
        # 执行分解计算
        result_3d = []
        total_calculations = 0
        successful_calculations = 0

        for copy_idx in range(3):
            copy_result = []

            # 获取当前副本对应的余弦值行
            cosine_row = cosine_data[copy_idx]

            print(f"\n处理第{copy_idx + 1}个副本，使用余弦值行{cosine_row}")

            # 遍历Excel数据的每一列
            for col_idx, column in enumerate(excel_data):
                multiplied_column = []

                # 遍历列中的每个元素
                for row_idx, value in enumerate(column):
                    total_calculations += 1

                    # 处理None值
                    if value is None:
                        multiplied_column.append(None)
                        continue

                    try:
                        # 转换为数值
                        if isinstance(value, (int, float, np.integer, np.floating)):
                            numeric_value = float(value)
                        else:
                            numeric_value = float(str(value).replace(',', ''))

                        # 使用对应位置的角度余弦值相乘
                        angle_idx = row_idx % len(cosine_row)  # 循环使用角度值
                        result_value = numeric_value * cosine_row[angle_idx]
                        multiplied_column.append(result_value)
                        successful_calculations += 1

                    except (ValueError, TypeError) as e:
                        print(f"  警告: 第{col_idx + 1}列第{row_idx + 1}行数据转换失败: {value}")
                        multiplied_column.append(None)

                copy_result.append(multiplied_column)

            result_3d.append(copy_result)

        # 统计信息
        stats = {
            'excel_data_shape': f"{len(excel_data)}列×{len(excel_data[0]) if excel_data[0] else 0}行",
            'cosine_data_shape': f"{len(cosine_data)}行×{len(cosine_data[0])}列",
            'result_shape': f"{len(result_3d)}副本×{len(result_3d[0])}列×{len(result_3d[0][0]) if result_3d[0] else 0}行",
            'total_calculations': total_calculations,
            'successful_calculations': successful_calculations,
            'success_rate': successful_calculations / total_calculations * 100 if total_calculations > 0 else 0
        }
        print("88888888888888888888888888888888",result_3d)
        return {
            'excel_data': excel_data,
            'cosine_data': cosine_data,
            'result_3d': result_3d,
            'statistics': stats
        }

    except Exception as e:
        raise Exception(f"简化版分解计算时出错: {str(e)}")


def display_integrated_results(result_dict: dict, show_details: bool = False):
    """
    显示集成处理结果

    参数:
    ----------
    result_dict : dict
        integrated_process函数的返回结果
    show_details : bool
        是否显示详细结果
    """
    excel_data = result_dict['excel_data']
    cosine_data = result_dict['cosine_data']
    result_3d = result_dict['result_3d']
    stats = result_dict['statistics']

    print("\n" + "=" * 100)
    print("集成处理结果")
    print("=" * 100)

    print(f"Excel数据形状: {stats['excel_data_shape']}")
    print(f"余弦值数据形状: {stats['cosine_data_shape']}")
    print(f"结果数据形状: {stats['result_shape']}")
    print(f"计算成功率: {stats['successful_calculations']}/{stats['total_calculations']} "
          f"({stats['success_rate']:.1f}%)")

    # 显示每个副本的结果摘要
    for copy_idx, copy_data in enumerate(result_3d):
        print(f"\n第{copy_idx + 1}个副本结果:")
        print("-" * 80)

        # 显示前3列的前5行
        for col_idx in range(min(3, len(copy_data))):
            preview_values = [f'{x:.6f}' if x is not None else 'None' for x in copy_data[col_idx][:5]]
            print(f"  第{col_idx + 1}列前5个值: {preview_values}")

        if show_details:
            print(f"  详细数据:")
            for col_idx, col_data in enumerate(copy_data):
                print(f"    第{col_idx + 1}列: {[f'{x:.6f}' if x is not None else 'None' for x in col_data]}")


def save_integrated_results(result_dict: dict, filename: str = "integrated_results.txt"):
    """
    保存集成处理结果到文件
    """
    with open(filename, 'w', encoding='utf-8') as f:
        f.write("集成处理结果\n")
        f.write("=" * 50 + "\n\n")

        f.write("数据信息:\n")
        f.write(f"  Excel数据形状: {result_dict['statistics']['excel_data_shape']}\n")
        f.write(f"  余弦值数据形状: {result_dict['statistics']['cosine_data_shape']}\n")
        f.write(f"  计算成功率: {result_dict['statistics']['success_rate']:.1f}%\n\n")

        f.write("余弦值数据:\n")
        for i, row in enumerate(result_dict['cosine_data']):
            f.write(f"  第{i + 1}行: {[f'{x:.6f}' for x in row]}\n")

        f.write("\n分解结果:\n")
        for copy_idx, copy_data in enumerate(result_dict['result_3d']):
            f.write(f"\n第{copy_idx + 1}个副本:\n")
            for col_idx, col_data in enumerate(copy_data):
                f.write(f"  第{col_idx + 1}列: {[f'{x:.6f}' if x is not None else 'None' for x in col_data]}\n")


def sum_fenjie_result(result_3d: List[List[List[float]]]) -> List[List[float]]:
    """
    对分解函数的结果进行求和

    参数:
    ----------
    result_3d : List[List[List[float]]]
        分解函数返回的三维数组，格式为 [[[],[],[]],[[],[],[]],[[],[],[]]]

    返回:
    ----------
    List[List[float]]
        求和后的二维数组，格式为 [[副本1的列和], [副本2的列和], [副本3的列和]]
    """
    try:
        # 验证输入数据
        if not result_3d or len(result_3d) == 0:
            raise ValueError("输入的三维数组为空")

        print("开始对分解结果进行求和计算")
        print(
            f"输入数据形状: {len(result_3d)}副本 × {len(result_3d[0])}列 × {len(result_3d[0][0]) if result_3d[0] else 0}行")

        # 创建结果数组
        sum_result = []

        # 遍历每个副本
        for copy_idx, copy_data in enumerate(result_3d):
            copy_sum = []

            print(f"\n处理第{copy_idx + 1}个副本:")

            # 遍历副本中的每一列
            for col_idx, column in enumerate(copy_data):
                # 对当前列的所有元素求和
                column_sum = 0.0
                valid_count = 0

                for value in column:
                    if value is not None:
                        try:
                            column_sum += float(value)
                            valid_count += 1
                        except (ValueError, TypeError):
                            # 无法转换为数值，跳过
                            pass

                copy_sum.append(column_sum)
                print(f"  第{col_idx + 1}列: 求和 = {column_sum:.6f} (有效值: {valid_count}/{len(column)})")

            sum_result.append(copy_sum)

        print(f"\n求和结果形状: {len(sum_result)}副本 × {len(sum_result[0])}列")
        return sum_result

    except Exception as e:
        raise Exception(f"求和计算时出错: {str(e)}")


def integrated_sum_process(file_path: str,
                           excel_range: Tuple[int, int, int, int],
                           angle_data: List[List[float]] = None) -> dict:
    """
    集成求和处理流程：包含文件读取、角度输入、余弦计算、分解计算和求和计算

    参数:
    ----------
    file_path : str
        Excel文件路径
    excel_range : Tuple[int, int, int, int]
        Excel数据范围 (start_row, end_row, start_col, end_col)
    angle_data : List[List[float]], optional
        角度数据，如果为None则使用默认值

    返回:
    ----------
    dict
        包含所有结果和信息的字典
    """
    try:
        # 1. 执行集成处理流程
        print("=" * 60)
        print("开始集成求和处理流程")
        print("=" * 60)

        # 修改这里：传递 angle_data 参数
        fenjie_result = integrated_process(file_path, excel_range, angle_data)

        # 2. 对分解结果进行求和
        print("\n" + "=" * 60)
        print("执行求和计算")
        print("=" * 60)

        sum_result = sum_fenjie_result(fenjie_result['result_3d'])

        # 3. 将求和结果添加到原字典中
        fenjie_result['sum_result'] = sum_result

        # 4. 添加求和统计信息
        fenjie_result['statistics']['sum_shape'] = f"{len(sum_result)}副本×{len(sum_result[0]) if sum_result else 0}列"

        # 计算总和统计
        total_sum = 0.0
        for copy_sum in sum_result:
            for col_sum in copy_sum:
                total_sum += col_sum

        fenjie_result['statistics']['total_sum'] = total_sum
        fenjie_result['statistics']['average_sum_per_column'] = total_sum / (
                    len(sum_result) * len(sum_result[0])) if sum_result and len(sum_result[0]) > 0 else 0

        return fenjie_result

    except Exception as e:
        raise Exception(f"集成求和处理流程出错: {str(e)}")


def display_sum_results(result_dict: dict, show_details: bool = False):
    """
    显示求和结果

    参数:
    ----------
    result_dict : dict
        integrated_sum_process函数的返回结果
    show_details : bool
        是否显示详细结果
    """
    if 'sum_result' not in result_dict:
        print("错误: 结果字典中不包含求和结果")
        return

    sum_result = result_dict['sum_result']
    stats = result_dict['statistics']

    print("\n" + "=" * 100)
    print("求和计算结果")
    print("=" * 100)

    print(f"求和结果形状: {stats['sum_shape']}")
    print(f"总和: {stats['total_sum']:.6f}")
    print(f"每列平均值: {stats['average_sum_per_column']:.6f}")

    # 显示每个副本的求和结果
    for copy_idx, copy_sum in enumerate(sum_result):
        print(f"\n第{copy_idx + 1}个副本的列和:")
        print("-" * 50)

        for col_idx, col_sum in enumerate(copy_sum):
            print(f"  第{col_idx + 1}列: {col_sum:.6f}")

        # 计算副本总和
        copy_total = sum(copy_sum)
        print(f"  副本{copy_idx + 1}总和: {copy_total:.6f}")

    if show_details:
        # 显示原始分解结果
        print(f"\n原始分解结果:")
        result_3d = result_dict['result_3d']
        for copy_idx, copy_data in enumerate(result_3d):
            print(f"\n第{copy_idx + 1}个副本原始数据:")
            for col_idx, col_data in enumerate(copy_data):
                preview_values = [f'{x:.6f}' if x is not None else 'None' for x in col_data[:5]]
                print(f"  第{col_idx + 1}列前5个值: {preview_values}")


def save_sum_results(result_dict: dict, filename: str = "sum_results.txt"):
    """
    保存求和结果到文件
    """
    if 'sum_result' not in result_dict:
        print("错误: 结果字典中不包含求和结果")
        return

    with open(filename, 'w', encoding='utf-8') as f:
        f.write("求和计算结果\n")
        f.write("=" * 50 + "\n\n")

        f.write("统计信息:\n")
        f.write(f"  求和结果形状: {result_dict['statistics']['sum_shape']}\n")
        f.write(f"  总和: {result_dict['statistics']['total_sum']:.6f}\n")
        f.write(f"  每列平均值: {result_dict['statistics']['average_sum_per_column']:.6f}\n\n")

        f.write("各副本列和:\n")
        for copy_idx, copy_sum in enumerate(result_dict['sum_result']):
            f.write(f"\n第{copy_idx + 1}个副本:\n")
            for col_idx, col_sum in enumerate(copy_sum):
                f.write(f"  第{col_idx + 1}列: {col_sum:.6f}\n")
            copy_total = sum(copy_sum)
            f.write(f"  副本总和: {copy_total:.6f}\n")

        f.write("\n原始分解结果摘要:\n")
        result_3d = result_dict['result_3d']
        for copy_idx, copy_data in enumerate(result_3d):
            f.write(f"\n第{copy_idx + 1}个副本原始数据:\n")
            for col_idx, col_data in enumerate(copy_data):
                preview_values = [f'{x:.6f}' if x is not None else 'None' for x in col_data[:3]]
                f.write(f"  第{col_idx + 1}列前3个值: {preview_values}\n")


def calculate_radial_array(sum_result: List[List[float]]) -> List[List[float]]:
    """
    计算径向数组：对索引1和索引2的数组进行平方和开根号计算

    参数:
    ----------
    sum_result : List[List[float]]
        求和函数返回的二维数组，格式为 [[副本1的列和], [副本2的列和], [副本3的列和]]

    返回:
    ----------
    List[List[float]]
        计算后的二维数组，格式为 [[副本1的列和], [径向数组]]
    """
    try:
        # 验证输入数据
        if not sum_result or len(sum_result) != 3:
            raise ValueError("求和结果必须包含3个副本的数据")

        print("开始计算径向数组")
        print(f"输入数据形状: {len(sum_result)}副本 × {len(sum_result[0])}列")

        # 提取副本2和副本3的数据（索引1和2）
        copy_1_data = sum_result[1]  # 索引1
        copy_2_data = sum_result[2]  # 索引2

        # 验证数组长度一致
        if len(copy_1_data) != len(copy_2_data):
            raise ValueError(f"副本2和副本3的列数不一致: {len(copy_1_data)} vs {len(copy_2_data)}")

        # 计算平方和开根号
        radial_array = []
        for i in range(len(copy_1_data)):
            value1 = copy_1_data[i]
            value2 = copy_2_data[i]
            # 计算平方和开根号: sqrt(value1^2 + value2^2)
            radial_value = math.sqrt(value1 ** 2 + value2 ** 2)
            radial_array.append(radial_value)

        print(f"副本2数据: {copy_1_data}")
        print(f"副本3数据: {copy_2_data}")
        print(f"径向计算数组: {[f'{x:.6f}' for x in radial_array]}")

        # 返回结果：副本1的数据和径向数组
        result = [sum_result[0], radial_array]
        print(f"径向数组结果形状: {len(result)}数组 × {len(result[0])}列")
        print("111111111111111111",result)
        return result

    except Exception as e:
        raise Exception(f"计算径向数组时出错: {str(e)}")


def calculate_axial_radial_max(radial_result: List[List[float]]) -> dict:
    """
    计算轴向和径向最大值

    参数:
    ----------
    radial_result : List[List[float]]
        径向数组计算结果，格式为 [[副本1的列和], [径向数组]]

    返回:
    ----------
    dict
        包含轴向和径向最大值的字典
    """
    try:
        # 验证输入数据
        if not radial_result or len(radial_result) != 2:
            raise ValueError("径向数组结果必须包含2个数组")

        print("开始计算轴向和径向最大值")
        print(f"输入数据形状: {len(radial_result)}数组 × {len(radial_result[0])}列")

        # 提取数据
        axial_data = radial_result[0]  # 轴向数据（副本1）
        radial_data = radial_result[1]  # 径向数据

        # 1. 计算轴向最大值（索引0的数组）
        axial_max = max(axial_data) if axial_data else 0.0
        axial_max_index = axial_data.index(axial_max) if axial_max in axial_data else -1

        print(f"\n轴向数据（索引0）: {axial_data}")
        print(f"轴向最大值: {axial_max:.6f} (位置: 第{axial_max_index + 1}列)")

        # 2. 计算径向最大值（索引1的数组）
        radial_max = max(radial_data) if radial_data else 0.0
        radial_max_index = radial_data.index(radial_max) if radial_max in radial_data else -1

        print(f"径向数据（索引1）: {radial_data}")
        print(f"径向最大值: {radial_max:.6f} (位置: 第{radial_max_index + 1}列)")

        # 返回结果
        return {
            'axial_max': {
                'value': axial_max,
                'index': axial_max_index,
                'position': f"第{axial_max_index + 1}列",
                'description': '轴向最大'
            },
            'radial_max': {
                'value': radial_max,
                'index': radial_max_index,
                'position': f"第{radial_max_index + 1}列",
                'description': '径向最大'
            },
            'axial_data': axial_data,
            'radial_data': radial_data,
            'max_values': [axial_max, radial_max]  # 返回轴向和径向最大值的列表
        }

    except Exception as e:
        raise Exception(f"计算轴向和径向最大值时出错: {str(e)}")


def integrated_axial_radial_process(file_path: str,
                                    excel_range: Tuple[int, int, int, int],
                                    angle_data: List[List[float]] = None) -> dict:
    """
    集成轴向径向处理流程：包含文件读取、角度输入、余弦计算、分解计算、求和计算、径向数组计算和最大值计算

    参数:
    ----------
    file_path : str
        Excel文件路径
    excel_range : Tuple[int, int, int, int]
        Excel数据范围 (start_row, end_row, start_col, end_col)
    angle_data : List[List[float]], optional
        角度数据，如果为None则使用默认值

    返回:
    ----------
    dict
        包含所有结果和信息的字典
    """
    try:
        # 1. 执行集成求和处理流程
        print("=" * 60)
        print("开始集成轴向径向处理流程")
        print("=" * 60)

        # 执行集成求和处理
        sum_result_dict = integrated_sum_process(file_path, excel_range, angle_data)

        # 2. 计算径向数组
        print("\n" + "=" * 60)
        print("执行径向数组计算")
        print("=" * 60)

        radial_array_result = calculate_radial_array(sum_result_dict['sum_result'])

        # 3. 计算轴向和径向最大值
        print("\n" + "=" * 60)
        print("执行轴向径向最大值计算")
        print("=" * 60)

        max_values_result = calculate_axial_radial_max(radial_array_result)

        # 4. 合并结果
        final_result = {**sum_result_dict, **max_values_result}

        # 5. 添加最大值统计信息
        final_result['statistics']['axial_max'] = final_result['axial_max']['value']
        final_result['statistics']['radial_max'] = final_result['radial_max']['value']
        final_result['statistics']['max_values'] = final_result['max_values']

        return final_result

    except Exception as e:
        raise Exception(f"集成轴向径向处理流程出错: {str(e)}")


def display_axial_radial_results(result_dict: dict, show_details: bool = False):
    """
    显示轴向径向计算结果

    参数:
    ----------
    result_dict : dict
        integrated_axial_radial_process函数的返回结果
    show_details : bool
        是否显示详细结果
    """
    if 'axial_max' not in result_dict or 'radial_max' not in result_dict:
        print("错误: 结果字典中不包含轴向径向计算结果")
        return

    axial_max = result_dict['axial_max']
    radial_max = result_dict['radial_max']
    axial_data = result_dict['axial_data']
    radial_data = result_dict['radial_data']
    max_values = result_dict['max_values']

    print("\n" + "=" * 100)
    print("轴向径向计算结果")
    print("=" * 100)

    # 显示轴向最大值
    print(f"\n轴向最大值 ({axial_max['description']}):")
    print(f"  值: {axial_max['value']:.6f}")
    print(f"  位置: {axial_max['position']} (索引: {axial_max['index']})")

    # 显示径向最大值
    print(f"\n径向最大值 ({radial_max['description']}):")
    print(f"  值: {radial_max['value']:.6f}")
    print(f"  位置: {radial_max['position']} (索引: {radial_max['index']})")

    # 显示最大值列表
    print(f"\n最大值列表: {[f'{x:.6f}' for x in max_values]}")

    # 显示轴向数据和径向数据
    print(f"\n轴向数据 (副本1列和): {[f'{x:.6f}' for x in axial_data]}")
    print(f"径向数据 (副本2和副本3的平方和开根号): {[f'{x:.6f}' for x in radial_data]}")

    if show_details:
        # 显示详细的求和结果
        print(f"\n详细的求和结果:")
        sum_result = result_dict['sum_result']
        for copy_idx, copy_sum in enumerate(sum_result):
            print(f"\n副本{copy_idx + 1}的列和:")
            for col_idx, col_sum in enumerate(copy_sum):
                print(f"  第{col_idx + 1}列: {col_sum:.6f}")


def save_axial_radial_results(result_dict: dict, filename: str = "axial_radial_results.txt"):
    """
    保存轴向径向计算结果到文件
    """
    if 'axial_max' not in result_dict or 'radial_max' not in result_dict:
        print("错误: 结果字典中不包含轴向径向计算结果")
        return

    with open(filename, 'w', encoding='utf-8') as f:
        f.write("轴向径向计算结果\n")
        f.write("=" * 50 + "\n\n")

        f.write("最大值统计:\n")
        f.write(f"  轴向最大值: {result_dict['axial_max']['value']:.6f} ({result_dict['axial_max']['position']})\n")
        f.write(f"  径向最大值: {result_dict['radial_max']['value']:.6f} ({result_dict['radial_max']['position']})\n")
        f.write(f"  最大值列表: {[f'{x:.6f}' for x in result_dict['max_values']]}\n\n")

        f.write("轴向数据 (副本1列和):\n")
        for i, value in enumerate(result_dict['axial_data']):
            f.write(f"  第{i + 1}列: {value:.6f}\n")

        f.write("\n径向数据 (副本2和副本3的平方和开根号):\n")
        for i, value in enumerate(result_dict['radial_data']):
            f.write(f"  第{i + 1}列: {value:.6f}\n")

        f.write("\n各副本列和:\n")
        for copy_idx, copy_sum in enumerate(result_dict['sum_result']):
            f.write(f"\n副本{copy_idx + 1}:\n")
            for col_idx, col_sum in enumerate(copy_sum):
                f.write(f"  第{col_idx + 1}列: {col_sum:.6f}\n")

        f.write("\n原始分解结果摘要:\n")
        result_3d = result_dict['result_3d']
        for copy_idx, copy_data in enumerate(result_3d):
            f.write(f"\n副本{copy_idx + 1}原始数据:\n")
            for col_idx, col_data in enumerate(copy_data):
                preview_values = [f'{x:.6f}' if x is not None else 'None' for x in col_data[:3]]
                f.write(f"  第{col_idx + 1}列前3个值: {preview_values}\n")


def input_projection_areas() -> tuple:
    """
    输入三个投影面值：轴拉投影面、轴压投影面、径向投影面

    返回:
    ----------
    tuple
        包含三个投影面值的元组 (a, b, c)
    """
    print("=" * 60)
    print("投影面值输入系统")
    print("=" * 60)
    print("请输入三个投影面值：")
    print("  a: 轴拉投影面")
    print("  b: 轴压投影面")
    print("  c: 径向投影面")

    while True:
        try:
            a = float(input("请输入轴拉投影面 (a): ").strip())
            b = float(input("请输入轴压投影面 (b): ").strip())
            c = float(input("请输入径向投影面 (c): ").strip())

            # 验证输入值是否为正数
            if a <= 0 or b <= 0 or c <= 0:
                print("错误：投影面值必须为正数，请重新输入")
                continue

            print(f"\n输入的投影面值:")
            print(f"  轴拉投影面 (a): {a}")
            print(f"  轴压投影面 (b): {b}")
            print(f"  径向投影面 (c): {c}")

            return a, b, c

        except ValueError:
            print("输入格式错误，请确保输入的是数字")
        except Exception as e:
            print(f"发生错误: {e}")


def calculate_mianya(radial_array_result: List[List[float]],
                     a: float, b: float, c: float) -> dict:
    """
    计算面压值

    参数:
    ----------
    radial_array_result : List[List[float]]
        calculate_radial_array函数的返回结果，格式为 [[轴向数据], [径向数据]]
    a : float
        轴拉投影面
    b : float
        轴压投影面
    c : float
        径向投影面

    返回:
    ----------
    dict
        包含面压计算结果的字典
    """
    try:
        # 验证输入数据
        if not radial_array_result or len(radial_array_result) != 2:
            raise ValueError("径向数组结果必须包含2个数组")

        print("=" * 60)
        print("开始面压计算")
        print("=" * 60)

        print(f"投影面值: a={a}, b={b}, c={c}")
        print(f"输入数据形状: {len(radial_array_result)}数组 × {len(radial_array_result[0])}列")

        # 提取数据
        axial_data = radial_array_result[0]  # 索引0：轴向数据
        radial_data = radial_array_result[1]  # 索引1：径向数据

        print(f"轴向数据: {axial_data}")
        print(f"径向数据: {radial_data}")

        # 1. 计算轴向面压
        axial_mianya = []
        axial_positive_count = 0
        axial_negative_count = 0

        print("\n计算轴向面压:")
        for i, value in enumerate(axial_data):
            if value > 0:
                # 正值：除以轴拉投影面 (a)
                result = value / a
                axial_mianya.append(result)
                axial_positive_count += 1
                print(f"  第{i + 1}列: {value} > 0, 除以a={a}, 结果={result:.6f}")
            elif value < 0:
                # 负值：除以轴压投影面 (b)
                result = value / b
                axial_mianya.append(result)
                axial_negative_count += 1
                print(f"  第{i + 1}列: {value} < 0, 除以b={b}, 结果={result:.6f}")
            else:
                # 零值：保持不变
                axial_mianya.append(0.0)
                print(f"  第{i + 1}列: {value} = 0, 保持不变, 结果=0.000000")

        # 2. 计算径向面压
        radial_mianya = []
        radial_count = 0

        print("\n计算径向面压:")
        for i, value in enumerate(radial_data):
            # 径向数据：不管正负都除以径向投影面 (c)
            result = value / c
            radial_mianya.append(result)
            radial_count += 1
            print(f"  第{i + 1}列: {value} / c={c}, 结果={result:.6f}")

        # 3. 统计信息
        stats = {
            'axial_positive_count': axial_positive_count,
            'axial_negative_count': axial_negative_count,
            'axial_zero_count': len(axial_data) - axial_positive_count - axial_negative_count,
            'radial_count': radial_count,
            'axial_max': max(axial_mianya) if axial_mianya else 0.0,
            'axial_min': min(axial_mianya) if axial_mianya else 0.0,
            'radial_max': max(radial_mianya) if radial_mianya else 0.0,
            'radial_min': min(radial_mianya) if radial_mianya else 0.0
        }

        # 返回结果
        result_dict = {
            'projection_areas': {'a': a, 'b': b, 'c': c},
            'axial_data': axial_data,
            'radial_data': radial_data,
            'axial_mianya': axial_mianya,
            'radial_mianya': radial_mianya,
            'mianya_result': [axial_mianya, radial_mianya],
            'statistics': stats
        }

        print(f"\n面压计算结果:")
        print(f"  轴向面压: {[f'{x:.6f}' for x in axial_mianya]}")
        print(f"  径向面压: {[f'{x:.6f}' for x in radial_mianya]}")
        print(f"  轴向正值数量: {stats['axial_positive_count']}")
        print(f"  轴向负值数量: {stats['axial_negative_count']}")
        print(f"  轴向零值数量: {stats['axial_zero_count']}")
        print(f"  轴向面压最大值: {stats['axial_max']:.6f}")
        print(f"  轴向面压最小值: {stats['axial_min']:.6f}")
        print(f"  径向面压最大值: {stats['radial_max']:.6f}")
        print(f"  径向面压最小值: {stats['radial_min']:.6f}")

        return result_dict

    except Exception as e:
        raise Exception(f"面压计算时出错: {str(e)}")


def integrated_mianya_process(file_path: str,
                              excel_range: Tuple[int, int, int, int],
                              angle_data: List[List[float]] = None,
                              projection_areas: tuple = None) -> dict:
    """
    集成面压处理流程：包含文件读取、角度输入、余弦计算、分解计算、求和计算、径向数组计算和面压计算

    参数:
    ----------
    file_path : str
        Excel文件路径
    excel_range : Tuple[int, int, int, int]
        Excel数据范围 (start_row, end_row, start_col, end_col)
    angle_data : List[List[float]], optional
        角度数据，如果为None则使用默认值
    projection_areas : tuple, optional
        投影面值元组 (a, b, c)，如果为None则通过输入函数获取

    返回:
    ----------
    dict
        包含所有结果和信息的字典
    """
    try:
        # 1. 执行集成轴向径向处理流程
        print("=" * 60)
        print("开始集成面压处理流程")
        print("=" * 60)

        # 执行集成轴向径向处理
        axial_radial_result = integrated_axial_radial_process(file_path, excel_range, angle_data)

        # 2. 获取投影面值
        print("\n" + "=" * 60)
        print("获取投影面值")
        print("=" * 60)

        if projection_areas is None:
            a, b, c = input_projection_areas()
        else:
            a, b, c = projection_areas
            print(f"使用提供的投影面值: a={a}, b={b}, c={c}")

        # 3. 计算面压
        print("\n" + "=" * 60)
        print("执行面压计算")
        print("=" * 60)

        # 从轴向径向结果中提取径向数组结果
        radial_array = [axial_radial_result['axial_data'], axial_radial_result['radial_data']]

        mianya_result = calculate_mianya(radial_array, a, b, c)

        # 4. 合并结果
        final_result = {**axial_radial_result, **mianya_result}

        return final_result

    except Exception as e:
        raise Exception(f"集成面压处理流程出错: {str(e)}")


def display_mianya_results(result_dict: dict, show_details: bool = False):
    """
    显示面压计算结果

    参数:
    ----------
    result_dict : dict
        integrated_mianya_process函数的返回结果
    show_details : bool
        是否显示详细结果
    """
    if 'axial_mianya' not in result_dict or 'radial_mianya' not in result_dict:
        print("错误: 结果字典中不包含面压计算结果")
        return

    a = result_dict['projection_areas']['a']
    b = result_dict['projection_areas']['b']
    c = result_dict['projection_areas']['c']
    axial_mianya = result_dict['axial_mianya']
    radial_mianya = result_dict['radial_mianya']
    stats = result_dict['statistics']

    print("\n" + "=" * 100)
    print("面压计算结果")
    print("=" * 100)

    print(f"投影面值: a={a}, b={b}, c={c}")

    # 显示轴向面压结果
    print(f"\n轴向面压结果 (索引0数组):")
    print("-" * 60)
    for i, value in enumerate(axial_mianya):
        original_value = result_dict['axial_data'][i]
        if original_value > 0:
            operation = f"{original_value} / {a}"
        elif original_value < 0:
            operation = f"{original_value} / {b}"
        else:
            operation = "0 (保持不变)"

        print(f"  第{i + 1}列: {operation} = {value:.6f}")

    # 显示径向面压结果
    print(f"\n径向面压结果 (索引1数组):")
    print("-" * 60)
    for i, value in enumerate(radial_mianya):
        original_value = result_dict['radial_data'][i]
        print(f"  第{i + 1}列: {original_value} / {c} = {value:.6f}")

    # 显示统计信息
    print(f"\n统计信息:")
    print(f"  轴向面压最大值: {stats['axial_max']:.6f}")
    print(f"  轴向面压最小值: {stats['axial_min']:.6f}")
    print(f"  径向面压最大值: {stats['radial_max']:.6f}")
    print(f"  径向面压最小值: {stats['radial_min']:.6f}")
    print(f"  轴向正值数量: {stats['axial_positive_count']}")
    print(f"  轴向负值数量: {stats['axial_negative_count']}")
    print(f"  轴向零值数量: {stats['axial_zero_count']}")

    if show_details:
        # 显示详细的面压计算结果
        print(f"\n详细面压计算结果:")
        print(f"  轴向面压数组: {[f'{x:.6f}' for x in axial_mianya]}")
        print(f"  径向面压数组: {[f'{x:.6f}' for x in radial_mianya]}")


def save_mianya_results(result_dict: dict, filename: str = "mianya_results.txt"):
    """
    保存面压计算结果到文件
    """
    if 'axial_mianya' not in result_dict or 'radial_mianya' not in result_dict:
        print("错误: 结果字典中不包含面压计算结果")
        return

    with open(filename, 'w', encoding='utf-8') as f:
        f.write("面压计算结果\n")
        f.write("=" * 50 + "\n\n")

        f.write("投影面值:\n")
        f.write(f"  轴拉投影面 (a): {result_dict['projection_areas']['a']}\n")
        f.write(f"  轴压投影面 (b): {result_dict['projection_areas']['b']}\n")
        f.write(f"  径向投影面 (c): {result_dict['projection_areas']['c']}\n\n")

        f.write("轴向面压结果:\n")
        axial_data = result_dict['axial_data']
        axial_mianya = result_dict['axial_mianya']
        for i, (orig, mianya) in enumerate(zip(axial_data, axial_mianya)):
            if orig > 0:
                operation = f"{orig} / {result_dict['projection_areas']['a']}"
            elif orig < 0:
                operation = f"{orig} / {result_dict['projection_areas']['b']}"
            else:
                operation = "0 (保持不变)"
            f.write(f"  第{i + 1}列: {operation} = {mianya:.6f}\n")

        f.write("\n径向面压结果:\n")
        radial_data = result_dict['radial_data']
        radial_mianya = result_dict['radial_mianya']
        for i, (orig, mianya) in enumerate(zip(radial_data, radial_mianya)):
            f.write(f"  第{i + 1}列: {orig} / {result_dict['projection_areas']['c']} = {mianya:.6f}\n")

        f.write("\n统计信息:\n")
        stats = result_dict['statistics']
        f.write(f"  轴向面压最大值: {stats['axial_max']:.6f}\n")
        f.write(f"  轴向面压最小值: {stats['axial_min']:.6f}\n")
        f.write(f"  径向面压最大值: {stats['radial_max']:.6f}\n")
        f.write(f"  径向面压最小值: {stats['radial_min']:.6f}\n")
        f.write(f"  轴向正值数量: {stats['axial_positive_count']}\n")
        f.write(f"  轴向负值数量: {stats['axial_negative_count']}\n")
        f.write(f"  轴向零值数量: {stats['axial_zero_count']}\n")


def gongkuang(file_path: str,
              excel_range: Tuple[int, int, int, int],  # 接受整个数据范围
              condition_col: int,  # 新增：独立的工况名称所在列
              sheet_name: Union[str, int] = 0) -> List[str]:
    """
    读取Excel文件中指定工况数据范围的工况名称
    修改：选择行的范围，读取工况名称所在列（第1行、第4行、第7行等）

    参数:
    ----------
    file_path : str
        Excel文件路径
    excel_range : Tuple[int, int, int, int]
        Excel数据范围 (start_row, end_row, start_col, end_col)
    condition_col : int
        工况名称所在列（独立参数）
    sheet_name : Union[str, int], default=0
        工作表名称或索引

    返回:
    ----------
    List[str]
        工况名称列表，每个元素对应一个工况数据范围的工况名称
    """
    try:
        # 读取整个工作表
        df = pd.read_excel(file_path, sheet_name=sheet_name, header=None)

        start_row, end_row, start_col, end_col = excel_range

        # 将Excel行列编号(1-based)转换为Python索引(0-based)
        start_row_idx = start_row - 1
        condition_col_idx = condition_col - 1  # 工况名称列索引

        # 验证范围是否有效
        if start_row_idx < 0 or start_row_idx >= len(df):
            raise ValueError(f"起始行无效: {start_row}")

        if condition_col_idx < 0 or condition_col_idx >= len(df.columns):
            raise ValueError(f"工况名称列无效: {condition_col}")

        condition_names = []

        # 计算需要读取的数据行（第1行、第4行、第7行等）
        data_rows = []
        current_row = start_row_idx

        # 找到第一个数据行（第1行或其后第一个3的倍数的行）
        while current_row <= end_row - 1:  # end_row是包含的，所以减1
            # 计算当前行相对于起始行的偏移量
            row_offset = current_row - start_row_idx + 1
            # 如果行号是3的倍数减2（即1,4,7,10...），则读取该行
            if (row_offset - 1) % 3 == 0:
                data_rows.append(current_row)
            current_row += 1

        print(f"检测到 {len(data_rows)} 个工况数据行: {[r + 1 for r in data_rows]}")

        # 读取每个工况数据行的工况名称（位于独立的工况名称列）
        for i, row_idx in enumerate(data_rows):
            # 确保不超过行范围
            if row_idx > end_row - 1:
                break

            # 读取当前行、独立工况名称列的值
            value = df.iloc[row_idx, condition_col_idx]

            # 处理空值
            if pd.isna(value) or str(value).strip() == "":
                condition_name = f"工况{i + 1}"
            else:
                condition_name = str(value).strip()

            condition_names.append(condition_name)
            print(f"工况{i + 1}名称: {condition_name} (行{row_idx + 1}, 列{condition_col})")

        return condition_names

    except FileNotFoundError:
        raise FileNotFoundError(f"文件未找到: {file_path}")
    except Exception as e:
        raise Exception(f"读取工况名称时出错: {str(e)}")

    def get_condition_col_from_input() -> int:
        """
        获取用户输入的工况名称所在列

        返回:
        ----------
        int
            工况名称所在列（从1开始）
        """
        print("=" * 60)
        print("工况名称列输入")
        print("=" * 60)

        while True:
            try:
                condition_col = int(input("请输入工况名称所在列号 (从1开始): ").strip())

                if condition_col <= 0:
                    print("错误: 列号必须为正整数")
                    continue

                print(f"设置的工况名称列: 第{condition_col}列")
                return condition_col

            except ValueError:
                print("输入格式错误，请确保输入的是整数")
            except Exception as e:
                print(f"发生错误: {e}")

    def save_condition_col(condition_col: int, filename: str = "condition_col_config.txt"):
        """
        保存工况名称列到配置文件
        """
        try:
            with open(filename, 'w', encoding='utf-8') as f:
                f.write(f"condition_col={condition_col}\n")
            print(f"工况名称列已保存到: {filename}")
        except Exception as e:
            print(f"保存工况名称列时出错: {e}")

    def load_condition_col(filename: str = "condition_col_config.txt") -> int:
        """
        从配置文件加载工况名称列
        """
        try:
            import os
            if not os.path.exists(filename):
                return None

            with open(filename, 'r', encoding='utf-8') as f:
                line = f.readline().strip()
                if '=' in line:
                    key, value = line.split('=', 1)
                    if key.strip() == 'condition_col':
                        result = int(value.strip())
                        print(f"从配置文件加载工况名称列: 第{result}列")
                        return result
            return None
        except Exception as e:
            print(f"加载工况名称列时出错: {e}")
            return None

    def get_current_condition_col(result_dict: dict = None,
                                  config_file: str = "condition_col_config.txt") -> int:
        """
        获取当前的工况名称列（优先级：结果字典 > 配置文件 > 用户输入）
        """
        # 1. 首先尝试从结果字典中获取
        if result_dict and 'condition_col' in result_dict:
            condition_col = result_dict['condition_col']
            print(f"从结果字典中获取工况名称列: 第{condition_col}列")
            return condition_col

        # 2. 尝试从配置文件中加载
        condition_col = load_condition_col(config_file)
        if condition_col is not None:
            return condition_col

        # 3. 如果都没有，则要求用户输入
        print("未找到工况名称列配置，需要用户输入")
        return get_condition_col_from_input()


def save_condition_col(condition_col: int, filename: str = "condition_col_config.txt"):
    """
    保存工况名称列到配置文件
    """
    try:
        with open(filename, 'w', encoding='utf-8') as f:
            f.write(f"condition_col={condition_col}\n")
        print(f"工况名称列已保存到: {filename}")
    except Exception as e:
        print(f"保存工况名称列时出错: {e}")

def get_excel_range_from_input() -> Tuple[int, int, int, int]:
    """
    获取用户输入的Excel数据范围
    修改：主要关注行范围，列范围用于确定工况名称所在列

    返回:
    ----------
    Tuple[int, int, int, int]
        Excel数据范围 (start_row, end_row, start_col, end_col)
    """
    print("=" * 60)
    print("Excel数据范围输入")
    print("=" * 60)
    print("注意: 现在主要关注行范围，列范围用于确定工况名称所在列")

    while True:
        try:
            # 获取行范围
            print("\n行范围设置:")
            start_row = int(input("请输入起始行号 (从1开始): ").strip())
            end_row = int(input("请输入结束行号 (包含该行): ").strip())

            # 获取列范围（主要用于确定工况名称所在列）
            print("\n列范围设置 (用于确定工况名称所在列):")
            start_col = int(input("请输入起始列号 (从1开始，工况名称所在列): ").strip())
            end_col = int(input("请输入结束列号 (包含该列): ").strip())

            # 验证输入范围是否有效
            if start_row <= 0 or end_row <= 0 or start_col <= 0 or end_col <= 0:
                print("错误: 行号和列号必须为正整数")
                continue

            if start_row > end_row:
                print("错误: 起始行号不能大于结束行号")
                continue

            if start_col > end_col:
                print("错误: 起始列号不能大于结束列号")
                continue

            print(f"设置的数据范围: 行{start_row}-{end_row}, 列{start_col}-{end_col}")
            print(f"工况名称将从第{start_col}列读取，行位置: {start_row}, {start_row + 3}, {start_row + 6}...")

            return start_row, end_row, start_col, end_col

        except ValueError:
            print("输入格式错误，请确保输入的是整数")
        except Exception as e:
            print(f"发生错误: {e}")


def save_excel_range(excel_range: Tuple[int, int, int, int], filename: str = "excel_range_config.txt"):
    """
    保存Excel数据范围到配置文件

    参数:
    ----------
    excel_range : Tuple[int, int, int, int]
        Excel数据范围
    filename : str
        配置文件名
    """
    try:
        with open(filename, 'w', encoding='utf-8') as f:
            f.write(f"start_row={excel_range[0]}\n")
            f.write(f"end_row={excel_range[1]}\n")
            f.write(f"start_col={excel_range[2]}\n")
            f.write(f"end_col={excel_range[3]}\n")

        print(f"Excel数据范围已保存到: {filename}")
    except Exception as e:
        print(f"保存Excel数据范围时出错: {e}")


def load_excel_range(filename: str = "excel_range_config.txt") -> Tuple[int, int, int, int]:
    """
    从配置文件加载Excel数据范围

    参数:
    ----------
    filename : str
        配置文件名

    返回:
    ----------
    Tuple[int, int, int, int]
        Excel数据范围，如果文件不存在则返回None
    """
    try:
        import os
        if not os.path.exists(filename):
            return None

        excel_range = {}
        with open(filename, 'r', encoding='utf-8') as f:
            for line in f:
                line = line.strip()
                if '=' in line:
                    key, value = line.split('=', 1)
                    excel_range[key.strip()] = int(value.strip())

        if all(key in excel_range for key in ['start_row', 'end_row', 'start_col', 'end_col']):
            result = (excel_range['start_row'], excel_range['end_row'],
                      excel_range['start_col'], excel_range['end_col'])
            print(f"从配置文件加载Excel数据范围: 行{result[0]}-{result[1]}, 列{result[2]}-{result[3]}")
            return result
        else:
            return None

    except Exception as e:
        print(f"加载Excel数据范围时出错: {e}")
        return None


def get_current_excel_range(result_dict: dict = None,
                            config_file: str = "excel_range_config.txt") -> Tuple[int, int, int, int]:
    """
    获取当前的Excel数据范围（优先级：结果字典 > 配置文件 > 用户输入）

    参数:
    ----------
    result_dict : dict, optional
        结果字典，可能包含excel_range
    config_file : str
        配置文件名

    返回:
    ----------
    Tuple[int, int, int, int]
        Excel数据范围
    """
    # 1. 首先尝试从结果字典中获取
    if result_dict and 'excel_range' in result_dict:
        excel_range = result_dict['excel_range']
        print(
            f"从结果字典中获取Excel数据范围: 行{excel_range[0]}-{excel_range[1]}, 列{excel_range[2]}-{excel_range[3]}")
        return excel_range

    # 2. 尝试从配置文件中加载
    excel_range = load_excel_range(config_file)
    if excel_range is not None:
        return excel_range

    # 3. 如果都没有，则要求用户输入
    print("未找到Excel数据范围配置，需要用户输入")
    return get_excel_range_from_input()


def save_results_to_excel(result_dict: dict,
                          file_path: str,
                          output_file: str = None,
                          condition_col: int = None) -> str:  # 修改参数名
    """
    将结果保存到Excel文件的两个工作表中，并对最大值进行标黄
    修改：使用独立的工况名称列参数
    """
    try:
        # 导入openpyxl的样式模块
        from openpyxl.styles import PatternFill, Font
        from openpyxl import Workbook

        # 确定输出文件路径
        if output_file is None:
            import os
            base_name = os.path.splitext(file_path)[0]
            output_file = f"{base_name}_结果.xlsx"

        print(f"开始将结果保存到Excel文件: {output_file}")

        # 获取数据范围
        excel_range = get_current_excel_range(result_dict)
        start_row, end_row, start_col, end_col = excel_range

        # 获取工况名称列
        if condition_col is None:
            condition_col = get_current_condition_col(result_dict)

        print(f"使用的数据范围: 行{start_row}-{end_row}, 列{start_col}-{end_col}")
        print(f"使用的工况名称列: 第{condition_col}列")

        # 读取工况名称（使用新的gongkuang函数，传递独立的condition_col参数）
        condition_names = []
        try:
            condition_names = gongkuang(
                file_path=file_path,
                excel_range=excel_range,
                condition_col=condition_col  # 传递独立的工况名称列
            )
            print(f"成功读取工况名称: {condition_names}")
        except Exception as e:
            print(f"读取工况名称时出错: {e}")
            # 生成默认工况名称
            total_columns = end_col - start_col + 1
            num_conditions = total_columns // 3
            if total_columns % 3 != 0:
                num_conditions += 1
            condition_names = [f"工况{i+1}" for i in range(num_conditions)]
            print(f"使用默认工况名称: {condition_names}")

        # 其余代码保持不变...
        # 获取所需数据
        sum_result = result_dict.get('sum_result', [])
        radial_data = result_dict.get('radial_data', [])
        axial_mianya = result_dict.get('axial_mianya', [])
        radial_mianya = result_dict.get('radial_mianya', [])

        # 确定行数 - 使用工况名称的数量
        num_rows = len(condition_names)
        print(f"最终确定的数据行数: {num_rows} (基于工况名称数量)")

        # 创建新的工作簿
        wb = Workbook()
        # 删除默认创建的工作表
        wb.remove(wb.active)

        # 工作表1: 详细结果
        ws1 = wb.create_sheet("详细结果")
        print("创建工作表1: 详细结果")

        # 设置标题行
        headers = ['工况名称', '轴向力分解', '径向力分解', '轴向面压计算结果', '径向面压计算结果']
        for col_idx, header in enumerate(headers, 1):
            ws1.cell(row=1, column=col_idx, value=header)
            ws1.cell(row=1, column=col_idx).font = Font(bold=True)

        # 填充数据 - 工况名称作为第一列
        for row_idx in range(num_rows):
            # 第一列：工况名称
            ws1.cell(row=row_idx + 2, column=1, value=condition_names[row_idx])

            # 第二列：轴向力分解（sum_result索引0）
            if sum_result and len(sum_result) > 0 and row_idx < len(sum_result[0]):
                value = sum_result[0][row_idx] if sum_result[0] else None
                ws1.cell(row=row_idx + 2, column=2, value=value)
            else:
                ws1.cell(row=row_idx + 2, column=2, value=None)

            # 第三列：径向力分解
            if radial_data and row_idx < len(radial_data):
                ws1.cell(row=row_idx + 2, column=3, value=radial_data[row_idx])
            else:
                ws1.cell(row=row_idx + 2, column=3, value=None)

            # 第四列：轴向面压计算结果
            if axial_mianya and row_idx < len(axial_mianya):
                ws1.cell(row=row_idx + 2, column=4, value=axial_mianya[row_idx])
            else:
                ws1.cell(row=row_idx + 2, column=4, value=None)

            # 第五列：径向面压计算结果
            if radial_mianya and row_idx < len(radial_mianya):
                ws1.cell(row=row_idx + 2, column=5, value=radial_mianya[row_idx])
            else:
                ws1.cell(row=row_idx + 2, column=5, value=None)

        # 设置列宽
        column_widths = [20, 15, 15, 18, 18]
        for i, width in enumerate(column_widths, 1):
            col_letter = chr(64 + i)
            ws1.column_dimensions[col_letter].width = width

        # 为最大值添加黄色背景
        yellow_fill = PatternFill(start_color='FFFF00', end_color='FFFF00', fill_type='solid')

        # 为每列的最大值标黄（排除工况名称列）
        for col_idx in range(2, 6):  # B到E列
            max_value = None
            max_rows = []

            # 找到最大值
            for row_idx in range(2, num_rows + 2):
                cell_value = ws1.cell(row=row_idx, column=col_idx).value
                if cell_value is not None:
                    try:
                        num_value = float(cell_value)
                        if max_value is None or num_value > max_value:
                            max_value = num_value
                            max_rows = [row_idx]
                        elif num_value == max_value:
                            max_rows.append(row_idx)
                    except (ValueError, TypeError):
                        continue

            # 标记所有等于最大值的单元格
            if max_value is not None:
                for row_idx in max_rows:
                    ws1.cell(row=row_idx, column=col_idx).fill = yellow_fill

        # 工作表2: 统计结果
        ws2 = wb.create_sheet("统计结果")
        print("创建工作表2: 统计结果")

        # 设置标题行
        stats_headers = ['统计项', '数值', '说明']
        for col_idx, header in enumerate(stats_headers, 1):
            ws2.cell(row=1, column=col_idx, value=header)
            ws2.cell(row=1, column=col_idx).font = Font(bold=True)

        # 添加统计信息
        stats = result_dict.get('statistics', {})
        row_idx = 2

        # 收集所有数值用于找到最大值
        all_values = []

        # 添加面压结果的极大值和极小值
        axial_mianya_stats = result_dict.get('axial_mianya', [])
        radial_mianya_stats = result_dict.get('radial_mianya', [])

        if axial_mianya_stats:
            axial_mianya_max = max(axial_mianya_stats) if axial_mianya_stats else 0
            axial_mianya_min = min(axial_mianya_stats) if axial_mianya_stats else 0

            ws2.cell(row=row_idx, column=1, value='轴向面压最大值')
            ws2.cell(row=row_idx, column=2, value=axial_mianya_max)
            ws2.cell(row=row_idx, column=3, value='轴向面压计算结果中的最大值')
            all_values.append(axial_mianya_max)
            row_idx += 1

            ws2.cell(row=row_idx, column=1, value='轴向面压最小值')
            ws2.cell(row=row_idx, column=2, value=axial_mianya_min)
            ws2.cell(row=row_idx, column=3, value='轴向面压计算结果中的最小值')
            all_values.append(axial_mianya_min)
            row_idx += 1

        if radial_mianya_stats:
            radial_mianya_max = max(radial_mianya_stats) if radial_mianya_stats else 0
            radial_mianya_min = min(radial_mianya_stats) if radial_mianya_stats else 0

            ws2.cell(row=row_idx, column=1, value='径向面压最大值')
            ws2.cell(row=row_idx, column=2, value=radial_mianya_max)
            ws2.cell(row=row_idx, column=3, value='径向面压计算结果中的最大值')
            all_values.append(radial_mianya_max)
            row_idx += 1

            ws2.cell(row=row_idx, column=1, value='径向面压最小值')
            ws2.cell(row=row_idx, column=2, value=radial_mianya_min)
            ws2.cell(row=row_idx, column=3, value='径向面压计算结果中的最小值')
            all_values.append(radial_mianya_min)
            row_idx += 1

        # 设置统计结果工作表的列宽
        stats_widths = [20, 15, 25]
        for i, width in enumerate(stats_widths, 1):
            col_letter = chr(64 + i)
            ws2.column_dimensions[col_letter].width = width

        # 为统计结果工作表中的最大值标黄
        if all_values:
            overall_max = max(all_values) if all_values else 0
            for row in range(2, row_idx):
                value = ws2.cell(row=row, column=2).value
                if value is not None and value == overall_max:
                    ws2.cell(row=row, column=2).fill = yellow_fill

        # 保存工作簿
        wb.save(output_file)

        print(f"结果已成功保存到: {output_file}")
        print("注意: 工况名称已从第{}列自动读取".format(condition_col))
        print("注意: 最大值已用黄色背景标记")
        return output_file

    except Exception as e:
        raise Exception(f"保存结果到Excel时出错: {str(e)}")



# 修改 integrated_full_process 函数，添加 condition_col 参数
def integrated_full_process(file_path: str,
                            excel_range: Tuple[int, int, int, int],
                            angle_data: List[List[float]] = None,
                            projection_areas: tuple = None,
                            output_file: str = None,
                            condition_col: int = None) -> dict:  # 修改参数名和用途
    """
    完整处理流程：包含所有计算步骤并将结果保存到Excel，最大值标黄
    修改：使用独立的工况名称列参数

    参数:
    ----------
    file_path : str
        Excel文件路径
    excel_range : Tuple[int, int, int, int]
        Excel数据范围 (start_row, end_row, start_col, end_col)
    angle_data : List[List[float]], optional
        角度数据，如果为None则使用默认值
    projection_areas : tuple, optional
        投影面值元组 (a, b, c)，如果为None则通过输入函数获取
    output_file : str, optional
        输出文件路径，如果为None则基于原始文件路径生成
    condition_col : int, optional
        工况名称所在的列号（从1开始）

    返回:
    ----------
    dict
        包含所有结果和信息的字典
    """
    try:
        # 执行集成面压处理
        result = integrated_mianya_process(
            file_path=file_path,
            excel_range=excel_range,
            angle_data=angle_data,
            projection_areas=projection_areas
        )

        # 将结果保存到Excel（传递condition_col参数）
        saved_file = save_results_to_excel(
            result,
            file_path,
            output_file,
            condition_col  # 传递工况名称列
        )

        # 在结果字典中添加保存的文件路径和工况名称列
        result['saved_file'] = saved_file
        result['condition_col'] = condition_col

        return result

    except Exception as e:
        raise Exception(f"完整处理流程出错: {str(e)}")

def display_full_results(result_dict: dict, show_details: bool = False):
    """
    显示完整处理结果

    参数:
    ----------
    result_dict : dict
        integrated_full_process函数的返回结果
    show_details : bool
        是否显示详细结果
    """
    # 显示面压结果
    display_mianya_results(result_dict, show_details)

    # 显示保存的文件信息
    if 'saved_file' in result_dict:
        print(f"\n结果已保存到: {result_dict['saved_file']}")
        print("注意: 最大值已用黄色背景标记")


def read_condition_data(file_path: str,
                        condition_ranges: List[Tuple[int, int, int, int]],
                        # 每个工况的数据范围 (start_row, end_row, start_col, end_col)
                        sheet_name: Union[str, int] = 0,
                        header: Optional[int] = None) -> List[List[List[Union[float, int, str]]]]:
    """
    读取多个工况数据范围的数据

    参数:
    ----------
    file_path : str
        Excel文件路径
    condition_ranges : List[Tuple[int, int, int, int]]
        每个工况的数据范围列表
    sheet_name : Union[str, int], default=0
        工作表名称或索引
    header : Optional[int], default=None
        表头行，None表示无表头

    返回:
    ----------
    List[List[List[Union[float, int, str]]]]
        读取的数据列表，每个元素代表一个工况的数据
    """
    try:
        all_condition_data = []

        for i, (start_row, end_row, start_col, end_col) in enumerate(condition_ranges):
            print(f"读取第{i + 1}个工况数据范围: 行{start_row}-{end_row}, 列{start_col}-{end_col}")

            # 使用修改后的read_excel_data函数读取数据
            condition_data = read_excel_data(
                file_path=file_path,
                start_row=start_row,
                end_row=end_row,
                start_col=start_col,
                end_col=end_col,
                sheet_name=sheet_name,
                header=header
            )

            all_condition_data.append(condition_data)

        return all_condition_data

    except Exception as e:
        raise Exception(f"读取工况数据时出错: {str(e)}")


# 修改主函数调用
if __name__ == "__main__":
    try:
        # 1. 设置文件路径
        file_path = r"E:\项目二22222222222222222\代码\项目三\RSP\22222.xlsx"

        # 2. 直接指定Excel数据范围
        excel_range = (23, 500, 3, 5)  # 起始行1，结束行120，起始列7，结束列9
        print(f"设置的数据范围: 行{excel_range[0]}-{excel_range[1]}, 列{excel_range[2]}-{excel_range[3]}")

        # 3. 设置独立的工况名称列
        condition_col = 1  # 工况名称在第1列
        print(f"设置的工况名称列: 第{condition_col}列")

        # 4. 设置角度数据（可选，不设置使用默认值）
        angle_data = [
            [35.937, 65.656, 114.694],
            [111.825, 100.987, 155.306],
            [62.991, 152.997, 89.939]
        ]

        # 5. 设置投影面值（可选，不设置会提示输入）
        projection_areas = (100.0, 150.0, 200.0)  # a, b, c

        # 6. 设置输出文件路径（可选）
        output_file = r"E:\项目二22222222222222222\1111111列结果输出.xlsx"

        # 7. 执行完整处理流程（添加condition_col参数）
        result = integrated_full_process(
            file_path=file_path,
            excel_range=excel_range,
            angle_data=angle_data,
            projection_areas=projection_areas,
            output_file=output_file,
            condition_col=condition_col  # 新增参数
        )

        # 8. 显示结果
        display_full_results(result, show_details=True)

    except Exception as e:
        print(f"错误: {e}")
