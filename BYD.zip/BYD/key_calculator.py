import tkinter as tk
from tkinter import ttk, messagebox, filedialog
import utils
import os

class KeyCalculatorUI:
    def __init__(self, root):
        self.root = root
        self.root.title("密码计算器")
        self.root.geometry("450x200")  # 缩小窗口适配简化后的界面

        # 设置你自己的图片作为程序图标
        self.set_custom_icon("7.ico")  # 替换为你的图片路径

        # 固定加密规则（仅保留这一种方式，不再允许修改）
        self.fixed_rule = {
            "to_upper": True,
            "hash_type": "sha256",
            "hash_length": 16,
            "shift": 5,
            "reverse": True
        }

        # 构建UI
        self._create_widgets()



    def set_custom_icon(self, image_path):
        """设置自定义图片作为程序图标"""
        try:
            # 检查图片文件是否存在
            if not os.path.exists(image_path):
                print(f"警告: 图片文件不存在: {image_path}")
                return

            # 使用PIL库处理图片（支持多种格式）
            from PIL import Image, ImageTk

            # 打开并处理图片
            image = Image.open(image_path)

            # 调整图片大小（可选，图标通常较小）
            icon_size = (32, 32)  # 标准图标大小
            image = image.resize(icon_size, Image.Resampling.LANCZOS)

            # 转换为Tkinter可用的格式
            icon = ImageTk.PhotoImage(image)

            # 设置窗口图标
            self.root.iconphoto(True, icon)

            # 保存引用，防止被垃圾回收
            self.app_icon = icon

            print(f"成功设置自定义图标: {image_path}")

        except ImportError:
            # 如果PIL未安装，尝试使用其他方法
            print("PIL库未安装，尝试使用ICO文件")
            self.try_ico_icon()
        except Exception as e:
            print(f"设置自定义图标失败: {e}")

    def _create_widgets(self):
        # 1. 主板序列号输入区
        frame_serial = ttk.LabelFrame(self.root, text="cpu-硬盘-主板序列号(填入格式一致)")
        frame_serial.pack(fill="x", padx=10, pady=5)

        ttk.Label(frame_serial, text="序列号：").pack(side="left", padx=5, pady=5)
        self.entry_serial = ttk.Entry(frame_serial, width=35)
        self.entry_serial.pack(side="left", padx=5, pady=5)
        # 一键读取本机序列号按钮
        ttk.Button(frame_serial, text="读取本机", command=self._read_local_serial).pack(side="left", padx=5)

        # 2. 密钥生成区（移除所有规则配置项，仅保留生成功能）
        frame_key = ttk.LabelFrame(self.root, text="生成密钥")
        frame_key.pack(fill="x", padx=10, pady=5)

        ttk.Button(frame_key, text="生成密钥", command=self._generate_key).pack(side="left", padx=5, pady=5)
        self.entry_key = ttk.Entry(frame_key, width=35)
        self.entry_key.pack(side="left", padx=5, pady=5)

        # 3. 辅助功能区（仅保留复制密钥）
        frame_help = ttk.Frame(self.root)
        frame_help.pack(fill="x", padx=10, pady=10)

        ttk.Button(frame_help, text="复制密钥", command=self._copy_key).pack(side="left", padx=5)

    def _read_local_serial(self):
        """读取本机主板序列号并填充到输入框"""
        # serial = utils.get_motherboard_serial()
        # serial = utils.get_cpu_serial()
        serial = utils.get_device_fingerprint()
        self.entry_serial.delete(0, tk.END)
        self.entry_serial.insert(0, serial)

    def _generate_key(self):
        """使用固定规则生成密钥"""
        try:
            # 获取输入的序列号
            serial = self.entry_serial.get().strip()
            if not serial:
                messagebox.warning("提示", "请输入cpu,硬盘，主板序列号！")
                return

            # 直接使用固定规则生成密钥
            key = utils.encrypt_serial(serial, self.fixed_rule)
            self.entry_key.delete(0, tk.END)
            self.entry_key.insert(0, key)

        except Exception as e:
            messagebox.showerror("错误", f"生成密钥失败：{e}")

    def _copy_key(self):
        """复制生成的密钥到剪贴板"""
        key = self.entry_key.get().strip()
        if key:
            self.root.clipboard_clear()
            self.root.clipboard_append(key)
            messagebox.showinfo("成功", "密钥已复制到剪贴板！")


if __name__ == "__main__":
    root = tk.Tk()
    app = KeyCalculatorUI(root)
    root.mainloop()

