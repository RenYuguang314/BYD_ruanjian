"""
多文件参数配置UI界面 - 增强版（支持文件合并和自动识别结束行）
支持自动识别数据结束行功能，无需手动填写结束行参数
优化布局，减少留白，提高空间利用率
支持暂停运行程序功能
"""

import tkinter as tk
from tkinter import ttk, filedialog, messagebox, scrolledtext
import os
import threading
import time
import sys
import traceback
import utils
import pandas as pd
import re
from openpyxl import load_workbook
import warnings
import tempfile

warnings.filterwarnings('ignore')

# 添加当前目录到路径，以便导入文档1中的函数
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

# 导入文档1中的函数
try:
    # 直接导入文档1中的函数
    from RSP import (
        batch_process_files,
        display_batch_results,
        save_batch_results,
        integrated_full_process,
        calculate_cosines_from_manual,
        fenjie_simplified,
        sum_fenjie_result,
        calculate_radial_array,
        calculate_axial_radial_max,
        integrated_axial_radial_process,
        integrated_mianya_process,
        save_results_to_excel,
        find_data_end_row_in_columns,
        read_data_with_end_row_detection
    )

    # 导入文档1中的read_data函数
    from Shi_Bie_over import read_data

    IMPORT_SUCCESS = True
except ImportError as e:
    print(f"导入错误: {e}")
    IMPORT_SUCCESS = False


# 文件合并功能函数（从文档2复制）
def convert_csv_to_xlsx(csv_path):
    """将CSV文件转换为XLSX格式"""
    xlsx_path = csv_path.replace('.csv', '.xlsx')
    if not os.path.exists(xlsx_path):  # 避免重复转换
        df = pd.read_csv(csv_path)
        df.to_excel(xlsx_path, index=False)
    return xlsx_path


def merge_files_by_prefix(file_paths, output_dir=None):
    """
    根据文件前缀合并文件
    """
    if not file_paths:
        return []

    # 如果未指定输出目录，使用第一个文件所在目录
    if output_dir is None:
        output_dir = os.path.dirname(file_paths[0])

    # 创建输出目录（如果不存在）
    os.makedirs(output_dir, exist_ok=True)

    # 文件分组字典，按前缀分组
    file_groups = {}

    # 正则表达式匹配文件前缀和数字部分
    pattern = r'QBED_S0_JXPG_Road_(\d+_\d+)_R_droplink_out-'

    # 第一步：处理所有文件，确保都是xlsx格式
    processed_files = []
    for file_path in file_paths:
        if not os.path.exists(file_path):
            print(f"警告: 文件不存在 - {file_path}")
            continue

        file_name = os.path.basename(file_path)
        file_ext = os.path.splitext(file_name)[1].lower()

        # 如果是csv文件，转换为xlsx
        if file_ext == '.csv':
            xlsx_path = convert_csv_to_xlsx(file_path)
            processed_files.append((file_name, xlsx_path))
        elif file_ext in ['.xlsx', '.xls']:
            # 如果是xlsx文件，直接使用
            processed_files.append((file_name, file_path))
        else:
            print(f"警告: 不支持的文件格式 - {file_path}")
            continue

    # 第二步：按前缀分组文件
    for file_name, file_path in processed_files:
        match = re.search(pattern, file_name)
        if match:
            prefix = match.group(0)  # 完整前缀
            num_part = match.group(1)  # 数字部分，如"1_1"

            # 提取后缀（FX, FY, FZ）
            base_name = file_name.replace('.xlsx', '').replace('.xls', '')
            suffix = base_name.split('-')[-1]

            if num_part not in file_groups:
                file_groups[num_part] = {'prefix': prefix, 'files': {}}

            file_groups[num_part]['files'][suffix] = file_path

    # 第三步：合并文件
    merged_file_paths = []

    for num_part, group_info in file_groups.items():
        files_dict = group_info['files']
        prefix = group_info['prefix']

        # 检查是否包含所有需要的文件
        required_suffixes = ['FX', 'FY', 'FZ']
        if not all(suffix in files_dict for suffix in required_suffixes):
            print(f"警告: 数字部分 {num_part} 的文件不完整，跳过处理")
            continue

        try:
            # 加载三个文件
            fx_path = files_dict['FX']
            fy_path = files_dict['FY']
            fz_path = files_dict['FZ']

            print(f"处理文件组 {num_part}:")
            print(f"  FX文件: {os.path.basename(fx_path)}")
            print(f"  FY文件: {os.path.basename(fy_path)}")
            print(f"  FZ文件: {os.path.basename(fz_path)}")

            # 使用pandas读取Excel文件
            df_fx = pd.read_excel(fx_path, header=None)
            df_fy = pd.read_excel(fy_path, header=None)
            df_fz = pd.read_excel(fz_path, header=None)

            print(f"  FX文件形状: {df_fx.shape} (行, 列)")
            print(f"  FY文件形状: {df_fy.shape} (行, 列)")
            print(f"  FZ文件形状: {df_fz.shape} (行, 列)")

            # 确保FX DataFrame至少有5列
            if df_fx.shape[1] < 5:
                print(f"  FX文件只有{df_fx.shape[1]}列，扩展至5列")
                for col_idx in range(df_fx.shape[1], 5):
                    df_fx[col_idx] = None

            # 获取FY文件的第三列（C列）数据
            fy_column_c = df_fy.iloc[:, 2]
            # 获取FZ文件的第三列（C列）数据
            fz_column_c = df_fz.iloc[:, 2]

            # 获取三个文件的总行数
            fx_rows = len(df_fx)
            fy_rows = len(df_fy)
            fz_rows = len(df_fz)

            # 计算需要合并的数据行数
            start_row = 8  # 第9行在pandas中的索引是8

            # 确保起始行不超出文件行数
            if start_row >= fx_rows or start_row >= fy_rows or start_row >= fz_rows:
                print(f"警告: 文件 {num_part} 行数不足9行，无法合并")
                continue

            # 计算最小行数，确保不会超出索引范围
            min_rows = min(fx_rows, fy_rows, fz_rows)

            # 创建要合并的行索引列表
            row_indices = list(range(start_row, min_rows))

            # 合并整列数据
            merged_rows = 0
            for i, row_idx in enumerate(row_indices):
                if row_idx < len(df_fy) and row_idx < len(df_fx):
                    fy_value = fy_column_c.iloc[row_idx]
                    df_fx.iat[row_idx, 3] = fy_value
                    merged_rows += 1

            for i, row_idx in enumerate(row_indices):
                if row_idx < len(df_fz) and row_idx < len(df_fx):
                    fz_value = fz_column_c.iloc[row_idx]
                    df_fx.iat[row_idx, 4] = fz_value

            # 保存合并后的文件
            output_filename = f"{prefix}merged_{num_part}.xlsx"
            output_path = os.path.join(output_dir, output_filename)

            # 保存时去掉列名
            df_fx.to_excel(output_path, index=False, header=False)

            merged_file_paths.append(output_path)
            print(f"  已合并 {merged_rows} 行数据")
            print(f"  保存到: {output_path}\n")

        except Exception as e:
            print(f"错误: 处理数字部分 {num_part} 的文件时出错 - {str(e)}")
            traceback.print_exc()
            continue

    return merged_file_paths


class MultiFileConfigUI:
    def __init__(self, root):
        self.root = root

        self.root.title("RSP_DAC")
        self.root.geometry("1100x700")  # 进一步缩小整体尺寸

        # 设置你自己的图片作为程序图标
        self.set_custom_icon("7.ico")  # 替换为你的图片路径

        # 存储所有文件的配置
        self.file_configs = {}

        # 全局角度参数和投影面值
        self.global_angles = [
            tk.StringVar(value="68.175"),  # 与X方向的角度 - 轴向
            tk.StringVar(value="79.013"),  # 与Y方向的角度 - 轴向
            tk.StringVar(value="24.694"),  # 与Z方向的角度 - 轴向
            tk.StringVar(value="111.825"),  # 与X方向的角度 - 径向1
            tk.StringVar(value="100.987"),  # 与Y方向的角度 - 径向1
            tk.StringVar(value="155.306"),  # 与Z方向的角度 - 径向1
            tk.StringVar(value="62.991"),  # 与X方向的角度 - 径向2
            tk.StringVar(value="152.997"),  # 与Y方向的角度 - 径向2
            tk.StringVar(value="89.939")  # 与Z方向的角度 - 径向2
        ]

        self.global_proj_a = tk.StringVar(value="100.0")
        self.global_proj_b = tk.StringVar(value="150.0")
        self.global_proj_c = tk.StringVar(value="200.0")

        # 处理状态
        self.processing = False
        self.paused = False
        self.stop_requested = False

        # 合并文件相关变量
        self.merge_files_list = []
        self.merge_output_dir = tk.StringVar(value=os.getcwd())

        # 创建界面
        self.create_widgets()

        # 检查函数导入状态
        if not IMPORT_SUCCESS:
            messagebox.showwarning("警告", "无法导入函数，部分功能可能无法使用")

    def set_custom_icon(self, image_path):
        """设置自定义图片作为程序图标"""
        try:
            # 检查图片文件是否存在
            if not os.path.exists(image_path):
                print(f"警告: 图片文件不存在: {image_path}")
                return

            # 使用PIL库处理图片（支持多种格式）
            from PIL import Image, ImageTk

            # 打开并处理图片
            image = Image.open(image_path)

            # 调整图片大小（可选，图标通常较小）
            icon_size = (32, 32)  # 标准图标大小
            image = image.resize(icon_size, Image.Resampling.LANCZOS)

            # 转换为Tkinter可用的格式
            icon = ImageTk.PhotoImage(image)

            # 设置窗口图标
            self.root.iconphoto(True, icon)

            # 保存引用，防止被垃圾回收
            self.app_icon = icon

            print(f"成功设置自定义图标: {image_path}")

        except ImportError:
            # 如果PIL未安装，尝试使用其他方法
            print("PIL库未安装，尝试使用ICO文件")
            self.try_ico_icon()
        except Exception as e:
            print(f"设置自定义图标失败: {e}")


    def create_widgets(self):
        """创建界面组件"""
        # 主框架 - 使用PanedWindow实现左右分割
        main_paned = ttk.PanedWindow(self.root, orient=tk.HORIZONTAL)
        main_paned.pack(fill=tk.BOTH, expand=True, padx=3, pady=3)

        # 左侧框架 - 文件列表和配置区域
        left_frame = ttk.Frame(main_paned, padding="3")
        main_paned.add(left_frame, weight=1)  # 左侧占1/2宽度

        # 右侧框架 - 日志和进度区域
        right_frame = ttk.Frame(main_paned, padding="3")
        main_paned.add(right_frame, weight=1)  # 右侧占1/2宽度

        # 左侧上方：文件列表区域
        file_lists_frame = ttk.LabelFrame(left_frame, text="文件列表", padding="3")
        file_lists_frame.pack(fill=tk.BOTH, expand=True, pady=2)

        # 创建Notebook用于切换合并文件和待处理文件
        file_notebook = ttk.Notebook(file_lists_frame)
        file_notebook.pack(fill=tk.BOTH, expand=True, pady=2)

        # 合并文件列表标签页
        merge_tab = ttk.Frame(file_notebook, padding="2")
        file_notebook.add(merge_tab, text="合并文件列表")

        # 合并文件选择按钮
        merge_btn_frame = ttk.Frame(merge_tab)
        merge_btn_frame.pack(fill=tk.X, pady=1)

        ttk.Button(merge_btn_frame, text="选择合并文件",
                   command=self.select_merge_files, width=12).pack(side=tk.LEFT, padx=1)
        ttk.Button(merge_btn_frame, text="清空列表",
                   command=self.clear_merge_files, width=8).pack(side=tk.LEFT, padx=1)
        ttk.Button(merge_btn_frame, text="执行合并",
                   command=self.execute_merge, width=8).pack(side=tk.LEFT, padx=1)

        # 合并文件列表显示
        merge_list_frame = ttk.Frame(merge_tab)
        merge_list_frame.pack(fill=tk.BOTH, expand=True, pady=1)

        self.merge_listbox = tk.Listbox(merge_list_frame, selectmode=tk.EXTENDED)
        merge_scrollbar = ttk.Scrollbar(merge_list_frame, orient=tk.VERTICAL, command=self.merge_listbox.yview)
        self.merge_listbox.configure(yscrollcommand=merge_scrollbar.set)

        self.merge_listbox.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        merge_scrollbar.pack(side=tk.RIGHT, fill=tk.Y)

        # 合并输出目录设置
        merge_dir_frame = ttk.Frame(merge_tab)
        merge_dir_frame.pack(fill=tk.X, pady=1)

        ttk.Label(merge_dir_frame, text="输出目录:").pack(side=tk.LEFT)
        ttk.Entry(merge_dir_frame, textvariable=self.merge_output_dir,
                  width=25).pack(side=tk.LEFT, padx=2)
        ttk.Button(merge_dir_frame, text="选择",
                   command=self.select_merge_output_dir, width=6).pack(side=tk.LEFT, padx=1)

        # 待处理文件列表标签页
        process_tab = ttk.Frame(file_notebook, padding="2")
        file_notebook.add(process_tab, text="待处理文件列表")

        # 文件管理按钮
        process_btn_frame = ttk.Frame(process_tab)
        process_btn_frame.pack(fill=tk.X, pady=1)

        ttk.Button(process_btn_frame, text="添加文件",
                   command=self.add_multiple_files, width=10).pack(side=tk.LEFT, padx=1)
        ttk.Button(process_btn_frame, text="删除文件",
                   command=self.remove_current_file, width=8).pack(side=tk.LEFT, padx=1)
        ttk.Button(process_btn_frame, text="清空所有",
                   command=self.clear_all_files, width=8).pack(side=tk.LEFT, padx=1)

        # 待处理文件列表显示
        process_list_frame = ttk.Frame(process_tab)
        process_list_frame.pack(fill=tk.BOTH, expand=True, pady=1)

        self.file_listbox = tk.Listbox(process_list_frame, selectmode=tk.SINGLE)
        process_scrollbar = ttk.Scrollbar(process_list_frame, orient=tk.VERTICAL, command=self.file_listbox.yview)
        self.file_listbox.configure(yscrollcommand=process_scrollbar.set)

        self.file_listbox.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        process_scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        self.file_listbox.bind('<<ListboxSelect>>', self.on_file_select)

        # 左侧下方：参数配置区域
        config_frame = ttk.LabelFrame(left_frame, text="参数配置", padding="3")
        config_frame.pack(fill=tk.BOTH, expand=True, pady=2)

        # 添加批量自动识别按钮
        auto_detect_frame = ttk.Frame(config_frame)
        auto_detect_frame.pack(fill=tk.X, pady=2)

        ttk.Button(auto_detect_frame, text="批量自动识别结束行",
                   command=self.batch_auto_detect_end_row, width=15).pack(side=tk.LEFT, padx=2)
        ttk.Label(auto_detect_frame, text="点击此按钮为所有文件自动识别数据结束行").pack(side=tk.LEFT, padx=5)

        # 创建Notebook用于文件配置翻页
        self.config_notebook = ttk.Notebook(config_frame)
        self.config_notebook.pack(fill=tk.BOTH, expand=True)

        # 默认创建一个空配置页
        self.create_config_page("请添加文件")

        # 右侧区域：全局参数、进度和日志
        # 全局参数设置区域
        global_frame = ttk.LabelFrame(right_frame, text="全局参数设置", padding="3")
        global_frame.pack(fill=tk.X, pady=2)

        # 角度参数设置 - 紧凑布局
        angle_frame = ttk.LabelFrame(global_frame, text="角度参数", padding="2")
        angle_frame.pack(fill=tk.X, pady=1)

        # 角度分组
        angle_groups = [
            ("轴向", 0),
            ("径向1", 3),
            ("径向2", 6)
        ]

        for group_name, start_idx in angle_groups:
            group_frame = ttk.Frame(angle_frame)
            group_frame.pack(fill=tk.X, pady=0)

            ttk.Label(group_frame, text=f"{group_name}:").pack(side=tk.LEFT, padx=1)

            for i in range(3):
                angle_idx = start_idx + i
                direction = "XYZ"[i]
                ttk.Label(group_frame, text=f"{direction}:").pack(side=tk.LEFT, padx=1)
                # 增大角度参数输入框的宽度
                ttk.Entry(group_frame, textvariable=self.global_angles[angle_idx], width=8).pack(side=tk.LEFT, padx=1)

        # 投影面值设置
        proj_frame = ttk.LabelFrame(global_frame, text="投影面值", padding="2")
        proj_frame.pack(fill=tk.X, pady=1)

        proj_subframe = ttk.Frame(proj_frame)
        proj_subframe.pack(fill=tk.X)

        ttk.Label(proj_subframe, text="轴拉(a):").pack(side=tk.LEFT, padx=1)
        ttk.Entry(proj_subframe, textvariable=self.global_proj_a, width=8).pack(side=tk.LEFT, padx=1)

        ttk.Label(proj_subframe, text="轴压(b):").pack(side=tk.LEFT, padx=(5, 1))
        ttk.Entry(proj_subframe, textvariable=self.global_proj_b, width=8).pack(side=tk.LEFT, padx=1)

        ttk.Label(proj_subframe, text="径向(c):").pack(side=tk.LEFT, padx=(5, 1))
        ttk.Entry(proj_subframe, textvariable=self.global_proj_c, width=8).pack(side=tk.LEFT, padx=1)

        # 控制按钮区域
        control_frame = ttk.Frame(right_frame)
        control_frame.pack(fill=tk.X, pady=2)

        # 保留"开始处理"按钮，保持批量处理功能
        ttk.Button(control_frame, text="开始处理",
                   command=self.batch_process, width=10).pack(side=tk.LEFT, padx=2)
        ttk.Button(control_frame, text="暂停",
                   command=self.pause_process, width=8).pack(side=tk.LEFT, padx=2)
        ttk.Button(control_frame, text="继续",
                   command=self.resume_process, width=8).pack(side=tk.LEFT, padx=2)
        ttk.Button(control_frame, text="停止",
                   command=self.stop_process, width=8).pack(side=tk.LEFT, padx=2)

        # 进度显示区域
        progress_frame = ttk.LabelFrame(right_frame, text="处理进度", padding="3")
        progress_frame.pack(fill=tk.X, pady=2)

        # 当前任务标签
        self.current_task_label = ttk.Label(progress_frame, text="就绪", font=("Arial", 9, "bold"))
        self.current_task_label.pack(fill=tk.X, pady=1)

        # 进度条和百分比
        progress_bar_frame = ttk.Frame(progress_frame)
        progress_bar_frame.pack(fill=tk.X, pady=1)

        self.progress_bar = ttk.Progressbar(progress_bar_frame, mode='determinate')
        self.progress_bar.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=(0, 5))

        self.progress_percent_var = tk.StringVar(value="0%")
        self.progress_percent_label = ttk.Label(progress_bar_frame, textvariable=self.progress_percent_var,
                                                font=("Arial", 9, "bold"), foreground="blue", width=5)
        self.progress_percent_label.pack(side=tk.RIGHT)

        # 详细进度信息
        self.detailed_progress_var = tk.StringVar(value="等待开始...")
        self.detailed_progress_label = ttk.Label(progress_frame, textvariable=self.detailed_progress_var,
                                                 wraplength=300, font=("Arial", 8))
        self.detailed_progress_label.pack(fill=tk.X, pady=1)

        # 文件处理统计
        stats_frame = ttk.LabelFrame(progress_frame, text="处理统计", padding="2")
        stats_frame.pack(fill=tk.X, pady=1)

        stats_grid = ttk.Frame(stats_frame)
        stats_grid.pack(fill=tk.X)

        # 第一行统计
        stats_row1 = ttk.Frame(stats_grid)
        stats_row1.pack(fill=tk.X)

        ttk.Label(stats_row1, text="总文件数:").pack(side=tk.LEFT)
        self.total_files_var = tk.StringVar(value="0")
        ttk.Label(stats_row1, textvariable=self.total_files_var, font=("Arial", 9, "bold"), width=5).pack(side=tk.LEFT,
                                                                                                          padx=2)

        ttk.Label(stats_row1, text="已处理:").pack(side=tk.LEFT, padx=(10, 2))
        self.processed_files_var = tk.StringVar(value="0")
        ttk.Label(stats_row1, textvariable=self.processed_files_var, font=("Arial", 9, "bold"), width=5).pack(
            side=tk.LEFT, padx=2)

        # 第二行统计
        stats_row2 = ttk.Frame(stats_grid)
        stats_row2.pack(fill=tk.X)

        ttk.Label(stats_row2, text="成功:").pack(side=tk.LEFT)
        self.success_files_var = tk.StringVar(value="0")
        ttk.Label(stats_row2, textvariable=self.success_files_var, font=("Arial", 9, "bold"),
                  foreground="green", width=5).pack(side=tk.LEFT, padx=2)

        ttk.Label(stats_row2, text="失败:").pack(side=tk.LEFT, padx=(10, 2))
        self.failed_files_var = tk.StringVar(value="0")
        ttk.Label(stats_row2, textvariable=self.failed_files_var, font=("Arial", 9, "bold"),
                  foreground="red", width=5).pack(side=tk.LEFT, padx=2)

        # 日志区域
        log_frame = ttk.LabelFrame(right_frame, text="处理日志", padding="2")
        log_frame.pack(fill=tk.BOTH, expand=True, pady=2)

        # 日志控制按钮
        log_control_frame = ttk.Frame(log_frame)
        log_control_frame.pack(fill=tk.X, pady=1)

        ttk.Button(log_control_frame, text="清空日志", command=self.clear_log, width=8).pack(side=tk.LEFT, padx=1)
        ttk.Button(log_control_frame, text="保存日志", command=self.save_log, width=8).pack(side=tk.LEFT, padx=1)

        self.auto_scroll = tk.BooleanVar(value=True)
        ttk.Checkbutton(log_control_frame, text="自动滚动", variable=self.auto_scroll).pack(side=tk.LEFT, padx=1)

        self.log_text = scrolledtext.ScrolledText(log_frame, height=12, wrap=tk.WORD, font=("Arial", 8))
        self.log_text.pack(fill=tk.BOTH, expand=True)

        # 初始化统计信息
        self.reset_stats()

    def reset_stats(self):
        """重置统计信息"""
        self.total_files_var.set("0")
        self.processed_files_var.set("0")
        self.success_files_var.set("0")
        self.failed_files_var.set("0")
        self.progress_bar['value'] = 0
        self.progress_percent_var.set("0%")
        self.current_task_label['text'] = "就绪"
        self.detailed_progress_var.set("等待开始...")

    def clear_log(self):
        """清空日志"""
        self.log_text.delete(1.0, tk.END)
        self.log("日志已清空")

    def save_log(self):
        """保存日志到文件"""
        file_path = filedialog.asksaveasfilename(
            title="保存日志文件",
            defaultextension=".txt",
            filetypes=[("Text files", "*.txt"), ("All files", "*.*")]
        )
        if file_path:
            try:
                with open(file_path, 'w', encoding='utf-8') as f:
                    log_content = self.log_text.get(1.0, tk.END)
                    f.write(log_content)
                self.log(f"日志已保存到: {file_path}")
            except Exception as e:
                messagebox.showerror("错误", f"保存日志失败: {str(e)}")

    # 批量自动识别结束行功能
    def batch_auto_detect_end_row(self):
        """批量自动识别所有文件的结束行"""
        valid_files = [fp for fp in self.file_configs.keys() if fp != "请添加文件"]
        if len(valid_files) == 0:
            messagebox.showwarning("警告", "请先添加文件配置")
            return

        if not IMPORT_SUCCESS:
            messagebox.showerror("错误", "无法导入自动识别函数，无法执行自动识别")
            return

        self.log("开始批量自动识别结束行...")
        self.reset_stats()
        self.current_task_label['text'] = "批量自动识别结束行"
        self.total_files_var.set(str(len(valid_files)))
        self.progress_bar['value'] = 0
        self.progress_percent_var.set("0%")

        self.processing = True
        self.paused = False
        self.stop_requested = False

        thread = threading.Thread(target=self.execute_batch_auto_detect, args=(valid_files,))
        thread.daemon = True
        thread.start()

    def execute_batch_auto_detect(self, valid_files):
        """执行批量自动识别"""
        try:
            file_count = len(valid_files)
            self.log(f"开始为 {file_count} 个文件自动识别结束行")

            # 实时更新进度
            self.update_progress(5, "开始识别...", "正在初始化识别环境")

            success_count = 0
            failed_count = 0

            for idx, file_path in enumerate(valid_files):
                # 检查暂停和停止
                if self.stop_requested:
                    self.log("自动识别被用户停止")
                    return
                while self.paused:
                    time.sleep(0.1)
                    if self.stop_requested:
                        self.log("自动识别被用户停止")
                        return

                # 更新进度
                progress = (idx / file_count) * 100
                self.update_progress(progress, f"识别文件中... ({idx+1}/{file_count})",
                                    f"正在处理: {os.path.basename(file_path)}")

                # 执行单个文件的自动识别
                try:
                    config = self.file_configs[file_path]
                    start_row = int(config['start_row'].get())

                    self.log(f"正在识别文件 {idx+1}/{file_count}: {os.path.basename(file_path)}")

                    # 使用文档1中的read_data函数进行自动识别
                    data = read_data(
                        file_path=file_path,
                        start_row=start_row,
                        start_col=3,  # 默认从第3列开始
                        end_col=5,  # 默认到第5列结束
                        auto_detect_end_row=True
                    )

                    # 计算结束行：起始行 + 数据行数 - 1
                    detected_end_row = start_row + len(data) - 1
                    config['auto_end_row'].set(str(detected_end_row))

                    self.log(f"✓ 文件 {os.path.basename(file_path)} 识别成功: 起始行={start_row}, 结束行={detected_end_row}, 数据行数={len(data)}")
                    success_count += 1

                except Exception as e:
                    error_msg = f"自动识别结束行失败: {str(e)}"
                    self.log(f"✗ 文件 {os.path.basename(file_path)} 识别失败: {error_msg}")
                    config['auto_end_row'].set("识别失败")
                    failed_count += 1

                # 更新统计信息
                self.processed_files_var.set(str(idx + 1))
                self.success_files_var.set(str(success_count))
                self.failed_files_var.set(str(failed_count))

            # 完成处理
            self.update_progress(100, "自动识别完成!", f"成功: {success_count}个, 失败: {failed_count}个")
            self.log(f"批量自动识别完成! 成功: {success_count}个文件, 失败: {failed_count}个文件")

            self.root.after(0, lambda: self.auto_detect_complete(success_count, failed_count))

        except Exception as e:
            error_msg = f"批量自动识别错误: {str(e)}"
            error_details = traceback.format_exc()
            self.log(f"错误详情: {error_details}")
            self.log(error_msg)
            self.root.after(0, lambda: self.auto_detect_error(error_msg))

    def auto_detect_complete(self, success_count, failed_count):
        """自动识别完成"""
        self.processing = False
        self.paused = False
        self.stop_requested = False
        messagebox.showinfo("完成",
                           f"批量自动识别完成!\n成功: {success_count}个文件\n失败: {failed_count}个文件")

    def auto_detect_error(self, error_msg):
        """自动识别错误"""
        self.processing = False
        self.paused = False
        self.stop_requested = False
        messagebox.showerror("错误", error_msg)

    # 文件合并相关方法
    def select_merge_files(self):
        """选择需要合并的文件"""
        file_paths = filedialog.askopenfilenames(
            title="选择需要合并的FX/FY/FZ文件",
            filetypes=[("Excel/CSV files", "*.xlsx *.xls *.csv"), ("All files", "*.*")]
        )

        if file_paths:
            for file_path in file_paths:
                if file_path not in self.merge_files_list:
                    self.merge_files_list.append(file_path)
                    self.merge_listbox.insert(tk.END, os.path.basename(file_path))
            self.log(f"已选择 {len(file_paths)} 个文件用于合并")

    def clear_merge_files(self):
        """清空合并文件列表"""
        self.merge_files_list.clear()
        self.merge_listbox.delete(0, tk.END)
        self.log("已清空合并文件列表")

    def select_merge_output_dir(self):
        """选择合并文件输出目录"""
        directory = filedialog.askdirectory(title="选择合并文件输出目录")
        if directory:
            self.merge_output_dir.set(directory)
            self.log(f"设置合并输出目录: {directory}")

    def execute_merge(self):
        """执行文件合并"""
        if not self.merge_files_list:
            messagebox.showwarning("警告", "请先选择需要合并的文件")
            return

        if len(self.merge_files_list) < 3:
            messagebox.showwarning("警告", "至少需要选择3个文件（FX/FY/FZ）进行合并")
            return

        # 在后台线程中执行合并
        self.log("开始文件合并...")
        self.reset_stats()
        self.current_task_label['text'] = "文件合并"
        self.progress_bar['value'] = 0
        self.progress_percent_var.set("0%")

        thread = threading.Thread(target=self._execute_merge_thread)
        thread.daemon = True
        thread.start()

    def _execute_merge_thread(self):
        """在后台线程中执行合并"""
        try:
            self.update_progress(10, "正在合并文件...", "正在分析文件结构")

            # 执行合并
            merged_files = merge_files_by_prefix(self.merge_files_list, self.merge_output_dir.get())

            self.update_progress(80, "合并完成，加载到界面...", "正在加载合并后的文件")

            # 将合并后的文件添加到UI界面
            for file_path in merged_files:
                if file_path not in self.file_configs:
                    # 创建新配置页
                    config = self.create_config_page(file_path)
                    # 添加到文件列表
                    self.file_listbox.insert(tk.END, file_path)
                    self.log(f"已添加合并文件: {file_path}")

            self.update_progress(100, "合并完成!", "文件合并操作已完成")
            self.log(f"文件合并完成，共生成 {len(merged_files)} 个合并文件")

            # 显示完成消息
            self.root.after(0, lambda: messagebox.showinfo("成功",
                                                           f"文件合并完成!\n共生成 {len(merged_files)} 个合并文件\n已自动加载到处理列表"))

        except Exception as e:
            error_msg = f"合并错误: {str(e)}"
            self.log(f"错误详情: {traceback.format_exc()}")
            self.log(error_msg)
            self.root.after(0, lambda: messagebox.showerror("错误", error_msg))
            self.update_progress(0, "合并失败", f"错误: {str(e)}")

    def create_config_page(self, file_path):
        """为单个文件创建配置页面"""
        frame = ttk.Frame(self.config_notebook, padding="3")

        # 文件路径显示
        path_frame = ttk.LabelFrame(frame, text="文件信息", padding="2")
        path_frame.pack(fill=tk.X, pady=1)

        ttk.Label(path_frame, text="文件路径:").pack(side=tk.LEFT)
        path_label = ttk.Label(path_frame, text=file_path, background="white",
                               relief="sunken", font=("Arial", 8))
        path_label.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=2)

        # 数据范围设置
        range_frame = ttk.LabelFrame(frame, text="数据范围设置", padding="2")
        range_frame.pack(fill=tk.X, pady=1)

        # 行设置 - 保留自动识别结束行的显示
        row_frame = ttk.Frame(range_frame)
        row_frame.pack(fill=tk.X, pady=1)

        start_row = tk.StringVar(value="9")
        # 结束行自动识别，初始显示为"未识别"
        auto_end_row = tk.StringVar(value="未识别")

        ttk.Label(row_frame, text="起始行:").pack(side=tk.LEFT, padx=2)
        ttk.Entry(row_frame, textvariable=start_row, width=8).pack(side=tk.LEFT, padx=1)
        ttk.Label(row_frame, text="结束行:").pack(side=tk.LEFT, padx=2)
        ttk.Label(row_frame, textvariable=auto_end_row, width=10,
                  background="lightgray").pack(side=tk.LEFT, padx=1)

        # 列设置
        col_frame = ttk.Frame(range_frame)
        col_frame.pack(fill=tk.X, pady=1)

        start_col = tk.StringVar(value="3")
        end_col = tk.StringVar(value="5")
        condition_col = tk.StringVar(value="2")

        ttk.Label(col_frame, text="起始列:").pack(side=tk.LEFT, padx=2)
        ttk.Entry(col_frame, textvariable=start_col, width=8).pack(side=tk.LEFT, padx=1)
        ttk.Label(col_frame, text="结束列:").pack(side=tk.LEFT, padx=2)
        ttk.Entry(col_frame, textvariable=end_col, width=8).pack(side=tk.LEFT, padx=1)
        ttk.Label(col_frame, text="时间列:").pack(side=tk.LEFT, padx=(10, 2))
        ttk.Entry(col_frame, textvariable=condition_col, width=8).pack(side=tk.LEFT, padx=1)

        # 输出设置
        output_frame = ttk.LabelFrame(frame, text="输出设置", padding="2")
        output_frame.pack(fill=tk.X, pady=1)

        output_subframe = ttk.Frame(output_frame)
        output_subframe.pack(fill=tk.X)

        output_var = tk.StringVar()
        ttk.Button(output_subframe, text="选择输出文件", width=10,
                   command=lambda: self.select_output_file(file_path, output_var)).pack(side=tk.LEFT, padx=2)
        output_label = ttk.Label(output_subframe, textvariable=output_var,
                                 background="white", relief="sunken", font=("Arial", 8))
        output_label.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=2)

        # 自动设置输出文件名
        if file_path != "请添加文件":
            base_name = os.path.splitext(file_path)[0]
            output_var.set(f"{base_name}_结果.xlsx")

        # 存储配置信息
        config_data = {
            'file_path': file_path,
            'start_row': start_row,
            'auto_end_row': auto_end_row,  # 自动识别的结束行
            'start_col': start_col,
            'end_col': end_col,
            'condition_col': condition_col,
            'output_file': output_var,
            'frame': frame,
            'path_label': path_label
        }

        if file_path not in self.file_configs:
            self.file_configs[file_path] = config_data

        # 添加到Notebook
        tab_name = os.path.basename(file_path) if file_path != "请添加文件" else file_path
        # 限制标签名称长度
        if len(tab_name) > 15:
            tab_name = tab_name[:12] + "..."
        self.config_notebook.add(frame, text=tab_name)

        return config_data

    def add_multiple_files(self):
        """添加多个文件"""
        file_paths = filedialog.askopenfilenames(
            title="选择多个Excel/CSV文件",
            filetypes=[("Excel/CSV files", "*.xlsx *.xls *.csv"), ("All files", "*.*")]
        )

        if file_paths:
            for file_path in file_paths:
                if file_path in self.file_configs:
                    self.log(f"跳过重复文件: {file_path}")
                    continue

                config = self.create_config_page(file_path)
                self.file_listbox.insert(tk.END, file_path)
                self.log(f"已添加文件: {file_path}")

            if file_paths:
                self.config_notebook.select(len(self.config_notebook.tabs()) - len(file_paths))
                self.file_listbox.selection_clear(0, tk.END)
                self.file_listbox.selection_set(0)

    def add_single_file(self):
        """添加单个文件"""
        file_path = filedialog.askopenfilename(
            title="选择Excel/CSV文件",
            filetypes=[("Excel/CSV files", "*.xlsx *.xls *.csv"), ("All files", "*.*")]
        )

        if file_path:
            if file_path in self.file_configs:
                messagebox.showinfo("提示", "该文件已存在配置中")
                return

            config = self.create_config_page(file_path)
            self.file_listbox.insert(tk.END, file_path)
            self.config_notebook.select(len(self.config_notebook.tabs()) - 1)
            self.file_listbox.selection_clear(0, tk.END)
            self.file_listbox.selection_set(tk.END)
            self.log(f"已添加文件: {file_path}")

    def remove_current_file(self):
        """删除当前选中的文件配置"""
        if not self.file_configs:
            return

        current_tab = self.config_notebook.select()
        if not current_tab:
            return

        tab_index = self.config_notebook.index(current_tab)
        tab_text = self.config_notebook.tab(current_tab, "text")

        for file_path, config in list(self.file_configs.items()):
            if config['frame'] == self.config_notebook.nametowidget(current_tab):
                del self.file_configs[file_path]
                break

        self.config_notebook.forget(current_tab)

        for i in range(self.file_listbox.size()):
            if self.file_listbox.get(i) in tab_text:
                self.file_listbox.delete(i)
                break

        self.log(f"已删除文件配置: {tab_text}")

        if len(self.file_configs) == 0:
            self.create_config_page("请添加文件")

    def clear_all_files(self):
        """清空所有文件配置"""
        if not messagebox.askyesno("确认", "确定要清空所有文件配置吗？"):
            return

        self.file_configs.clear()
        for tab in self.config_notebook.tabs():
            self.config_notebook.forget(tab)

        self.file_listbox.delete(0, tk.END)
        self.create_config_page("请添加文件")
        self.log("已清空所有文件配置")

    def on_file_select(self, event):
        """文件列表选择事件"""
        selection = self.file_listbox.curselection()
        if selection:
            file_path = self.file_listbox.get(selection[0])
            for file_path_key, config in self.file_configs.items():
                if file_path_key == file_path:
                    tab_index = self.config_notebook.index(config['frame'])
                    self.config_notebook.select(tab_index)
                    break

    def select_output_file(self, file_path, output_var):
        """选择输出文件"""
        if file_path == "请添加文件":
            messagebox.showwarning("警告", "请先添加文件")
            return

        output_path = filedialog.asksaveasfilename(
            title="选择输出文件",
            defaultextension=".xlsx",
            filetypes=[("Excel files", "*.xlsx"), ("All files", "*.*")]
        )

        if output_path:
            output_var.set(output_path)
            self.log(f"设置输出文件: {output_path}")

    # 暂停/继续/停止功能
    def pause_process(self):
        """暂停处理"""
        if self.processing and not self.paused:
            self.paused = True
            self.log("处理已暂停")
            self.current_task_label['text'] = "已暂停"

    def resume_process(self):
        """继续处理"""
        if self.paused:
            self.paused = False
            self.log("处理已继续")
            self.current_task_label['text'] = "继续处理中..."

    def stop_process(self):
        """停止处理"""
        if self.processing:
            self.stop_requested = True
            if self.paused:
                self.paused = False  # 如果暂停中，先恢复再停止
            self.log("处理停止请求已发送")

    def batch_process(self):
        """批量处理所有文件"""
        valid_files = [fp for fp in self.file_configs.keys() if fp != "请添加文件"]
        if len(valid_files) == 0:
            messagebox.showwarning("警告", "请先添加文件配置")
            return

        if not IMPORT_SUCCESS:
            messagebox.showerror("错误", "无法导入文档1中的函数，无法执行批量处理")
            return

        # 检查每个文件的结束行是否已自动识别
        for file_path, config in self.file_configs.items():
            if file_path == "请添加文件":
                continue

            end_row_value = config['auto_end_row'].get()
            if end_row_value == "未识别" or end_row_value == "识别失败" or not end_row_value.isdigit():
                if not messagebox.askyesno("确认",
                                           f"文件 {os.path.basename(file_path)} 的结束行未识别或识别失败。\n是否继续处理？"):
                    return

        files_config = {}
        for file_path, config in self.file_configs.items():
            if file_path == "请添加文件":
                continue

            # 使用自动识别的结束行，如果未识别则使用默认值
            end_row = config['auto_end_row'].get()
            if end_row == "未识别" or end_row == "识别失败" or not end_row.isdigit():
                end_row = "10248"  # 默认值

            files_config[file_path] = {
                'excel_range': (
                    int(config['start_row'].get()),
                    int(end_row),
                    int(config['start_col'].get()),
                    int(config['end_col'].get())
                ),
                'condition_col': int(config['condition_col'].get()),
                'angle_data': [
                    [float(self.global_angles[0].get()), float(self.global_angles[1].get()),
                     float(self.global_angles[2].get())],
                    [float(self.global_angles[3].get()), float(self.global_angles[4].get()),
                     float(self.global_angles[5].get())],
                    [float(self.global_angles[6].get()), float(self.global_angles[7].get()),
                     float(self.global_angles[8].get())]
                ],
                'projection_areas': (
                    float(self.global_proj_a.get()),
                    float(self.global_proj_b.get()),
                    float(self.global_proj_c.get())
                ),
                'output_file': config['output_file'].get()
            }

        if not files_config:
            messagebox.showwarning("警告", "没有有效的文件配置")
            return

        self.log("开始批量处理...")
        self.reset_stats()
        self.current_task_label['text'] = "批量处理文件"
        self.total_files_var.set(str(len(files_config)))
        self.progress_bar['value'] = 0
        self.progress_percent_var.set("0%")

        self.processing = True
        self.paused = False
        self.stop_requested = False

        thread = threading.Thread(target=self.execute_batch_process, args=(files_config,))
        thread.daemon = True
        thread.start()

    def execute_batch_process(self, files_config):
        """执行批量处理"""
        try:
            file_count = len(files_config)
            self.log(f"开始处理 {file_count} 个文件")
            self.log("=" * 50)

            # 实时更新进度
            self.update_progress(5, "开始处理...", "正在初始化处理环境")

            # 检查暂停和停止
            if self.stop_requested:
                self.log("处理被用户停止")
                return
            while self.paused:
                time.sleep(0.1)
                if self.stop_requested:
                    self.log("处理被用户停止")
                    return

            output_dir = os.path.dirname(next(iter(files_config.keys())))
            combined_output = os.path.join(output_dir, "所有结果汇总.xlsx")

            self.update_progress(10, "处理文件中...", "正在读取文件数据")

            # 检查暂停和停止
            if self.stop_requested:
                self.log("处理被用户停止")
                return
            while self.paused:
                time.sleep(0.1)
                if self.stop_requested:
                    self.log("处理被用户停止")
                    return

            # 改为逐个文件处理，以便显示详细进度
            results = {}
            success_count = 0
            failed_count = 0

            for idx, (file_path, config) in enumerate(files_config.items()):
                # 检查暂停和停止
                if self.stop_requested:
                    self.log("处理被用户停止")
                    break
                while self.paused:
                    time.sleep(0.1)
                    if self.stop_requested:
                        self.log("处理被用户停止")
                        break

                # 更新进度
                progress = 10 + (idx / file_count) * 75  # 10%到85%之间
                self.update_progress(progress, f"处理文件中... ({idx + 1}/{file_count})",
                                     f"正在处理: {os.path.basename(file_path)}")

                # 记录开始处理当前文件
                self.log(f"【文件 {idx + 1}/{file_count}】开始处理: {os.path.basename(file_path)}")
                self.log(f"   - 文件路径: {file_path}")
                self.log(f"   - 数据范围: 行{config['excel_range'][0]}-{config['excel_range'][1]}, "
                         f"列{config['excel_range'][2]}-{config['excel_range'][3]}")
                self.log(f"   - 时间列: {config['condition_col']}")
                self.log(f"   - 输出文件: {config['output_file']}")

                try:
                    # 处理单个文件
                    start_time = time.time()

                    # 这里调用实际的单个文件处理函数
                    # 由于原代码使用batch_process_files，我们需要模拟单个文件处理
                    # 实际使用时需要根据你的具体函数进行调整
                    result = self.process_single_file(file_path, config)

                    end_time = time.time()
                    processing_time = end_time - start_time

                    if 'error' in result:
                        self.log(f"✗✗【文件 {idx + 1}/{file_count}】处理失败: {result['error']}")
                        self.log(f"   处理时间: {processing_time:.2f}秒")
                        results[file_path] = result
                        failed_count += 1
                    else:
                        self.log(f"✓✓【文件 {idx + 1}/{file_count}】处理成功")
                        self.log(f"   输出文件: {result.get('saved_file', '未知')}")
                        self.log(f"   处理时间: {processing_time:.2f}秒")
                        results[file_path] = result
                        success_count += 1

                except Exception as e:
                    error_msg = f"处理文件时发生异常: {str(e)}"
                    self.log(f"✗✗【文件 {idx + 1}/{file_count}】处理异常: {error_msg}")
                    self.log(f"   异常详情: {traceback.format_exc()}")
                    results[file_path] = {'error': error_msg}
                    failed_count += 1

                # 更新统计信息
                self.processed_files_var.set(str(idx + 1))
                self.success_files_var.set(str(success_count))
                self.failed_files_var.set(str(failed_count))

                # 添加文件间的分隔线
                if idx < file_count - 1:
                    self.log("-" * 40)

            self.update_progress(85, "处理完成，整理结果...", "正在生成汇总报告")

            # 检查暂停和停止
            if self.stop_requested:
                self.log("处理被用户停止")
                return
            while self.paused:
                time.sleep(0.1)
                if self.stop_requested:
                    self.log("处理被用户停止")
                    return

            # 保存汇总结果
            summary_file = os.path.join(output_dir, "处理汇总.txt")
            try:
                # 这里调用保存汇总结果的函数
                save_batch_results(results, summary_file)
                self.log(f"汇总文件已保存: {summary_file}")
            except Exception as e:
                self.log(f"保存汇总文件失败: {str(e)}")

            self.log("\n" + "=" * 50)
            self.log("批量处理完成摘要:")
            self.log("=" * 50)
            self.log(f"总文件数: {file_count}")
            self.log(f"成功处理: {success_count}")
            self.log(f"处理失败: {failed_count}")

            if success_count > 0:
                self.log(f"成功率: {success_count / file_count * 100:.1f}%")

            self.log("=" * 50)

            self.update_progress(100, "批量处理完成", "所有文件处理已完成")
            self.log(f"批量处理完成！汇总文件: {combined_output}")

            self.root.after(0, lambda: self.process_complete(combined_output, success_count, failed_count))

        except Exception as e:
            error_msg = f"处理错误: {str(e)}"
            error_details = traceback.format_exc()
            self.log(f"错误详情: {error_details}")
            self.log(error_msg)
            self.root.after(0, lambda: self.process_error(error_msg))

    def process_single_file(self, file_path, config):
        """处理单个文件"""
        try:
            # 这里需要根据你的实际处理函数来调用
            # 假设我们有一个处理单个文件的函数
            # 你需要根据实际情况调整这个函数调用

            # 示例调用（需要根据你的实际函数调整）：
            result = integrated_full_process(
                file_path=file_path,
                excel_range=config['excel_range'],
                condition_col=config['condition_col'],
                angle_data=config['angle_data'],
                projection_areas=config['projection_areas'],
                output_file=config['output_file']
            )

            return result

        except Exception as e:
            return {'error': str(e)}

    def update_progress(self, value, status, detail=""):
        """更新进度条"""

        def update():
            self.progress_bar['value'] = value
            self.progress_percent_var.set(f"{int(value)}%")
            self.current_task_label['text'] = status
            if detail:
                self.detailed_progress_var.set(detail)
            self.root.update_idletasks()

        self.root.after(0, update)

    def process_complete(self, output_file, success_count, failed_count):
        """处理完成"""
        self.processing = False
        self.paused = False
        self.stop_requested = False
        self.update_progress(100, "完成!", f"成功: {success_count}个, 失败: {failed_count}个")
        messagebox.showinfo("成功",
                            f"批量处理完成!\n成功: {success_count}个文件\n失败: {failed_count}个文件\n汇总文件: {output_file}")

    def process_error(self, error_msg):
        """处理错误"""
        self.processing = False
        self.paused = False
        self.stop_requested = False
        self.update_progress(0, "错误", f"处理过程中出现错误")
        messagebox.showerror("错误", error_msg)

    def log(self, message):
        """添加日志"""

        def add_log():
            timestamp = time.strftime("%H:%M:%S")
            self.log_text.insert(tk.END, f"[{timestamp}] {message}\n")
            if self.auto_scroll.get():
                self.log_text.see(tk.END)
            self.root.update_idletasks()

        self.root.after(0, add_log)


def main():
    """主函数（由主界面调用）"""
    win = tk.Toplevel()
    app = MultiFileConfigUI(win)


if __name__ == "__main__":
    main()
