import pandas as pd
import math
from typing import List, Union, Optional, Tuple, Dict
import numpy as np
import os
import tempfile


def read_data(
        file_path: str,
        start_row: int,
        start_col: int,
        end_col: int,
        end_row: Optional[int] = None,
        sheet_name: Union[str, int] = 0,
        header: Optional[int] = None,
        auto_detect_end_row: bool = False
) -> List[List[Union[float, int, str]]]:
    """
    统一数据读取函数（增强版）
    """
    # 标准化路径 + 检查文件存在性
    file_path = os.path.normpath(file_path)
    if not os.path.exists(file_path):
        raise FileNotFoundError(f"文件不存在: {file_path}")

    print(f"读取文件: {file_path}")

    # 如果启用自动识别结束行功能
    if auto_detect_end_row:
        print("启用自动识别结束行功能")
        data, file_info = read_data_with_auto_end_row(
            file_path=file_path,
            start_col=start_col,
            end_col=end_col,
            start_row=start_row,
            sheet_name=sheet_name,
            header=header
        )

        # 打印详细的识别结果
        print_detailed_identification_info(file_info, data)
        return data

    # 原有的读取逻辑（手动指定结束行）
    print("使用传统模式（手动指定结束行）")

    # 检查是否提供了结束行
    if end_row is None:
        raise ValueError("传统模式下必须提供 end_row 参数")

    return read_data_auto_convert(file_path, start_row, end_row, start_col, end_col, sheet_name, header)


def print_detailed_identification_info(file_info: Dict, data: List[List]):
    """
    打印详细的识别信息，包括识别的数据和行号
    """
    print("\n" + "=" * 80)
    print("自动识别结果详细信息")
    print("=" * 80)

    print(f"文件信息:")
    print(f"  原始文件: {file_info['original_file']}")
    print(f"  转换后文件: {file_info['converted_file']}")
    print(f"  是否转换: {'是' if file_info['is_converted'] else '否'}")

    print(f"\n行列范围信息:")
    print(f"  用户输入起始行: {file_info['original_start_row']}")
    print(f"  起始列-结束列: {file_info['start_col']}-{file_info['end_col']}")

    if file_info.get('is_converted'):
        print(f"  注释行数: {file_info['comment_lines']}")
        print(f"  调整后起始行: {file_info['adjusted_start_row']}")

    print(f"  自动识别结束行: {file_info['end_row']}")

    print(f"\n数据统计:")
    print(f"  读取的总行数: {len(data)}")
    print(
        f"  实际数据范围: 第{file_info.get('adjusted_start_row', file_info['original_start_row'])}行到第{file_info['end_row']}行")

    # 显示识别的具体数据内容
    if print(f"\n识别的数据内容预览:"):
        print(f"  (显示前10行和后5行数据)")

        # 显示前10行数据
        display_start = min(10, len(data))
        for i in range(display_start):
            actual_row = file_info.get('adjusted_start_row', file_info['original_start_row']) + i
            row_data = data[i]
            # 简化显示，避免过长输出
            simplified_data = []
            for x in row_data:
                if x is None:
                    simplified_data.append("None")
                elif isinstance(x, (int, float)):
                    simplified_data.append(f"{x:.2f}")
                else:
                    str_x = str(x)
                    if len(str_x) > 20:
                        simplified_data.append(str_x[:20] + "...")
                    else:
                        simplified_data.append(str_x)
            print(f"  第{actual_row}行: {simplified_data}")

        # 显示后5行数据（如果有更多行）
        if len(data) > 15:
            print(f"  ... (中间省略 {len(data) - 15} 行) ...")
            for i in range(max(10, len(data) - 5), len(data)):
                actual_row = file_info.get('adjusted_start_row', file_info['original_start_row']) + i
                row_data = data[i]
                simplified_data = []
                for x in row_data:
                    if x is None:
                        simplified_data.append("None")
                    elif isinstance(x, (int, float)):
                        simplified_data.append(f"{x:.2f}")
                    else:
                        str_x = str(x)
                        if len(str_x) > 20:
                            simplified_data.append(str_x[:20] + "...")
                        else:
                            simplified_data.append(str_x)
                print(f"  第{actual_row}行: {simplified_data}")

        # 显示数据统计信息
        print(f"\n数据统计详情:")
        non_null_counts = []
        for i, row in enumerate(data):
            non_null_count = sum(1 for x in row if x is not None)
            non_null_counts.append(non_null_count)

        print(f"  每行非空值数量: {non_null_counts}")
        print(f"  总非空值数量: {sum(non_null_counts)}")
        print(f"  平均每行非空值: {sum(non_null_counts) / len(non_null_counts):.2f}")

    print("=" * 80)


def read_data_with_auto_end_row(
        file_path: str,
        start_col: int,
        end_col: int,
        start_row: int = 1,
        sheet_name: Union[str, int] = 0,
        header: Optional[int] = None
) -> Tuple[List[List[Union[float, int, str]]], Dict[str, Union[str, int]]]:
    """
    自动识别结束行并读取数据的完整函数
    """
    print("=== 开始自动识别结束行并读取数据 ===")

    # 标准化路径 + 检查文件存在性
    file_path = os.path.normpath(file_path)
    if not os.path.exists(file_path):
        raise FileNotFoundError(f"文件不存在: {file_path}")

    # 提取扩展名
    file_extension = os.path.splitext(file_path)[1].lower()

    # 文件信息结果
    file_info = {
        'original_file': file_path,
        'converted_file': file_path,
        'original_start_row': start_row,
        'adjusted_start_row': start_row,
        'end_row': -1,
        'start_col': start_col,
        'end_col': end_col,
        'is_converted': False,
        'comment_lines': 0
    }

    try:
        # CSV文件：先转换再识别结束行
        if file_extension == '.csv':
            print("检测到CSV文件，正在转换为XLSX格式...")

            # 创建临时XLSX文件
            with tempfile.NamedTemporaryFile(suffix='.xlsx', delete=False) as temp_file:
                temp_xlsx_path = temp_file.name

            try:
                # 第一步：读取CSV文件并计算注释行
                print("第一步：读取CSV文件并计算注释行")
                with open(file_path, 'r', encoding='utf-8') as f:
                    lines = f.readlines()

                comment_lines = sum(1 for line in lines if line.strip().startswith('#'))
                file_info['comment_lines'] = comment_lines
                print(f"检测到 {comment_lines} 行注释")

                # 第二步：读取CSV数据（跳过注释行）
                df = pd.read_csv(file_path, comment='#', header=None)
                print(f"CSV文件读取成功，数据形状: {df.shape}")

                # 第三步：保存为临时XLSX文件
                df.to_excel(temp_xlsx_path, index=False, header=False)
                print(f"已创建临时XLSX文件: {temp_xlsx_path}")

                # 第四步：计算调整后的行号
                adjusted_start_row = max(1, start_row - comment_lines)
                file_info['adjusted_start_row'] = adjusted_start_row
                print(f"调整行号: {start_row} -> {adjusted_start_row} (减去{comment_lines}行注释)")

                # 第五步：在转换后的XLSX文件中识别结束行
                end_row, debug_info = find_end_row_in_xlsx_debug(temp_xlsx_path, start_col, end_col, adjusted_start_row,
                                                                 sheet_name)

                file_info['converted_file'] = temp_xlsx_path
                file_info['is_converted'] = True
                file_info['end_row'] = end_row
                file_info['debug_info'] = debug_info  # 保存调试信息

                print(f"CSV文件处理完成: 原始起始行={start_row}, 调整后起始行={adjusted_start_row}, 结束行={end_row}")

            except Exception as e:
                if os.path.exists(temp_xlsx_path):
                    os.unlink(temp_xlsx_path)
                raise e

        # Excel文件：直接识别结束行
        elif file_extension in ['.xlsx', '.xls']:
            print("检测到Excel文件，直接识别结束行...")

            # 直接识别结束行
            end_row, debug_info = find_end_row_in_xlsx_debug(file_path, start_col, end_col, start_row, sheet_name)

            file_info['converted_file'] = file_path
            file_info['is_converted'] = False
            file_info['end_row'] = end_row
            file_info['adjusted_start_row'] = start_row
            file_info['debug_info'] = debug_info

        else:
            raise ValueError(f"不支持的文件格式: {file_extension}")

        # 第二步：使用识别出的范围读取数据
        print("=== 开始读取数据 ===")
        if file_info['is_converted']:
            data = read_excel_data(
                file_path=file_info['converted_file'],
                start_row=file_info['adjusted_start_row'],
                end_row=file_info['end_row'],
                start_col=file_info['start_col'],
                end_col=file_info['end_col'],
                sheet_name=sheet_name,
                header=header
            )
        else:
            data = read_excel_data(
                file_path=file_info['converted_file'],
                start_row=file_info['original_start_row'],
                end_row=file_info['end_row'],
                start_col=file_info['start_col'],
                end_col=file_info['end_col'],
                sheet_name=sheet_name,
                header=header
            )

        print(f"读取完成: 共{len(data)}行数据")
        return data, file_info

    except Exception as e:
        raise Exception(f"自动识别结束行并读取数据时出错: {str(e)}")

    finally:
        if file_info.get('is_converted') and os.path.exists(file_info.get('converted_file', '')):
            os.unlink(file_info['converted_file'])
            print("临时文件已清理")


def find_end_row_in_xlsx_debug(
        xlsx_path: str,
        start_col: int,
        end_col: int,
        start_row: int,
        sheet_name: Union[str, int] = 0
) -> Tuple[int, List[Dict]]:
    """
    在XLSX文件中查找结束行（带调试信息）

    返回结束行和详细的检查信息
    """
    debug_info = []

    try:
        # 读取Excel文件
        df = pd.read_excel(xlsx_path, sheet_name=sheet_name, header=None)
        print(f"Excel文件读取成功，数据形状: {df.shape}")

        # 转换为0-based索引
        start_row_idx = start_row - 1
        start_col_idx = start_col - 1
        end_col_idx = end_col - 1

        # 验证列范围
        if start_col_idx < 0 or end_col_idx >= len(df.columns) or start_col_idx > end_col_idx:
            raise ValueError(f"列范围无效: {start_col}-{end_col}")

        # 验证起始行
        if start_row_idx < 0 or start_row_idx >= len(df):
            raise ValueError(f"起始行无效: {start_row}")

        # 选择指定的列范围
        df_selected = df.iloc[start_row_idx:, start_col_idx:end_col_idx + 1]
        print(f"选择的列范围数据形状: {df_selected.shape}")

        # 从起始行开始向下检查
        found_empty_row = False
        end_row = start_row

        for i in range(len(df_selected)):
            actual_row_number = i + start_row
            row = df_selected.iloc[i]

            # 获取该行在指定列范围内的实际数据
            row_data = []
            for col_idx in range(start_col_idx, end_col_idx + 1):
                value = df.iloc[start_row_idx + i, col_idx]
                row_data.append(value if not pd.isna(value) else None)

            # 检查该行是否全部为空
            is_all_null = row.isnull().all()

            # 记录调试信息
            debug_info.append({
                'row_number': actual_row_number,
                'data': row_data,
                'is_all_null': is_all_null,
                'non_null_count': sum(1 for x in row_data if x is not None)
            })

            print(f"检查第{actual_row_number}行: 数据={row_data}, 是否全空={is_all_null}")

            if is_all_null:
                found_empty_row = True
                if i == 0:
                    end_row = start_row - 1 if start_row > 1 else 1
                    print(f"第{actual_row_number}行就是空行，数据结束行: {end_row}")
                else:
                    end_row = actual_row_number - 1
                    print(f"在第{actual_row_number}行发现空行，数据结束行: {end_row}")
                break

        # 如果所有行都有数据，返回最后一行
        if not found_empty_row:
            end_row = len(df_selected) + start_row - 1
            print(f"所有行在指定列范围内都有数据，返回最后一行: {end_row}")

        # 打印检查统计
        print(f"\n检查统计:")
        print(f"  总共检查了 {len(debug_info)} 行")
        print(f"  有空行: {any(info['is_all_null'] for info in debug_info)}")
        print(f"  平均每行非空值: {sum(info['non_null_count'] for info in debug_info) / len(debug_info):.2f}")

        return end_row, debug_info

    except Exception as e:
        raise Exception(f"在XLSX文件中查找结束行时出错: {str(e)}")


def read_data_auto_convert(
        file_path: str,
        start_row: int,
        end_row: int,
        start_col: int,
        end_col: int,
        sheet_name: Union[str, int] = 0,
        header: Optional[int] = None,
        delete_temp_file: bool = True
) -> List[List[Union[float, int, str]]]:
    """
    自动读取数据文件
    """
    file_path = os.path.normpath(file_path)
    if not os.path.exists(file_path):
        raise FileNotFoundError(f"文件不存在: {file_path}")

    file_extension = os.path.splitext(file_path)[1].lower()

    if file_extension in ['.xlsx', '.xls']:
        return read_excel_data(file_path, start_row, end_row, start_col, end_col, sheet_name, header)

    elif file_extension == '.csv':
        with tempfile.NamedTemporaryFile(suffix='.xlsx', delete=False) as temp_file:
            temp_xlsx_path = temp_file.name

        try:
            print("检测到CSV文件，正在转换为XLSX格式...")
            df = pd.read_csv(file_path, comment='#')
            df.to_excel(temp_xlsx_path, index=False, header=header is not None)
            print(f"已创建临时XLSX文件: {temp_xlsx_path}")

            with open(file_path, 'r', encoding='utf-8') as f:
                lines = f.readlines()
            comment_lines = sum(1 for line in lines if line.strip().startswith('#'))
            print(f"检测到 {comment_lines} 行注释")

            adjusted_start_row = max(1, start_row - comment_lines)
            adjusted_end_row = max(1, end_row - comment_lines)

            if adjusted_start_row > adjusted_end_row:
                raise ValueError("调整行号后起始行大于结束行")

            print(f"调整行号: {start_row}-{end_row} -> {adjusted_start_row}-{adjusted_end_row}")

            result = read_excel_data(temp_xlsx_path, adjusted_start_row, adjusted_end_row,
                                     start_col, end_col, sheet_name, header)
            return result

        finally:
            if delete_temp_file and os.path.exists(temp_xlsx_path):
                os.unlink(temp_xlsx_path)
                print("临时文件已清理")
    else:
        raise ValueError(f"不支持的文件格式: {file_extension}")


def read_excel_data(
        file_path: str,
        start_row: int,
        end_row: int,
        start_col: int,
        end_col: int,
        sheet_name: Union[str, int] = 0,
        header: Optional[int] = None
) -> List[List[Union[float, int, str]]]:
    """
    读取Excel文件中指定行和列范围的数据
    """
    file_path = os.path.normpath(file_path)
    if not os.path.exists(file_path):
        raise FileNotFoundError(f"文件未找到: {file_path}")

    try:
        df = pd.read_excel(file_path, sheet_name=sheet_name, header=header)

        start_row_idx = start_row - 1
        end_row_idx = end_row - 1
        start_col_idx = start_col - 1
        end_col_idx = end_col - 1

        if start_row_idx < 0 or end_row_idx >= len(df) or start_row_idx > end_row_idx:
            raise ValueError(f"行范围无效: {start_row}-{end_row}")

        if start_col_idx < 0 or end_col_idx >= len(df.columns) or start_col_idx > end_col_idx:
            raise ValueError(f"列范围无效: {start_col}-{end_col}")

        all_data = []
        for row_idx in range(start_row_idx, end_row_idx + 1):
            row_data = []
            for col_idx in range(start_col_idx, end_col_idx + 1):
                value = df.iloc[row_idx, col_idx]
                row_data.append(value if not pd.isna(value) else None)
            all_data.append(row_data)

        print(f"成功读取 {len(all_data)} 行数据 (第{start_row}行到第{end_row}行)")
        return all_data

    except Exception as e:
        raise Exception(f"读取Excel文件时出错: {str(e)}")


# 使用示例
if __name__ == "__main__":
    csv_path = r"E:\项目二22222222222222222\代码\项目三\RSP\测试2\222123123213.csv"

    try:
        print("=== 测试自动识别结束行功能 ===")
        result = read_data(
            file_path=csv_path,
            start_row=9,
            start_col=3,
            end_col=5,
            auto_detect_end_row=True
        )
        print(f"读取到 {len(result)} 行数据")

    except Exception as e:
        print(f"执行出错: {str(e)}")
        import traceback

        traceback.print_exc()