# -*- mode: python ; coding: utf-8 -*-


a = Analysis(
    ['QI7.py'],
    pathex=[],
    binaries=[],
    datas=[('E:\\项目二22222222222222222\\代码\\主界面优化（最终版1）\\7.ico', '.')],
    hiddenimports=[],
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=['matplotlib', 'scipy', 'unittest', 'pytest', 'test', 'doctest', 'pip', 'wheel'],
    noarchive=False,
    optimize=0,
)
pyz = PYZ(a.pure)

exe = EXE(
    pyz,
    a.scripts,
    [],
    exclude_binaries=True,
    name='QI7',
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=True,
    console=False,
    disable_windowed_traceback=False,
    argv_emulation=False,
    target_arch=None,
    codesign_identity=None,
    entitlements_file=None,
    icon=['E:\\项目二22222222222222222\\代码\\主界面优化（最终版1）\\7.ico'],
)
coll = COLLECT(
    exe,
    a.binaries,
    a.datas,
    strip=False,
    upx=True,
    upx_exclude=[],
    name='QI7',
)
