import hashlib
import wmi
import json


def get_motherboard_serial():
    """读取Windows设备的主板序列号"""
    try:
        c = wmi.WMI()
        for board in c.Win32_BaseBoard():
            serial = board.SerialNumber.strip()
            if serial:
                return serial
        return ""
    except Exception as e:
        print(f"读取主板序列号失败：{e}")
        return ""

import wmi

def get_cpu_serial():
    """读取Windows设备的CPU序列号"""
    try:
        c = wmi.WMI()
        for cpu in c.Win32_Processor():
            serial = cpu.ProcessorId.strip()
            if serial:
                return serial
        return ""
    except Exception as e:
        print(f"读取CPU序列号失败：{e}")
        return ""

def get_disk_serial():
    """读取Windows设备的硬盘序列号（返回第一个硬盘的序列号）"""
    try:
        c = wmi.WMI()
        for disk in c.Win32_DiskDrive():
            serial = disk.SerialNumber.strip()
            if serial:
                return serial
        return ""
    except Exception as e:
        print(f"读取硬盘序列号失败：{e}")
        return ""


def get_device_fingerprint():
    """
    生成一个复合设备标识符（指纹）
    返回值格式：CPU序列号-硬盘序列号-主板序列号（经过SHA-256哈希处理）
    """
    try:
        cpu_serial = get_cpu_serial()
        disk_serial = get_disk_serial()
        motherboard_serial = get_motherboard_serial() # 您原有的函数

        # 组合关键信息
        combined_info = f"{cpu_serial}-{disk_serial}-{motherboard_serial}"

        # # 导入hashlib用于生成哈希值，确保指纹长度固定且不直接暴露原始信息
        # import hashlib
        # device_fingerprint = hashlib.sha256(combined_info.encode()).hexdigest()
        return combined_info
    except Exception as e:
        print(f"生成设备指纹失败：{e}")
        return ""




def encrypt_serial(serial, rule_config):
    """
    按规则对主板序列号加密，生成密钥
    :param serial: 主板序列号
    :param rule_config: 加密规则配置（字典），包含：
        - to_upper: bool，是否转大写
        - hash_type: str，哈希类型（md5/sha256）
        - hash_length: int，哈希结果截取长度
        - shift: int，字符ASCII码移位位数
        - reverse: bool，是否反转最终字符串
    :return: 加密后的密钥
    """
    if not serial:
        return ""

    # 步骤1：转大写（可选）
    if rule_config.get("to_upper", True):
        serial = serial.upper()

    # 步骤2：哈希运算
    hash_func = hashlib.md5() if rule_config.get("hash_type") == "md5" else hashlib.sha256()
    hash_func.update(serial.encode("utf-8"))
    hash_result = hash_func.hexdigest()

    # 步骤3：截取哈希结果
    hash_length = rule_config.get("hash_length", 16)
    hash_cut = hash_result[:hash_length]

    # 步骤4：ASCII码移位
    shift = rule_config.get("shift", 5)
    shift_result = []
    for char in hash_cut:
        new_ascii = ord(char) + shift
        # 限制ASCII范围在可打印字符（32-126）
        new_ascii = new_ascii if new_ascii <= 126 else new_ascii - 94
        shift_result.append(chr(new_ascii))
    shift_str = "".join(shift_result)

    # 步骤5：反转字符串（可选）
    if rule_config.get("reverse", True):
        final_key = shift_str[::-1]
    else:
        final_key = shift_str

    return final_key


def save_rule_config(config, file_path="rule_config.json"):
    """保存加密规则到JSON文件"""
    with open(file_path, "w", encoding="utf-8") as f:
        json.dump(config, f, ensure_ascii=False, indent=4)


def load_rule_config(file_path="rule_config.json"):
    """加载加密规则配置"""
    try:
        with open(file_path, "r", encoding="utf-8") as f:
            return json.load(f)
    except FileNotFoundError:
        # 默认规则
        return {
            "to_upper": True,
            "hash_type": "sha256",
            "hash_length": 16,
            "shift": 5,
            "reverse": True
        }