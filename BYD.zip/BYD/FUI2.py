import os
from tkinter import ttk, filedialog, messagebox, scrolledtext
import threading
import time
import tkinter as tk
from tkinter import messagebox

import sys

# 添加当前目录到路径，以便导入文档1中的函数
sys.path.append(os.path.dirname(os.path.abspath(__file__)))


# 按需导入文档1中的函数
def import_necessary_functions():
    """按需导入文档1中的必要函数"""
    try:
        # 导入核心处理函数
        from F2 import (
            read_excel_data,
            input_angles_batch,
            integrated_sum_process,
            gongkuang,
            save_excel_range,
            load_excel_range,
            save_results_to_excel,
            display_sum_results
        )
        return {
            'read_excel_data': read_excel_data,
            'input_angles_batch': input_angles_batch,
            'integrated_sum_process': integrated_sum_process,
            'gongkuang': gongkuang,
            'save_excel_range': save_excel_range,
            'load_excel_range': load_excel_range,
            'save_results_to_excel': save_results_to_excel,
            'display_sum_results': display_sum_results
        }
    except ImportError as e:
        print(f"导入错误: {e}")
        return None


def main():
    """主函数 - 修改为适配集成环境"""
    print("启动整车转局部(L)系统...")

    # 延迟导入函数
    imported_funcs = import_necessary_functions()
    if imported_funcs is None:
        messagebox.showerror("错误", "无法导入必要的函数库")
        return

    class ExcelDataProcessorUI:
        def __init__(self, root):
            self.root = root  # 先保存root引用

            self.root.title("整车转局部(L)")
            self.root.geometry("1000x800")

            # 设置你自己的图片作为程序图标
            self.set_custom_icon("7.ico")  # 替换为你的图片路径

            # 存储变量
            self.file_path = tk.StringVar()
            self.start_row = tk.StringVar(value="2")
            self.end_row = tk.StringVar(value="100")
            self.start_col = tk.StringVar(value="1")
            self.end_col = tk.StringVar(value="10")
            self.condition_row = tk.StringVar(value="1")  # 工况名称行

            # 角度数据变量 - 3组，每组3个角度
            self.angle_groups = []
            for i in range(3):  # 3组角度
                group_vars = []
                for j in range(3):  # 每组3个角度
                    group_vars.append(tk.StringVar(value="0.0"))
                self.angle_groups.append(group_vars)

            # 输出文件路径
            self.output_file = tk.StringVar()

            # 处理状态
            self.processing = False
            self.current_result = None

            self.create_widgets()

        def set_custom_icon(self, image_path):
            """设置自定义图片作为程序图标"""
            try:
                # 检查图片文件是否存在
                if not os.path.exists(image_path):
                    print(f"警告: 图片文件不存在: {image_path}")
                    return

                # 使用PIL库处理图片（支持多种格式）
                from PIL import Image, ImageTk

                # 打开并处理图片
                image = Image.open(image_path)

                # 调整图片大小
                icon_size = (32, 32)
                image = image.resize(icon_size, Image.Resampling.LANCZOS)

                # 转换为Tkinter可用的格式
                icon = ImageTk.PhotoImage(image)

                # 设置窗口图标
                self.root.iconphoto(True, icon)

                # 保存引用，防止被垃圾回收
                self.app_icon = icon

                print(f"成功设置自定义图标: {image_path}")

            except ImportError:
                # 如果PIL未安装，直接使用ICO文件
                print("PIL库未安装，尝试使用ICO文件")
                try:
                    # 直接尝试设置ICO图标，不调用try_ico_icon方法
                    if os.path.exists("7.ico"):
                        self.root.iconbitmap("7.ico")
                        print("使用ICO图标: 7.ico")
                    elif os.path.exists("app_icon.ico"):
                        self.root.iconbitmap("app_icon.ico")
                        print("使用ICO图标: app_icon.ico")
                except Exception as e:
                    print(f"设置ICO图标失败: {e}")
            except Exception as e:
                print(f"设置自定义图标失败: {e}")

        def create_widgets(self):
            """创建界面组件"""
            # 主框架
            main_frame = ttk.Frame(self.root, padding="10")
            main_frame.pack(fill=tk.BOTH, expand=True)

            # 文件选择
            file_frame = ttk.LabelFrame(main_frame, text="1. 文件选择", padding="5")
            file_frame.pack(fill=tk.X, pady=5)

            file_subframe = ttk.Frame(file_frame)
            file_subframe.pack(fill=tk.X)

            ttk.Button(file_subframe, text="选择Excel文件",
                       command=self.select_file).pack(side=tk.LEFT, padx=5)
            ttk.Label(file_subframe, textvariable=self.file_path,
                      background="white", relief="sunken", width=80).pack(
                side=tk.LEFT, fill=tk.X, expand=True, padx=5)

            # 数据范围
            range_frame = ttk.LabelFrame(main_frame, text="2. 数据范围设置", padding="5")
            range_frame.pack(fill=tk.X, pady=5)

            range_subframe = ttk.Frame(range_frame)
            range_subframe.pack(fill=tk.X)

            # 行范围
            ttk.Label(range_subframe, text="数据行范围:").pack(side=tk.LEFT, padx=5)
            ttk.Entry(range_subframe, textvariable=self.start_row, width=8).pack(side=tk.LEFT, padx=2)
            ttk.Label(range_subframe, text="-").pack(side=tk.LEFT)
            ttk.Entry(range_subframe, textvariable=self.end_row, width=8).pack(side=tk.LEFT, padx=2)

            # 列范围
            ttk.Label(range_subframe, text="数据列范围:").pack(side=tk.LEFT, padx=(20, 5))
            ttk.Entry(range_subframe, textvariable=self.start_col, width=8).pack(side=tk.LEFT, padx=2)
            ttk.Label(range_subframe, text="-").pack(side=tk.LEFT)
            ttk.Entry(range_subframe, textvariable=self.end_col, width=8).pack(side=tk.LEFT, padx=2)

            # 工况名称行
            ttk.Label(range_subframe, text="工况名称行:").pack(side=tk.LEFT, padx=(20, 5))
            ttk.Entry(range_subframe, textvariable=self.condition_row, width=8).pack(side=tk.LEFT, padx=2)

            # 角度输入框架
            angle_frame = ttk.LabelFrame(main_frame, text="3. 角度输入（3组，每组3个角度）", padding="5")
            angle_frame.pack(fill=tk.X, pady=5)

            # 创建3组角度输入
            group_labels = ["第一组角度", "第二组角度", "第三组角度"]
            for i, label in enumerate(group_labels):
                group_frame = ttk.LabelFrame(angle_frame, text=label, padding="5")
                group_frame.pack(fill=tk.X, pady=2)

                group_subframe = ttk.Frame(group_frame)
                group_subframe.pack(fill=tk.X)

                for j in range(3):
                    ttk.Label(group_subframe, text=f"角度{j + 1}:").pack(side=tk.LEFT, padx=5)
                    ttk.Entry(group_subframe, textvariable=self.angle_groups[i][j], width=10).pack(side=tk.LEFT, padx=2)

            # 输出设置
            output_frame = ttk.LabelFrame(main_frame, text="4. 输出设置", padding="5")
            output_frame.pack(fill=tk.X, pady=5)

            output_subframe = ttk.Frame(output_frame)
            output_subframe.pack(fill=tk.X)

            ttk.Button(output_subframe, text="选择输出文件",
                       command=self.select_output_file).pack(side=tk.LEFT, padx=5)
            ttk.Label(output_subframe, textvariable=self.output_file,
                      background="white", relief="sunken").pack(
                side=tk.LEFT, fill=tk.X, expand=True, padx=5)

            # 控制按钮
            button_frame = ttk.Frame(main_frame)
            button_frame.pack(fill=tk.X, pady=10)

            self.process_button = ttk.Button(button_frame, text="开始处理",
                                             command=self.process_data)
            self.process_button.pack(side=tk.LEFT, padx=10)

            ttk.Button(button_frame, text="测试读取",
                       command=self.test_read).pack(side=tk.LEFT, padx=10)

            ttk.Button(button_frame, text="清除",
                       command=self.clear_inputs).pack(side=tk.LEFT, padx=10)

            ttk.Button(button_frame, text="退出",
                       command=self.root.quit).pack(side=tk.LEFT, padx=10)

            # 进度条
            progress_frame = ttk.Frame(main_frame)
            progress_frame.pack(fill=tk.X, pady=5)

            self.progress_label = ttk.Label(progress_frame, text="就绪")
            self.progress_label.pack(fill=tk.X)

            self.progress_bar = ttk.Progressbar(progress_frame, mode='determinate')
            self.progress_bar.pack(fill=tk.X, pady=2)

            # 笔记本（选项卡）
            notebook = ttk.Notebook(main_frame)
            notebook.pack(fill=tk.BOTH, expand=True, pady=5)

            # 日志标签页
            log_frame = ttk.Frame(notebook, padding="5")
            notebook.add(log_frame, text="处理日志")

            self.log_text = scrolledtext.ScrolledText(log_frame, wrap=tk.WORD, height=15)
            self.log_text.pack(fill=tk.BOTH, expand=True)

            # 结果标签页
            result_frame = ttk.Frame(notebook, padding="5")
            notebook.add(result_frame, text="计算结果")

            self.result_text = scrolledtext.ScrolledText(result_frame, wrap=tk.WORD, height=15)
            self.result_text.pack(fill=tk.BOTH, expand=True)

            # 初始日志
            self.log("整车转局部(L)系统已启动")

        def select_file(self):
            """选择Excel文件"""
            file_path = filedialog.askopenfilename(
                title="选择Excel文件",
                filetypes=[("Excel files", "*.xlsx *.xls"), ("All files", "*.*")]
            )
            if file_path:
                self.file_path.set(file_path)
                base_name = os.path.splitext(file_path)[0]
                self.output_file.set(f"{base_name}_结果.xlsx")
                self.log(f"已选择文件: {file_path}")

        def select_output_file(self):
            """选择输出文件"""
            file_path = filedialog.asksaveasfilename(
                title="选择输出文件",
                defaultextension=".xlsx",
                filetypes=[("Excel files", "*.xlsx"), ("All files", "*.*")]
            )
            if file_path:
                self.output_file.set(file_path)
                self.log(f"输出文件设置为: {file_path}")

        def clear_inputs(self):
            """清除输入"""
            self.file_path.set("")
            self.start_row.set("2")
            self.end_row.set("100")
            self.start_col.set("1")
            self.end_col.set("10")
            self.condition_row.set("1")

            # 清除角度数据
            for group in self.angle_groups:
                for var in group:
                    var.set("0.0")

            self.output_file.set("")

            self.log_text.delete(1.0, tk.END)
            self.result_text.delete(1.0, tk.END)
            self.log("输入已清除")
            self.update_progress(0, "就绪")

        def log(self, message):
            """添加日志"""
            timestamp = time.strftime("%H:%M:%S")
            self.log_text.insert(tk.END, f"[{timestamp}] {message}\n")
            self.log_text.see(tk.END)
            self.root.update_idletasks()

        def update_progress(self, value, message):
            """更新进度"""
            self.progress_bar['value'] = value
            self.progress_label['text'] = message
            self.root.update_idletasks()

        def validate_inputs(self):
            """验证输入"""
            if not self.file_path.get():
                messagebox.showerror("错误", "请选择Excel文件")
                return False

            if not os.path.exists(self.file_path.get()):
                messagebox.showerror("错误", "文件不存在")
                return False

            try:
                start_r = int(self.start_row.get())
                end_r = int(self.end_row.get())
                start_c = int(self.start_col.get())
                end_c = int(self.end_col.get())

                if start_r <= 0 or end_r <= 0 or start_c <= 0 or end_c <= 0:
                    messagebox.showerror("错误", "行和列必须为正整数")
                    return False

                if start_r > end_r:
                    messagebox.showerror("错误", "起始行不能大于结束行")
                    return False

                if start_c > end_c:
                    messagebox.showerror("错误", "起始列不能大于结束列")
                    return False

            except ValueError:
                messagebox.showerror("错误", "行和列必须是整数")
                return False

            # 验证角度数据
            try:
                for i, group in enumerate(self.angle_groups):
                    for j, var in enumerate(group):
                        angle_val = float(var.get())
                        if angle_val < 0 or angle_val > 180:
                            messagebox.showerror("错误", f"第{i + 1}组角度{j + 1}必须在0-180度之间")
                            return False
            except ValueError:
                messagebox.showerror("错误", "角度必须是数字")
                return False

            return True

        def test_read(self):
            """测试读取Excel数据"""
            if not self.file_path.get():
                messagebox.showerror("错误", "请先选择Excel文件")
                return

            try:
                start_r = int(self.start_row.get())
                end_r = int(self.end_row.get())
                start_c = int(self.start_col.get())
                end_c = int(self.end_col.get())

                self.log("开始测试读取Excel数据...")

                # 使用导入的函数进行测试读取
                data = imported_funcs['read_excel_data'](
                    file_path=self.file_path.get(),
                    start_row=start_r,
                    end_row=end_r,
                    start_col=start_c,
                    end_col=end_c
                )

                self.log(f"读取成功! 数据形状: {len(data)}列 × {len(data[0]) if data else 0}行")
                self.log(f"前3列前5行预览:")

                for i in range(min(3, len(data))):
                    preview = [str(x)[:10] + '...' if x and len(str(x)) > 10 else str(x) for x in data[i][:5]]
                    self.log(f"  第{i + 1}列: {preview}")

            except Exception as e:
                self.log(f"测试读取失败: {str(e)}")
                messagebox.showerror("错误", f"读取失败: {str(e)}")

        def process_data_thread(self):
            """处理数据的线程"""
            try:
                # 获取参数
                file_path = self.file_path.get()
                start_row = int(self.start_row.get())
                end_row = int(self.end_row.get())
                start_col = int(self.start_col.get())
                end_col = int(self.end_col.get())
                condition_row = int(self.condition_row.get())

                excel_range = (start_row, end_row, start_col, end_col)

                # 构建角度数据
                angle_data = []
                for group_vars in self.angle_groups:
                    group = [float(var.get()) for var in group_vars]
                    angle_data.append(group)

                # 输出文件
                output_file = self.output_file.get()
                if not output_file:
                    base_name = os.path.splitext(file_path)[0]
                    output_file = f"{base_name}_结果.xlsx"
                    self.output_file.set(output_file)

                # 进度模拟
                steps = [
                    (10, "读取Excel数据..."),
                    (20, "验证数据格式..."),
                    (30, "计算角度余弦值..."),
                    (40, "执行分解计算..."),
                    (50, "执行求和计算..."),
                    (60, "生成结果表格..."),
                    (70, "保存Excel文件..."),
                    (100, "完成!")
                ]

                for progress, message in steps:
                    if not self.processing:
                        break
                    self.update_progress(progress, message)
                    self.log(message)
                    time.sleep(0.5)

                # 执行集成求和处理
                self.log("开始集成求和处理流程...")
                result = imported_funcs['integrated_sum_process'](
                    file_path=file_path,
                    excel_range=excel_range,
                    angle_data=angle_data
                )

                self.current_result = result
                self.log("集成求和处理完成!")

                # 保存结果到Excel
                self.log("开始保存结果到Excel文件...")
                saved_file = imported_funcs['save_results_to_excel'](
                    result_dict=result,
                    file_path=file_path,
                    output_file=output_file,
                    condition_row=condition_row
                )

                self.log(f"结果已保存到: {saved_file}")

                # 在主线程显示结果
                self.root.after(0, self.show_results)
                self.root.after(0, lambda: self.process_complete(saved_file))

            except Exception as e:
                error_msg = f"处理错误: {str(e)}"
                self.log(error_msg)
                self.root.after(0, lambda: self.process_error(error_msg))

        def show_results(self):
            """显示结果"""
            if not self.current_result:
                return

            self.result_text.delete(1.0, tk.END)

            result = self.current_result
            stats = result.get('statistics', {})

            # 显示基本信息
            self.result_text.insert(tk.END, "集成求和处理结果摘要\n")
            self.result_text.insert(tk.END, "=" * 50 + "\n\n")

            self.result_text.insert(tk.END, f"Excel数据形状: {stats.get('excel_data_shape', '未知')}\n")
            self.result_text.insert(tk.END, f"余弦值数据形状: {stats.get('cosine_data_shape', '未知')}\n")
            self.result_text.insert(tk.END, f"结果数据形状: {stats.get('result_shape', '未知')}\n")
            self.result_text.insert(tk.END, f"求和结果形状: {stats.get('sum_shape', '未知')}\n")
            self.result_text.insert(tk.END, f"计算成功率: {stats.get('success_rate', 0):.1f}%\n\n")

            # 显示求和结果
            sum_result = result.get('sum_result', [])
            if sum_result:
                self.result_text.insert(tk.END, "求和结果:\n")
                self.result_text.insert(tk.END, "-" * 30 + "\n")

                for i, copy_sum in enumerate(sum_result):
                    self.result_text.insert(tk.END, f"第{i + 1}个副本:\n")
                    for j, col_sum in enumerate(copy_sum):
                        self.result_text.insert(tk.END, f"  第{j + 1}列和: {col_sum:.6f}\n")
                    copy_total = sum(copy_sum)
                    self.result_text.insert(tk.END, f"  副本总和: {copy_total:.6f}\n\n")

            # 显示总和统计
            total_sum = stats.get('total_sum', 0)
            avg_sum = stats.get('average_sum_per_column', 0)
            self.result_text.insert(tk.END, f"总和: {total_sum:.6f}\n")
            self.result_text.insert(tk.END, f"每列平均值: {avg_sum:.6f}\n")

            self.result_text.see(tk.END)

        def process_complete(self, output_file):
            """处理完成"""
            self.processing = False
            self.process_button['state'] = 'normal'
            self.update_progress(100, "完成!")
            messagebox.showinfo("成功", f"处理完成!\n结果文件: {output_file}")

        def process_error(self, error_msg):
            """处理错误"""
            self.processing = False
            self.process_button['state'] = 'normal'
            self.update_progress(0, "错误")
            messagebox.showerror("错误", error_msg)

        def process_data(self):
            """开始处理"""
            if not self.validate_inputs():
                return

            if self.processing:
                return

            self.processing = True
            self.process_button['state'] = 'disabled'
            self.log_text.delete(1.0, tk.END)
            self.result_text.delete(1.0, tk.END)

            self.log("开始处理数据...")
            self.update_progress(0, "初始化...")

            # 保存配置
            try:
                excel_range = (
                    int(self.start_row.get()),
                    int(self.end_row.get()),
                    int(self.start_col.get()),
                    int(self.end_col.get())
                )
                imported_funcs['save_excel_range'](excel_range)
                self.log("配置已保存")
            except Exception as e:
                self.log(f"保存配置失败: {e}")

            # 启动处理线程
            thread = threading.Thread(target=self.process_data_thread)
            thread.daemon = True
            thread.start()

    # 创建Toplevel窗口（适配集成环境）
    win = tk.Toplevel()
    win.title("整车转局部(L)")
    win.geometry("1000x800")

    # 创建应用实例
    app = ExcelDataProcessorUI(win)

    # 确保窗口显示和焦点
    win.focus_set()
    win.grab_set()  # 模态窗口，确保用户先处理此窗口

    # 等待窗口关闭
    win.wait_window(win)


if __name__ == "__main__":
    main()