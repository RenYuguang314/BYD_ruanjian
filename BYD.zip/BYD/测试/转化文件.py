import os
import pandas as pd
import openpyxl
from openpyxl.utils import get_column_letter
import csv

# 请将此处路径修改为您要测试的CSV文件的实际路径
test_file_path = r"E:\项目二22222222222222222\合并文件2\shc_harm_ev_gvw_vr_p3_maintain_rr_harm_integral_jiont_lh_fx_rear_out.csv"  # 请替换为您的实际CSV文件路径


def convert_csv_to_xlsx(csv_path):
    """将CSV文件转换为XLSX格式，提升兼容性与准确性"""
    xlsx_path = csv_path.replace('.csv', '.xlsx')

    # 检查目标XLSX文件是否已存在，避免重复转换
    if os.path.exists(xlsx_path):
        print(f"提示: XLSX文件已存在，跳过转换: {xlsx_path}")
        return xlsx_path

    try:
        # 方案A: 使用 openpyxl 直接、精细地控制转换过程 (推荐用于复杂CSV)
        wb = openpyxl.Workbook()
        ws = wb.active

        with open(csv_path, 'r', encoding='utf-8-sig', newline='') as f:  # 使用 utf-8-sig 处理BOM
            reader = csv.reader(f)
            for row_idx, row in enumerate(reader, start=1):  # start=1 对应Excel行号起始
                for col_idx, value in enumerate(row, start=1):
                    # 将值直接写入单元格，openpyxl不会对字符串数字做数学转换
                    ws.cell(row=row_idx, column=col_idx, value=value)

        # 可选：自动调整列宽
        for column in ws.columns:
            max_length = 0
            column_letter = get_column_letter(column[0].column)
            for cell in column:
                try:
                    if cell.value:
                        cell_value_len = len(str(cell.value))
                        if cell_value_len > max_length:
                            max_length = cell_value_len
                except:
                    pass
            adjusted_width = (max_length + 2)
            ws.column_dimensions[column_letter].width = adjusted_width if adjusted_width <= 50 else 50

        wb.save(xlsx_path)
        print(f"[Openpyxl] 成功转换: {csv_path} -> {xlsx_path}")
        return xlsx_path

    except Exception as e1:
        print(f"[Openpyxl] 转换失败 ({e1})，尝试使用Pandas回退方案...")
        try:
            # 方案B: 使用 pandas 作为备用方案
            df = pd.read_csv(csv_path, dtype=str, encoding='utf-8-sig', keep_default_na=False)
            df.to_excel(xlsx_path, index=False, header=False)
            print(f"[Pandas] 成功转换: {csv_path} -> {xlsx_path}")
            return xlsx_path
        except Exception as e2:
            error_msg = f"CSV转换完全失败: 初始错误({e1})，回退错误({e2})"
            print(error_msg)
            raise IOError(error_msg)


def test_conversion():
    """测试CSV到XLSX的转换功能"""
    print("=" * 60)
    print("CSV 转 XLSX 功能测试")
    print("=" * 60)

    # 1. 检查测试文件是否存在
    if not os.path.exists(test_file_path):
        print(f"❌ 错误: 测试文件不存在 - {test_file_path}")
        print("请修改 'test_file_path' 变量为有效的CSV文件路径")
        return

    print(f"测试文件: {test_file_path}")
    print(f"文件大小: {os.path.getsize(test_file_path)} 字节")

    # 2. 备份原始XLSX文件路径，用于清理
    xlsx_path = test_file_path.replace('.csv', '.xlsx')
    original_xlsx_exists = os.path.exists(xlsx_path)

    if original_xlsx_exists:
        backup_path = xlsx_path.replace('.xlsx', '_备份.xlsx')
        print(f"提示: 原始XLSX文件已存在，备份至: {backup_path}")
        try:
            os.rename(xlsx_path, backup_path)
        except Exception as e:
            print(f"备份失败: {e}")

    try:
        # 3. 执行转换
        print("\n开始转换...")
        result_path = convert_csv_to_xlsx(test_file_path)

        # 4. 验证转换结果
        if os.path.exists(result_path):
            print(f"✅ 转换成功! 生成文件: {result_path}")
            print(f"生成文件大小: {os.path.getsize(result_path)} 字节")

            # 5. 可选：对比原始CSV和生成XLSX的内容行数
            try:
                # 读取CSV行数
                with open(test_file_path, 'r', encoding='utf-8-sig') as f:
                    csv_lines = sum(1 for _ in f)

                # 读取XLSX行数
                wb = openpyxl.load_workbook(result_path, data_only=True)
                ws = wb.active
                xlsx_rows = ws.max_row

                print(f"\n内容对比:")
                print(f"  CSV文件行数: {csv_lines}")
                print(f"  XLSX文件行数: {xlsx_rows}")

                if csv_lines == xlsx_rows:
                    print(f"  ✅ 行数匹配，转换准确")
                else:
                    print(f"  ⚠️  行数不匹配，请检查数据完整性")

                # 6. 可选：预览前几行数据
                print(f"\nXLSX文件前3行数据预览:")
                for i, row in enumerate(ws.iter_rows(min_row=1, max_row=3, values_only=True), 1):
                    # 只显示前5列，避免输出过长
                    preview_columns = row[:5]
                    print(f"  第{i}行: {preview_columns}")

            except Exception as e:
                print(f"内容验证时出错: {e}")

        else:
            print(f"❌ 转换失败: 未生成输出文件")

    except Exception as e:
        print(f"❌ 转换过程中出错: {e}")

    finally:
        # 7. 清理：恢复备份文件
        if original_xlsx_exists and os.path.exists(backup_path):
            try:
                # 删除新生成的测试文件
                if os.path.exists(xlsx_path):
                    os.remove(xlsx_path)
                # 恢复备份文件
                os.rename(backup_path, xlsx_path)
                print(f"\n已清理测试文件，恢复原始XLSX文件")
            except Exception as e:
                print(f"清理文件时出错: {e}")

    print("\n" + "=" * 60)
    print("测试完成")
    print("=" * 60)


def quick_test_multiple_formats():
    """快速测试多种CSV格式的兼容性"""
    print("\n" + "=" * 60)
    print("多格式兼容性快速测试")
    print("=" * 60)

    # 创建测试用的临时CSV文件
    test_cases = [
        ("normal.csv", ["Name,Age,City", "John Doe,30,New York", "Jane Smith,25,London"]),
        ("special_chars.csv", ["ID,Content", "001,Special: ç, ñ, é", "002,Quotes: \"Hello\""]),
        ("long_numbers.csv", ["ID,Phone", "001,001234567890", "002,98765432100123456789"]),  # 长数字
        ("empty_cells.csv", ["Col1,Col2,Col3", "A,,C", ",B,", ",,C"]),  # 空单元格
    ]

    for filename, lines in test_cases:
        print(f"\n测试用例: {filename}")

        # 创建临时CSV文件
        temp_csv = os.path.join(os.path.dirname(test_file_path), filename) if os.path.dirname(
            test_file_path) else filename
        with open(temp_csv, 'w', encoding='utf-8-sig', newline='') as f:
            f.write('\n'.join(lines))

        try:
            result = convert_csv_to_xlsx(temp_csv)
            print(f"  ✅ 转换成功: {result}")

            # 清理临时文件
            if os.path.exists(temp_csv):
                os.remove(temp_csv)
            if os.path.exists(result):
                os.remove(result)

        except Exception as e:
            print(f"  ❌ 转换失败: {e}")

            # 清理临时文件
            if os.path.exists(temp_csv):
                os.remove(temp_csv)


# 运行测试
if __name__ == "__main__":
    # 主测试：测试指定路径的CSV文件
    test_conversion()

    # 可选：运行多格式兼容性测试（注释掉下一行以跳过）
    # quick_test_multiple_formats()