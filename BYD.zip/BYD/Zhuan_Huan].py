from PIL import Image
img = Image.open("7.jpeg")
img.save("7.ico", format='ICO', sizes=[(32,32), (64,64)])  # 适配标准图标尺寸