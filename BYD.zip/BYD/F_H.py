import pandas as pd
import math
from typing import List, Union, Optional, Tuple
import numpy as np


def read_excel_data(
        file_path: str,
        start_row: int,
        end_row: int,
        start_col: int,
        end_col: int,
        sheet_name: Union[str, int] = 0,
        header: Optional[int] = None
) -> List[List[Union[float, int, str]]]:
    """
    读取Excel文件中指定行和列范围的数据，按横向（先行后列）顺序读取

    注意：行和列编号都从1开始（符合Excel习惯）

    参数:
    ----------
    file_path : str
        Excel文件路径
    start_row : int
        起始行编号（从1开始）- 数据行起始位置
    end_row : int
        结束行编号（包含该行，从1开始）- 数据行结束位置
    start_col : int
        起始列编号（从1开始）
    end_col : int
        结束列编号（包含该列，从1开始）
    sheet_name : Union[str, int], default=0
        工作表名称或索引
    header : Optional[int], default=None
        表头行，None表示无表头

    返回:
    ----------
    List[List[Union[float, int, str]]]
        读取的数据列表，每个子列表代表一行的数据
    """
    try:
        # 读取整个工作表
        df = pd.read_excel(file_path, sheet_name=sheet_name, header=header)

        # 将Excel行列编号(1-based)转换为Python索引(0-based)
        start_row_idx = start_row - 1
        end_row_idx = end_row - 1
        start_col_idx = start_col - 1
        end_col_idx = end_col - 1

        # 验证行列范围是否有效
        if start_row_idx < 0 or end_row_idx >= len(df) or start_row_idx > end_row_idx:
            raise ValueError(f"行范围无效: start_row={start_row}, end_row={end_row}, 数据行数={len(df)}")

        if start_col_idx < 0 or end_col_idx >= len(df.columns) or start_col_idx > end_col_idx:
            raise ValueError(f"列范围无效: start_col={start_col}, end_col={end_col}, 数据列数={len(df.columns)}")

        # 计算需要读取的数据行（第3行、第6行、第9行等）
        data_rows = []
        current_row = start_row_idx

        # 找到第一个数据行（第3行或其后第一个3的倍数的行）
        while current_row <= end_row_idx:
            # 计算当前行相对于起始行的偏移量
            row_offset = current_row - start_row_idx + 1
            # 如果行号是3的倍数，则读取该行
            if row_offset % 3 == 0:
                data_rows.append(current_row)
            current_row += 1

        print(f"检测到 {len(data_rows)} 个数据行: {[r + 1 for r in data_rows]}")

        # 创建空列表来存储数据（按行存储）
        all_data = []

        # 横向读取：先遍历行，再遍历列
        for row_idx in data_rows:
            row_data = []

            # 遍历当前行的所有列
            for col in range(start_col_idx, end_col_idx + 1):
                value = df.iloc[row_idx, col]

                # 处理NaN值（空单元格）
                if pd.isna(value):
                    row_data.append(None)
                else:
                    row_data.append(value)

            all_data.append(row_data)

        print(f"读取的数据（按行存储）2222222222222222222: {all_data}")
        return all_data

    except FileNotFoundError:
        raise FileNotFoundError(f"文件未找到: {file_path}")
    except Exception as e:
        raise Exception(f"读取Excel文件时出错: {str(e)}")


def input_angles_batch() -> List[List[float]]:
    """
    批量输入角度信息（按组输入）

    返回:
    ----------
    List[List[float]]
        角度信息，格式为 [[角度1, 角度2, 角度3], [角度4, 角度5, 角度6], [角度7, 角度8, 角度9]]
    """
    print("=" * 50)
    print("批量角度输入系统")
    print("=" * 50)
    print("请按组输入角度值，每组3个角度")

    result = []

    for group_num in range(1, 4):
        while True:
            try:
                input_str = input(f"请输入第{group_num}组的3个角度值（用逗号分隔）: ").strip()

                values = input_str.split(',')

                if len(values) != 3:
                    print(f"错误：每组需要3个角度值，您输入了{len(values)}个")
                    continue

                # 转换为浮点数
                angles = []
                for value in values:
                    angle = float(value.strip())
                    angles.append(angle)

                result.append(angles)
                break

            except ValueError:
                print("输入格式错误，请确保输入的是数字，并用逗号分隔")
            except Exception as e:
                print(f"发生错误: {e}")

    print("\n输入的角度信息:")
    for i, group in enumerate(result):
        print(f"  第{i + 1}组: {group}")

    return result

def calculate_cosines_from_manual(manual_angles: List[List[float]] = None) -> List[List[float]]:
    """
    从手动指定的角度数据计算余弦值

    参数:
    ----------
    manual_angles : List[List[float]], optional
        手动指定的3x3角度数据

    返回:
    ----------
    List[List[float]]
        3x3格式的余弦值数据
    """
    if manual_angles is None:
        # 使用默认测试数据
        manual_angles = [
            [35.937, 65.656, 114.694],
            [111.825, 100.987, 155.306],
            [111.825, 100.987, 155.306]
        ]

    print("使用的手动角度数据:")
    for i, row in enumerate(manual_angles):
        print(f"  第{i + 1}行: {row}")

    cosine_data = []

    for row in manual_angles:
        cosine_row = []
        for angle in row:
            cosine_value = math.cos(math.radians(angle))
            cosine_row.append(cosine_value)
        cosine_data.append(cosine_row)

    return manual_angles, cosine_data


def convert_to_numeric(data_list: List[List]) -> List[List]:
    """
    将读取的数据转换为数值类型（如果可能）

    参数:
    ----------
    data_list : List[List]
        原始数据列表

    返回:
    ----------
    List[List]
        转换后的数据列表
    """
    converted_data = []

    for column in data_list:
        converted_column = []
        for value in column:
            if value is None:
                converted_column.append(None)
            else:
                # 尝试转换为数值
                try:
                    if isinstance(value, (int, float, np.integer, np.floating)):
                        converted_column.append(float(value))
                    else:
                        # 尝试从字符串转换
                        converted_column.append(float(str(value).replace(',', '')))
                except (ValueError, TypeError):
                    # 无法转换，保留原值
                    converted_column.append(value)
        converted_data.append(converted_column)

    return converted_data

def integrated_process(file_path: str,
                       excel_range: Tuple[int, int, int, int],
                       angle_data: List[List[float]] = None) -> dict:
    """
    集成流程函数：将文件读取、角度输入、余弦计算和分解计算整合到一个函数中

    参数:
    ----------
    file_path : str
        Excel文件路径
    excel_range : Tuple[int, int, int, int]
        Excel数据范围 (start_row, end_row, start_col, end_col)
    angle_data : List[List[float]], optional
        角度数据，如果为None则使用默认值

    返回:
    ----------
    dict
        包含所有结果和信息的字典
    """
    try:
        # 1. 读取Excel数据
        start_row, end_row, start_col, end_col = excel_range
        print("=" * 60)
        print("开始集成处理流程")
        print("=" * 60)

        print(f"1. 读取Excel数据: {file_path}")
        print(f"   范围: 行{start_row}-{end_row}, 列{start_col}-{end_col}")

        raw_excel_data = read_excel_data(
            file_path=file_path,
            start_row=start_row,
            end_row=end_row,
            start_col=start_col,
            end_col=end_col
        )

        # 转换为数值类型
        excel_data = convert_to_numeric(raw_excel_data)

        if not excel_data or len(excel_data) == 0:
            raise ValueError("Excel数据为空")

        print(f"   Excel数据形状: {len(excel_data)}列 × {len(excel_data[0]) if excel_data[0] else 0}行")

        # 2. 使用角度数据
        print("\n2. 使用角度数据")
        if angle_data is None:
            # 使用默认角度数据
            angle_data = [[35.937,65.656,114.694],
                          [111.825,100.987,155.306],
                          [62.991,152.997,89.939]]
            print("使用默认角度数据")
        else:
            print("使用传入的角度数据")

        # 3. 计算余弦值
        print("\n3. 计算余弦值")
        _, cosine_data = calculate_cosines_from_manual(angle_data)

        # 4. 执行分解计算
        print("\n4. 执行分解计算")
        result = fenjie_simplified(excel_data, cosine_data)

        return result

    except Exception as e:
        raise Exception(f"集成处理流程出错: {str(e)}")


def fenjie_simplified(excel_data: List[List[Union[float, int, str]]],
                      cosine_data: List[List[float]]) -> dict:
    """
    简化版分解函数：只需要Excel数据和余弦值数据

    参数:
    ----------
    excel_data : List[List[Union[float, int, str]]]
        从Excel读取的数据
    cosine_data : List[List[float]]
        余弦值数据，必须是3x3格式

    返回:
    ----------
    dict
        包含所有结果和信息的字典
    """
    try:
        # 验证余弦值数据是否为3x3格式
        if len(cosine_data) != 3 or any(len(row) != 3 for row in cosine_data):
            raise ValueError(
                f"余弦值数据必须是3x3格式，当前形状: {len(cosine_data)}x{len(cosine_data[0]) if cosine_data else 0}")

        # 验证Excel数据
        if not excel_data or len(excel_data) == 0:
            raise ValueError("Excel数据为空")

        print("余弦值数据:")
        for i, row in enumerate(cosine_data):
            print(f"  第{i + 1}行: {[f'{x:.6f}' for x in row]}")

        print("232423511531515151515151515155",excel_data)
        # 执行分解计算
        result_3d = []
        total_calculations = 0
        successful_calculations = 0

        for copy_idx in range(3):
            copy_result = []

            # 获取当前副本对应的余弦值行
            cosine_row = cosine_data[copy_idx]

            print(f"\n处理第{copy_idx + 1}个副本，使用余弦值行{cosine_row}")

            # 遍历Excel数据的每一列
            for col_idx, column in enumerate(excel_data):
                multiplied_column = []

                # 遍历列中的每个元素
                for row_idx, value in enumerate(column):
                    total_calculations += 1

                    # 处理None值
                    if value is None:
                        multiplied_column.append(None)
                        continue

                    try:
                        # 转换为数值
                        if isinstance(value, (int, float, np.integer, np.floating)):
                            numeric_value = float(value)
                        else:
                            numeric_value = float(str(value).replace(',', ''))

                        # 使用对应位置的角度余弦值相乘
                        angle_idx = row_idx % len(cosine_row)  # 循环使用角度值
                        result_value = numeric_value * cosine_row[angle_idx]
                        multiplied_column.append(result_value)
                        successful_calculations += 1

                    except (ValueError, TypeError) as e:
                        print(f"  警告: 第{col_idx + 1}列第{row_idx + 1}行数据转换失败: {value}")
                        multiplied_column.append(None)

                copy_result.append(multiplied_column)

            result_3d.append(copy_result)

        # 统计信息
        stats = {
            'excel_data_shape': f"{len(excel_data)}列×{len(excel_data[0]) if excel_data[0] else 0}行",
            'cosine_data_shape': f"{len(cosine_data)}行×{len(cosine_data[0])}列",
            'result_shape': f"{len(result_3d)}副本×{len(result_3d[0])}列×{len(result_3d[0][0]) if result_3d[0] else 0}行",
            'total_calculations': total_calculations,
            'successful_calculations': successful_calculations,
            'success_rate': successful_calculations / total_calculations * 100 if total_calculations > 0 else 0
        }
        print("88888888888888888888888888888888",result_3d)
        return {
            'excel_data': excel_data,
            'cosine_data': cosine_data,
            'result_3d': result_3d,
            'statistics': stats
        }

    except Exception as e:
        raise Exception(f"简化版分解计算时出错: {str(e)}")


def display_integrated_results(result_dict: dict, show_details: bool = False):
    """
    显示集成处理结果

    参数:
    ----------
    result_dict : dict
        integrated_process函数的返回结果
    show_details : bool
        是否显示详细结果
    """
    excel_data = result_dict['excel_data']
    cosine_data = result_dict['cosine_data']
    result_3d = result_dict['result_3d']
    stats = result_dict['statistics']

    print("\n" + "=" * 100)
    print("集成处理结果")
    print("=" * 100)

    print(f"Excel数据形状: {stats['excel_data_shape']}")
    print(f"余弦值数据形状: {stats['cosine_data_shape']}")
    print(f"结果数据形状: {stats['result_shape']}")
    print(f"计算成功率: {stats['successful_calculations']}/{stats['total_calculations']} "
          f"({stats['success_rate']:.1f}%)")

    # 显示每个副本的结果摘要
    for copy_idx, copy_data in enumerate(result_3d):
        print(f"\n第{copy_idx + 1}个副本结果:")
        print("-" * 80)

        # 显示前3列的前5行
        for col_idx in range(min(3, len(copy_data))):
            preview_values = [f'{x:.6f}' if x is not None else 'None' for x in copy_data[col_idx][:5]]
            print(f"  第{col_idx + 1}列前5个值: {preview_values}")

        if show_details:
            print(f"  详细数据:")
            for col_idx, col_data in enumerate(copy_data):
                print(f"    第{col_idx + 1}列: {[f'{x:.6f}' if x is not None else 'None' for x in col_data]}")


def save_integrated_results(result_dict: dict, filename: str = "integrated_results.txt"):
    """
    保存集成处理结果到文件
    """
    with open(filename, 'w', encoding='utf-8') as f:
        f.write("集成处理结果\n")
        f.write("=" * 50 + "\n\n")

        f.write("数据信息:\n")
        f.write(f"  Excel数据形状: {result_dict['statistics']['excel_data_shape']}\n")
        f.write(f"  余弦值数据形状: {result_dict['statistics']['cosine_data_shape']}\n")
        f.write(f"  计算成功率: {result_dict['statistics']['success_rate']:.1f}%\n\n")

        f.write("余弦值数据:\n")
        for i, row in enumerate(result_dict['cosine_data']):
            f.write(f"  第{i + 1}行: {[f'{x:.6f}' for x in row]}\n")

        f.write("\n分解结果:\n")
        for copy_idx, copy_data in enumerate(result_dict['result_3d']):
            f.write(f"\n第{copy_idx + 1}个副本:\n")
            for col_idx, col_data in enumerate(copy_data):
                f.write(f"  第{col_idx + 1}列: {[f'{x:.6f}' if x is not None else 'None' for x in col_data]}\n")


def sum_fenjie_result(result_3d: List[List[List[float]]]) -> List[List[float]]:
    """
    对分解函数的结果进行求和

    参数:
    ----------
    result_3d : List[List[List[float]]]
        分解函数返回的三维数组，格式为 [[[],[],[]],[[],[],[]],[[],[],[]]]

    返回:
    ----------
    List[List[float]]
        求和后的二维数组，格式为 [[副本1的列和], [副本2的列和], [副本3的列和]]
    """
    try:
        # 验证输入数据
        if not result_3d or len(result_3d) == 0:
            raise ValueError("输入的三维数组为空")

        print("开始对分解结果进行求和计算")
        print(
            f"输入数据形状: {len(result_3d)}副本 × {len(result_3d[0])}列 × {len(result_3d[0][0]) if result_3d[0] else 0}行")

        # 创建结果数组
        sum_result = []

        # 遍历每个副本
        for copy_idx, copy_data in enumerate(result_3d):
            copy_sum = []

            print(f"\n处理第{copy_idx + 1}个副本:")

            # 遍历副本中的每一列
            for col_idx, column in enumerate(copy_data):
                # 对当前列的所有元素求和
                column_sum = 0.0
                valid_count = 0

                for value in column:
                    if value is not None:
                        try:
                            column_sum += float(value)
                            valid_count += 1
                        except (ValueError, TypeError):
                            # 无法转换为数值，跳过
                            pass

                copy_sum.append(column_sum)
                print(f"  第{col_idx + 1}列: 求和 = {column_sum:.6f} (有效值: {valid_count}/{len(column)})")

            sum_result.append(copy_sum)

        print(f"\n求和结果形状: {len(sum_result)}副本 × {len(sum_result[0])}列")
        return sum_result

    except Exception as e:
        raise Exception(f"求和计算时出错: {str(e)}")


def integrated_sum_process(file_path: str,
                           excel_range: Tuple[int, int, int, int],
                           angle_data: List[List[float]] = None) -> dict:
    """
    集成求和处理流程：包含文件读取、角度输入、余弦计算、分解计算和求和计算

    参数:
    ----------
    file_path : str
        Excel文件路径
    excel_range : Tuple[int, int, int, int]
        Excel数据范围 (start_row, end_row, start_col, end_col)
    angle_data : List[List[float]], optional
        角度数据，如果为None则使用默认值

    返回:
    ----------
    dict
        包含所有结果和信息的字典
    """
    try:
        # 1. 执行集成处理流程
        print("=" * 60)
        print("开始集成求和处理流程")
        print("=" * 60)

        # 修改这里：传递 angle_data 参数
        fenjie_result = integrated_process(file_path, excel_range, angle_data)

        # 2. 对分解结果进行求和
        print("\n" + "=" * 60)
        print("执行求和计算")
        print("=" * 60)

        sum_result = sum_fenjie_result(fenjie_result['result_3d'])

        # 3. 将求和结果添加到原字典中
        fenjie_result['sum_result'] = sum_result

        # 4. 添加求和统计信息
        fenjie_result['statistics']['sum_shape'] = f"{len(sum_result)}副本×{len(sum_result[0]) if sum_result else 0}列"

        # 计算总和统计
        total_sum = 0.0
        for copy_sum in sum_result:
            for col_sum in copy_sum:
                total_sum += col_sum

        fenjie_result['statistics']['total_sum'] = total_sum
        fenjie_result['statistics']['average_sum_per_column'] = total_sum / (
                    len(sum_result) * len(sum_result[0])) if sum_result and len(sum_result[0]) > 0 else 0

        return fenjie_result

    except Exception as e:
        raise Exception(f"集成求和处理流程出错: {str(e)}")


def display_sum_results(result_dict: dict, show_details: bool = False):
    """
    显示求和结果

    参数:
    ----------
    result_dict : dict
        integrated_sum_process函数的返回结果
    show_details : bool
        是否显示详细结果
    """
    if 'sum_result' not in result_dict:
        print("错误: 结果字典中不包含求和结果")
        return

    sum_result = result_dict['sum_result']
    stats = result_dict['statistics']

    print("\n" + "=" * 100)
    print("求和计算结果")
    print("=" * 100)

    print(f"求和结果形状: {stats['sum_shape']}")
    print(f"总和: {stats['total_sum']:.6f}")
    print(f"每列平均值: {stats['average_sum_per_column']:.6f}")

    # 显示每个副本的求和结果
    for copy_idx, copy_sum in enumerate(sum_result):
        print(f"\n第{copy_idx + 1}个副本的列和:")
        print("-" * 50)

        for col_idx, col_sum in enumerate(copy_sum):
            print(f"  第{col_idx + 1}列: {col_sum:.6f}")

        # 计算副本总和
        copy_total = sum(copy_sum)
        print(f"  副本{copy_idx + 1}总和: {copy_total:.6f}")

    if show_details:
        # 显示原始分解结果
        print(f"\n原始分解结果:")
        result_3d = result_dict['result_3d']
        for copy_idx, copy_data in enumerate(result_3d):
            print(f"\n第{copy_idx + 1}个副本原始数据:")
            for col_idx, col_data in enumerate(copy_data):
                preview_values = [f'{x:.6f}' if x is not None else 'None' for x in col_data[:5]]
                print(f"  第{col_idx + 1}列前5个值: {preview_values}")


def save_sum_results(result_dict: dict, filename: str = "sum_results.txt"):
    """
    保存求和结果到文件
    """
    if 'sum_result' not in result_dict:
        print("错误: 结果字典中不包含求和结果")
        return

    with open(filename, 'w', encoding='utf-8') as f:
        f.write("求和计算结果\n")
        f.write("=" * 50 + "\n\n")

        f.write("统计信息:\n")
        f.write(f"  求和结果形状: {result_dict['statistics']['sum_shape']}\n")
        f.write(f"  总和: {result_dict['statistics']['total_sum']:.6f}\n")
        f.write(f"  每列平均值: {result_dict['statistics']['average_sum_per_column']:.6f}\n\n")

        f.write("各副本列和:\n")
        for copy_idx, copy_sum in enumerate(result_dict['sum_result']):
            f.write(f"\n第{copy_idx + 1}个副本:\n")
            for col_idx, col_sum in enumerate(copy_sum):
                f.write(f"  第{col_idx + 1}列: {col_sum:.6f}\n")
            copy_total = sum(copy_sum)
            f.write(f"  副本总和: {copy_total:.6f}\n")

        f.write("\n原始分解结果摘要:\n")
        result_3d = result_dict['result_3d']
        for copy_idx, copy_data in enumerate(result_3d):
            f.write(f"\n第{copy_idx + 1}个副本原始数据:\n")
            for col_idx, col_data in enumerate(copy_data):
                preview_values = [f'{x:.6f}' if x is not None else 'None' for x in col_data[:3]]
                f.write(f"  第{col_idx + 1}列前3个值: {preview_values}\n")



def gongkuang(file_path: str,
              excel_range: Tuple[int, int, int, int],  # 接受整个数据范围
              condition_col: int,  # 新增：独立的工况名称所在列
              sheet_name: Union[str, int] = 0) -> List[str]:
    """
    读取Excel文件中指定工况数据范围的工况名称
    修改：选择行的范围，读取工况名称所在列（第1行、第4行、第7行等）

    参数:
    ----------
    file_path : str
        Excel文件路径
    excel_range : Tuple[int, int, int, int]
        Excel数据范围 (start_row, end_row, start_col, end_col)
    condition_col : int
        工况名称所在列（独立参数）
    sheet_name : Union[str, int], default=0
        工作表名称或索引

    返回:
    ----------
    List[str]
        工况名称列表，每个元素对应一个工况数据范围的工况名称
    """
    try:
        # 读取整个工作表
        df = pd.read_excel(file_path, sheet_name=sheet_name, header=None)

        start_row, end_row, start_col, end_col = excel_range

        # 将Excel行列编号(1-based)转换为Python索引(0-based)
        start_row_idx = start_row - 1
        condition_col_idx = condition_col - 1  # 工况名称列索引

        # 验证范围是否有效
        if start_row_idx < 0 or start_row_idx >= len(df):
            raise ValueError(f"起始行无效: {start_row}")

        if condition_col_idx < 0 or condition_col_idx >= len(df.columns):
            raise ValueError(f"工况名称列无效: {condition_col}")

        condition_names = []

        # 计算需要读取的数据行（第1行、第4行、第7行等）
        data_rows = []
        current_row = start_row_idx

        # 找到第一个数据行（第1行或其后第一个3的倍数的行）
        while current_row <= end_row - 1:  # end_row是包含的，所以减1
            # 计算当前行相对于起始行的偏移量
            row_offset = current_row - start_row_idx + 1
            # 如果行号是3的倍数减2（即1,4,7,10...），则读取该行
            if (row_offset - 1) % 3 == 0:
                data_rows.append(current_row)
            current_row += 1

        print(f"检测到 {len(data_rows)} 个工况数据行: {[r + 1 for r in data_rows]}")

        # 读取每个工况数据行的工况名称（位于独立的工况名称列）
        for i, row_idx in enumerate(data_rows):
            # 确保不超过行范围
            if row_idx > end_row - 1:
                break

            # 读取当前行、独立工况名称列的值
            value = df.iloc[row_idx, condition_col_idx]

            # 处理空值
            if pd.isna(value) or str(value).strip() == "":
                condition_name = f"工况{i + 1}"
            else:
                condition_name = str(value).strip()

            condition_names.append(condition_name)
            print(f"工况{i + 1}名称: {condition_name} (行{row_idx + 1}, 列{condition_col})")

        return condition_names

    except FileNotFoundError:
        raise FileNotFoundError(f"文件未找到: {file_path}")
    except Exception as e:
        raise Exception(f"读取工况名称时出错: {str(e)}")

    def get_condition_col_from_input() -> int:
        """
        获取用户输入的工况名称所在列

        返回:
        ----------
        int
            工况名称所在列（从1开始）
        """
        print("=" * 60)
        print("工况名称列输入")
        print("=" * 60)

        while True:
            try:
                condition_col = int(input("请输入工况名称所在列号 (从1开始): ").strip())

                if condition_col <= 0:
                    print("错误: 列号必须为正整数")
                    continue

                print(f"设置的工况名称列: 第{condition_col}列")
                return condition_col

            except ValueError:
                print("输入格式错误，请确保输入的是整数")
            except Exception as e:
                print(f"发生错误: {e}")

    def save_condition_col(condition_col: int, filename: str = "condition_col_config.txt"):
        """
        保存工况名称列到配置文件
        """
        try:
            with open(filename, 'w', encoding='utf-8') as f:
                f.write(f"condition_col={condition_col}\n")
            print(f"工况名称列已保存到: {filename}")
        except Exception as e:
            print(f"保存工况名称列时出错: {e}")

    def load_condition_col(filename: str = "condition_col_config.txt") -> int:
        """
        从配置文件加载工况名称列
        """
        try:
            import os
            if not os.path.exists(filename):
                return None

            with open(filename, 'r', encoding='utf-8') as f:
                line = f.readline().strip()
                if '=' in line:
                    key, value = line.split('=', 1)
                    if key.strip() == 'condition_col':
                        result = int(value.strip())
                        print(f"从配置文件加载工况名称列: 第{result}列")
                        return result
            return None
        except Exception as e:
            print(f"加载工况名称列时出错: {e}")
            return None

    def get_current_condition_col(result_dict: dict = None,
                                  config_file: str = "condition_col_config.txt") -> int:
        """
        获取当前的工况名称列（优先级：结果字典 > 配置文件 > 用户输入）
        """
        # 1. 首先尝试从结果字典中获取
        if result_dict and 'condition_col' in result_dict:
            condition_col = result_dict['condition_col']
            print(f"从结果字典中获取工况名称列: 第{condition_col}列")
            return condition_col

        # 2. 尝试从配置文件中加载
        condition_col = load_condition_col(config_file)
        if condition_col is not None:
            return condition_col

        # 3. 如果都没有，则要求用户输入
        print("未找到工况名称列配置，需要用户输入")
        return get_condition_col_from_input()


def save_condition_col(condition_col: int, filename: str = "condition_col_config.txt"):
    """
    保存工况名称列到配置文件
    """
    try:
        with open(filename, 'w', encoding='utf-8') as f:
            f.write(f"condition_col={condition_col}\n")
        print(f"工况名称列已保存到: {filename}")
    except Exception as e:
        print(f"保存工况名称列时出错: {e}")

def get_excel_range_from_input() -> Tuple[int, int, int, int]:
    """
    获取用户输入的Excel数据范围
    修改：主要关注行范围，列范围用于确定工况名称所在列

    返回:
    ----------
    Tuple[int, int, int, int]
        Excel数据范围 (start_row, end_row, start_col, end_col)
    """
    print("=" * 60)
    print("Excel数据范围输入")
    print("=" * 60)
    print("注意: 现在主要关注行范围，列范围用于确定工况名称所在列")

    while True:
        try:
            # 获取行范围
            print("\n行范围设置:")
            start_row = int(input("请输入起始行号 (从1开始): ").strip())
            end_row = int(input("请输入结束行号 (包含该行): ").strip())

            # 获取列范围（主要用于确定工况名称所在列）
            print("\n列范围设置 (用于确定工况名称所在列):")
            start_col = int(input("请输入起始列号 (从1开始，工况名称所在列): ").strip())
            end_col = int(input("请输入结束列号 (包含该列): ").strip())

            # 验证输入范围是否有效
            if start_row <= 0 or end_row <= 0 or start_col <= 0 or end_col <= 0:
                print("错误: 行号和列号必须为正整数")
                continue

            if start_row > end_row:
                print("错误: 起始行号不能大于结束行号")
                continue

            if start_col > end_col:
                print("错误: 起始列号不能大于结束列号")
                continue

            print(f"设置的数据范围: 行{start_row}-{end_row}, 列{start_col}-{end_col}")
            print(f"工况名称将从第{start_col}列读取，行位置: {start_row}, {start_row + 3}, {start_row + 6}...")

            return start_row, end_row, start_col, end_col

        except ValueError:
            print("输入格式错误，请确保输入的是整数")
        except Exception as e:
            print(f"发生错误: {e}")


def save_excel_range(excel_range: Tuple[int, int, int, int], filename: str = "excel_range_config.txt"):
    """
    保存Excel数据范围到配置文件

    参数:
    ----------
    excel_range : Tuple[int, int, int, int]
        Excel数据范围
    filename : str
        配置文件名
    """
    try:
        with open(filename, 'w', encoding='utf-8') as f:
            f.write(f"start_row={excel_range[0]}\n")
            f.write(f"end_row={excel_range[1]}\n")
            f.write(f"start_col={excel_range[2]}\n")
            f.write(f"end_col={excel_range[3]}\n")

        print(f"Excel数据范围已保存到: {filename}")
    except Exception as e:
        print(f"保存Excel数据范围时出错: {e}")


def load_excel_range(filename: str = "excel_range_config.txt") -> Tuple[int, int, int, int]:
    """
    从配置文件加载Excel数据范围

    参数:
    ----------
    filename : str
        配置文件名

    返回:
    ----------
    Tuple[int, int, int, int]
        Excel数据范围，如果文件不存在则返回None
    """
    try:
        import os
        if not os.path.exists(filename):
            return None

        excel_range = {}
        with open(filename, 'r', encoding='utf-8') as f:
            for line in f:
                line = line.strip()
                if '=' in line:
                    key, value = line.split('=', 1)
                    excel_range[key.strip()] = int(value.strip())

        if all(key in excel_range for key in ['start_row', 'end_row', 'start_col', 'end_col']):
            result = (excel_range['start_row'], excel_range['end_row'],
                      excel_range['start_col'], excel_range['end_col'])
            print(f"从配置文件加载Excel数据范围: 行{result[0]}-{result[1]}, 列{result[2]}-{result[3]}")
            return result
        else:
            return None

    except Exception as e:
        print(f"加载Excel数据范围时出错: {e}")
        return None


def get_current_excel_range(result_dict: dict = None,
                            config_file: str = "excel_range_config.txt") -> Tuple[int, int, int, int]:
    """
    获取当前的Excel数据范围（优先级：结果字典 > 配置文件 > 用户输入）

    参数:
    ----------
    result_dict : dict, optional
        结果字典，可能包含excel_range
    config_file : str
        配置文件名

    返回:
    ----------
    Tuple[int, int, int, int]
        Excel数据范围
    """
    # 1. 首先尝试从结果字典中获取
    if result_dict and 'excel_range' in result_dict:
        excel_range = result_dict['excel_range']
        print(
            f"从结果字典中获取Excel数据范围: 行{excel_range[0]}-{excel_range[1]}, 列{excel_range[2]}-{excel_range[3]}")
        return excel_range

    # 2. 尝试从配置文件中加载
    excel_range = load_excel_range(config_file)
    if excel_range is not None:
        return excel_range

    # 3. 如果都没有，则要求用户输入
    print("未找到Excel数据范围配置，需要用户输入")
    return get_excel_range_from_input()


def save_results_to_excel(result_dict: dict,
                          file_path: str,
                          output_file: str = None,
                          condition_col: int = None) -> str:
    """
    将结果保存到Excel文件的两个工作表中，并对最大值进行标黄
    修改：使用X、Y、Z三列数据，分别对应sum_result的三个子列表
    """
    try:
        # 导入openpyxl的样式模块
        from openpyxl.styles import PatternFill, Font
        from openpyxl import Workbook

        # 确定输出文件路径
        if output_file is None:
            import os
            base_name = os.path.splitext(file_path)[0]
            output_file = f"{base_name}_结果.xlsx"

        print(f"开始将结果保存到Excel文件: {output_file}")

        # 获取数据范围
        excel_range = get_current_excel_range(result_dict)
        start_row, end_row, start_col, end_col = excel_range

        # 获取工况名称列
        if condition_col is None:
            condition_col = get_current_condition_col(result_dict)

        print(f"使用的数据范围: 行{start_row}-{end_row}, 列{start_col}-{end_col}")
        print(f"使用的工况名称列: 第{condition_col}列")

        # 读取工况名称
        condition_names = []
        try:
            condition_names = gongkuang(
                file_path=file_path,
                excel_range=excel_range,
                condition_col=condition_col
            )
            print(f"成功读取工况名称: {condition_names}")
        except Exception as e:
            print(f"读取工况名称时出错: {e}")
            # 生成默认工况名称
            total_columns = end_col - start_col + 1
            num_conditions = total_columns // 3
            if total_columns % 3 != 0:
                num_conditions += 1
            condition_names = [f"工况{i+1}" for i in range(num_conditions)]
            print(f"使用默认工况名称: {condition_names}")

        # 获取所需数据 - 使用sum_result
        sum_result = result_dict.get('sum_result', [])

        # 验证sum_result格式
        if not sum_result or len(sum_result) != 3:
            raise ValueError(f"求和结果格式错误，期望3个子列表，实际得到{len(sum_result)}个")

        # 将sum_result作为X、Y、Z三列数据
        x_data = sum_result[0] if len(sum_result) > 0 else []
        y_data = sum_result[1] if len(sum_result) > 1 else []
        z_data = sum_result[2] if len(sum_result) > 2 else []

        print(f"X数据长度: {len(x_data)}")
        print(f"Y数据长度: {len(y_data)}")
        print(f"Z数据长度: {len(z_data)}")

        # 确定行数 - 使用工况名称的数量或数据长度的最大值
        data_lengths = [len(x_data), len(y_data), len(z_data)]
        max_data_length = max(data_lengths) if data_lengths else 0

        if condition_names:
            num_rows = len(condition_names)
            print(f"使用工况名称数量作为行数: {num_rows}")
        else:
            num_rows = max_data_length
            print(f"使用最大数据长度作为行数: {num_rows}")

        # 验证行数是否一致
        if condition_names and len(condition_names) != max_data_length:
            print(f"警告: 工况名称数量({len(condition_names)})与最大数据长度({max_data_length})不一致")
            # 使用较大的值确保所有数据都能显示
            num_rows = max(len(condition_names), max_data_length)
            print(f"使用较大值作为行数: {num_rows}")

        print(f"最终确定的数据行数: {num_rows}")

        # 创建新的工作簿
        wb = Workbook()
        # 删除默认创建的工作表
        wb.remove(wb.active)

        # 工作表1: 详细结果
        ws1 = wb.create_sheet("详细结果")
        print("创建工作表1: 详细结果")

        # 设置标题行 - 修改为X、Y、Z
        headers = ['工况名称', 'X', 'Y', 'Z']
        for col_idx, header in enumerate(headers, 1):
            ws1.cell(row=1, column=col_idx, value=header)
            ws1.cell(row=1, column=col_idx).font = Font(bold=True)

        # 填充数据 - 工况名称作为第一列，X、Y、Z作为第二、三、四列
        for row_idx in range(num_rows):
            # 第一列：工况名称
            if row_idx < len(condition_names):
                ws1.cell(row=row_idx + 2, column=1, value=condition_names[row_idx])
            else:
                ws1.cell(row=row_idx + 2, column=1, value=f"工况{row_idx + 1}")

            # 第二列：X数据
            if row_idx < len(x_data):
                value = x_data[row_idx]
                ws1.cell(row=row_idx + 2, column=2, value=value)
            else:
                ws1.cell(row=row_idx + 2, column=2, value=None)

            # 第三列：Y数据
            if row_idx < len(y_data):
                value = y_data[row_idx]
                ws1.cell(row=row_idx + 2, column=3, value=value)
            else:
                ws1.cell(row=row_idx + 2, column=3, value=None)

            # 第四列：Z数据
            if row_idx < len(z_data):
                value = z_data[row_idx]
                ws1.cell(row=row_idx + 2, column=4, value=value)
            else:
                ws1.cell(row=row_idx + 2, column=4, value=None)

        # 设置列宽
        column_widths = [20, 15, 15, 15]
        for i, width in enumerate(column_widths, 1):
            col_letter = chr(64 + i)
            ws1.column_dimensions[col_letter].width = width

        # 为最大值添加黄色背景
        yellow_fill = PatternFill(start_color='FFFF00', end_color='FFFF00', fill_type='solid')

        # 为X、Y、Z三列的最大值标黄
        for col_idx in range(2, 5):  # B到D列（X、Y、Z）
            max_value = None
            max_rows = []

            # 找到最大值
            for row_idx in range(2, num_rows + 2):
                cell_value = ws1.cell(row=row_idx, column=col_idx).value
                if cell_value is not None:
                    try:
                        num_value = float(cell_value)
                        if max_value is None or num_value > max_value:
                            max_value = num_value
                            max_rows = [row_idx]
                        elif num_value == max_value:
                            max_rows.append(row_idx)
                    except (ValueError, TypeError):
                        continue

            # 标记所有等于最大值的单元格
            if max_value is not None:
                for row_idx in max_rows:
                    ws1.cell(row=row_idx, column=col_idx).fill = yellow_fill

        # 工作表2: 统计结果
        ws2 = wb.create_sheet("统计结果")
        print("创建工作表2: 统计结果")

        # 设置标题行
        stats_headers = ['统计项', '数值', '说明']
        for col_idx, header in enumerate(stats_headers, 1):
            ws2.cell(row=1, column=col_idx, value=header)
            ws2.cell(row=1, column=col_idx).font = Font(bold=True)

        # 添加统计信息
        row_idx = 2
        all_values = []

        # 添加X、Y、Z的统计信息
        for i, col_name in enumerate(['X', 'Y', 'Z']):
            col_data = []
            if i == 0:
                col_data = [x for x in x_data if x is not None]
            elif i == 1:
                col_data = [x for x in y_data if x is not None]
            elif i == 2:
                col_data = [x for x in z_data if x is not None]

            if col_data:
                col_max = max(col_data) if col_data else 0
                col_min = min(col_data) if col_data else 0
                col_avg = sum(col_data) / len(col_data) if col_data else 0

                # 最大值
                ws2.cell(row=row_idx, column=1, value=f'{col_name}最大值')
                ws2.cell(row=row_idx, column=2, value=col_max)
                ws2.cell(row=row_idx, column=3, value=f'{col_name}数据中的最大值')
                all_values.append(col_max)
                row_idx += 1

                # 最小值
                ws2.cell(row=row_idx, column=1, value=f'{col_name}最小值')
                ws2.cell(row=row_idx, column=2, value=col_min)
                ws2.cell(row=row_idx, column=3, value=f'{col_name}数据中的最小值')
                all_values.append(col_min)
                row_idx += 1

                # 平均值
                ws2.cell(row=row_idx, column=1, value=f'{col_name}平均值')
                ws2.cell(row=row_idx, column=2, value=col_avg)
                ws2.cell(row=row_idx, column=3, value=f'{col_name}数据的平均值')
                all_values.append(col_avg)
                row_idx += 1


        # 设置统计结果工作表的列宽
        stats_widths = [20, 15, 25]
        for i, width in enumerate(stats_widths, 1):
            col_letter = chr(64 + i)
            ws2.column_dimensions[col_letter].width = width

        # 为统计结果工作表中的最大值标黄
        if all_values:
            overall_max = max(all_values) if all_values else 0
            for row in range(2, row_idx):
                value = ws2.cell(row=row, column=2).value
                if value is not None and value == overall_max:
                    ws2.cell(row=row, column=2).fill = yellow_fill

        # 保存工作簿
        wb.save(output_file)

        print(f"结果已成功保存到: {output_file}")
        print(f"注意: 工况名称已从第{condition_col}列自动读取")
        print("注意: X、Y、Z三列的最大值已用黄色背景标记")
        return output_file

    except Exception as e:
        raise Exception(f"保存结果到Excel时出错: {str(e)}")



def read_condition_data(file_path: str,
                        condition_ranges: List[Tuple[int, int, int, int]],
                        # 每个工况的数据范围 (start_row, end_row, start_col, end_col)
                        sheet_name: Union[str, int] = 0,
                        header: Optional[int] = None) -> List[List[List[Union[float, int, str]]]]:
    """
    读取多个工况数据范围的数据

    参数:
    ----------
    file_path : str
        Excel文件路径
    condition_ranges : List[Tuple[int, int, int, int]]
        每个工况的数据范围列表
    sheet_name : Union[str, int], default=0
        工作表名称或索引
    header : Optional[int], default=None
        表头行，None表示无表头

    返回:
    ----------
    List[List[List[Union[float, int, str]]]]
        读取的数据列表，每个元素代表一个工况的数据
    """
    try:
        all_condition_data = []

        for i, (start_row, end_row, start_col, end_col) in enumerate(condition_ranges):
            print(f"读取第{i + 1}个工况数据范围: 行{start_row}-{end_row}, 列{start_col}-{end_col}")

            # 使用修改后的read_excel_data函数读取数据
            condition_data = read_excel_data(
                file_path=file_path,
                start_row=start_row,
                end_row=end_row,
                start_col=start_col,
                end_col=end_col,
                sheet_name=sheet_name,
                header=header
            )

            all_condition_data.append(condition_data)

        return all_condition_data

    except Exception as e:
        raise Exception(f"读取工况数据时出错: {str(e)}")


# 修改主函数调用
if __name__ == "__main__":
    try:
        # 1. 设置文件路径
        file_path = r"E:\项目二22222222222222222\代码\行读取\文档三.xlsx"

        # 2. 直接指定Excel数据范围
        excel_range = (1, 120, 7, 9)  # 起始行1，结束行120，起始列7，结束列9
        print(f"设置的数据范围: 行{excel_range[0]}-{excel_range[1]}, 列{excel_range[2]}-{excel_range[3]}")

        # 3. 设置独立的工况名称列
        condition_col = 1  # 工况名称在第1列
        print(f"设置的工况名称列: 第{condition_col}列")

        # 4. 设置角度数据（可选，不设置使用默认值）
        angle_data = [
            [35.937, 65.656, 114.694],
            [111.825, 100.987, 155.306],
            [62.991, 152.997, 89.939]
        ]

        # 5. 设置投影面值（可选，不设置会提示输入）
        projection_areas = (100.0, 150.0, 200.0)  # a, b, c

        # 6. 设置输出文件路径（可选）
        output_file = r"E:\项目二22222222222222222\项目五\列读取\1111111列结果输出.xlsx"

        # 在主程序末尾添加以下代码：

        # 执行集成求和处理
        print("开始执行集成求和处理...")
        result_dict = integrated_sum_process(
            file_path=file_path,
            excel_range=excel_range,
            angle_data=angle_data
        )

        # 显示结果
        display_sum_results(result_dict, show_details=True)

        # 保存结果到Excel
        print("\n保存结果到Excel文件...")
        saved_file = save_results_to_excel(
            result_dict=result_dict,
            file_path=file_path,
            output_file=output_file,
            condition_col=condition_col
        )

        print(f"\n处理完成！结果已保存到: {saved_file}")

    except Exception as e:
        print(f"错误: {e}")
