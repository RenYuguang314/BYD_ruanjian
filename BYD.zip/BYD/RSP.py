
import pandas as pd
import math
from typing import List, Union, Optional, Tuple, Dict
import numpy as np
import os
import tempfile
from typing import List, Union, Optional, Tuple, Dict
import pandas as pd
import math
from typing import List, Union, Optional, Tuple
import numpy as np
import os
import tempfile


def read_data(
        file_path: str,
        start_row: int,
        end_row: int,
        start_col: int,
        end_col: int,
        sheet_name: Union[str, int] = 0,
        header: Optional[int] = None
) -> List[List[Union[float, int, str]]]:
    """
    统一数据读取函数，使用pandas自动检测文件格式
    """
    # 标准化路径（处理反斜杠/转义问题）+ 检查文件是否存在
    file_path = os.path.normpath(file_path)
    if not os.path.exists(file_path):
        raise FileNotFoundError(f"文件不存在: {file_path}")

    print(f"读取文件: {file_path}")

    try:
        # 提取扩展名（统一小写，避免大小写问题）
        file_extension = os.path.splitext(file_path)[1].lower()

        # 按扩展名精准读取，避免冗余的自动检测
        if file_extension in ['.xlsx', '.xls']:
            df = pd.read_excel(file_path, sheet_name=sheet_name, header=header)
        elif file_extension == '.csv':
            # 使用改进的自动转换函数处理CSV文件
            return read_data_auto_convert(file_path, start_row, end_row, start_col, end_col, sheet_name, header)
        else:
            raise ValueError(f"不支持的文件格式: {file_extension}，仅支持.xlsx/.xls/.csv")

        print(f"成功读取文件，数据形状: {df.shape}")

        # 将Excel行列编号(1-based)转换为Python索引(0-based)
        start_row_idx = start_row - 1
        end_row_idx = end_row - 1
        start_col_idx = start_col - 1
        end_col_idx = end_col - 1

        # 验证行列范围
        if start_row_idx < 0 or end_row_idx >= len(df) or start_row_idx > end_row_idx:
            raise ValueError(f"行范围无效: {start_row}-{end_row}, 数据行数={len(df)}")

        if start_col_idx < 0 or end_col_idx >= len(df.columns) or start_col_idx > end_col_idx:
            raise ValueError(f"列范围无效: {start_col}-{end_col}, 数据列数={len(df.columns)}")

        # 提取指定范围的数据
        all_data = []
        for row_idx in range(start_row_idx, end_row_idx + 1):
            row_data = []
            for col_idx in range(start_col_idx, end_col_idx + 1):
                value = df.iloc[row_idx, col_idx]
                row_data.append(value if not pd.isna(value) else None)
            all_data.append(row_data)

        print(f"成功读取 {len(all_data)} 行数据")
        return all_data

    except ValueError as ve:
        raise ValueError(f"文件读取参数错误: {str(ve)}")
    except Exception as e:
        raise Exception(f"读取文件时出错: {str(e)}")

def read_excel_data(
        file_path: str,
        start_row: int,
        end_row: int,
        start_col: int,
        end_col: int,
        sheet_name: Union[str, int] = 0,
        header: Optional[int] = None
) -> List[List[Union[float, int, str]]]:
    """
    读取Excel文件中指定行和列范围的数据，按横向（先行后列）顺序读取

    注意：行和列编号都从1开始（符合Excel习惯）

    参数:
    ----------
    file_path : str
        Excel文件路径
    start_row : int
        起始行编号（从1开始）- 数据行起始位置
    end_row : int
        结束行编号（包含该行，从1开始）- 数据行结束位置
    start_col : int
        起始列编号（从1开始）
    end_col : int
        结束列编号（包含该列，从1开始）
    sheet_name : Union[str, int], default=0
        工作表名称或索引
    header : Optional[int], default=None
        表头行，None表示无表头

    返回:
    ----------
    List[List[Union[float, int, str]]]
        读取的数据列表，每个子列表代表一行的数据
    """
    # 标准化路径 + 提前检查文件存在性
    file_path = os.path.normpath(file_path)
    if not os.path.exists(file_path):
        raise FileNotFoundError(f"文件未找到: {file_path}")

    # 校验文件扩展名
    file_extension = os.path.splitext(file_path)[1].lower()
    if file_extension not in ['.xlsx', '.xls']:
        raise ValueError(f"该函数仅支持Excel文件，当前文件格式: {file_extension}")

    try:
        # 读取整个工作表
        df = pd.read_excel(file_path, sheet_name=sheet_name, header=header)

        # 将Excel行列编号(1-based)转换为Python索引(0-based)
        start_row_idx = start_row - 1
        end_row_idx = end_row - 1
        start_col_idx = start_col - 1
        end_col_idx = end_col - 1

        # 验证行列范围是否有效
        if start_row_idx < 0 or end_row_idx >= len(df) or start_row_idx > end_row_idx:
            raise ValueError(f"行范围无效: start_row={start_row}, end_row={end_row}, 数据行数={len(df)}")

        if start_col_idx < 0 or end_col_idx >= len(df.columns) or start_col_idx > end_col_idx:
            raise ValueError(f"列范围无效: start_col={start_col}, end_col={end_col}, 数据列数={len(df.columns)}")

        # 计算需要读取的数据行（第3行、第6行、第9行等）
        data_rows = []
        current_row = start_row_idx

        # 找到第一个数据行（第3行或其后第一个3的倍数的行）
        while current_row <= end_row_idx:
            # 计算当前行相对于起始行的偏移量
            row_offset = current_row - start_row_idx + 1
            data_rows.append(current_row)
            current_row += 1

        print(f"检测到 {len(data_rows)} 个数据行: {[r + 1 for r in data_rows]}")

        # 创建空列表来存储数据（按行存储）
        all_data = []

        # 横向读取：先遍历行，再遍历列
        for row_idx in data_rows:
            row_data = []

            # 遍历当前行的所有列
            for col in range(start_col_idx, end_col_idx + 1):
                value = df.iloc[row_idx, col]

                # 处理NaN值（空单元格）
                if pd.isna(value):
                    row_data.append(None)
                else:
                    row_data.append(value)

            all_data.append(row_data)

        print(f"读取的数据（按行存储）: {all_data}")
        return all_data

    except Exception as e:
        raise Exception(f"读取Excel文件时出错: {str(e)}")


def read_data_auto_convert(
        file_path: str,
        start_row: int,
        end_row: int,
        start_col: int,
        end_col: int,
        sheet_name: Union[str, int] = 0,
        header: Optional[int] = None,
        delete_temp_file: bool = True
) -> List[List[Union[float, int, str]]]:
    """
    自动读取数据文件，仅当文件为CSV格式时转换为XLSX后再读取；Excel文件直接读取
    """
    # 标准化路径 + 提前检查文件存在性
    file_path = os.path.normpath(file_path)
    if not os.path.exists(file_path):
        raise FileNotFoundError(f"文件不存在: {file_path}")

    # 提取扩展名
    file_extension = os.path.splitext(file_path)[1].lower()

    # Excel文件直接读取
    if file_extension in ['.xlsx', '.xls']:
        return read_excel_data(file_path, start_row, end_row, start_col, end_col, sheet_name, header)

    # CSV文件转换后读取
    elif file_extension == '.csv':
        # 创建临时XLSX文件
        with tempfile.NamedTemporaryFile(suffix='.xlsx', delete=False) as temp_file:
            temp_xlsx_path = temp_file.name

        try:
            print("检测到CSV文件，正在转换为XLSX格式...")

            # 读取CSV文件（跳过注释行）
            df = pd.read_csv(file_path, comment='#')

            # 保存为临时XLSX文件
            df.to_excel(temp_xlsx_path, index=False, header=header is not None)
            print(f"已创建临时XLSX文件: {temp_xlsx_path}")

            # 计算原始CSV文件中的有效数据行（跳过注释行）
            with open(file_path, 'r', encoding='utf-8') as f:
                lines = f.readlines()
            comment_lines = sum(1 for line in lines if line.strip().startswith('#'))
            print(f"检测到 {comment_lines} 行注释")

            # 修正行号调整逻辑：+1 来补偿注释行的影响
            adjusted_start_row = max(1, start_row - comment_lines - 1)
            adjusted_end_row = max(1, end_row - comment_lines - 1)

            if adjusted_start_row > adjusted_end_row:
                raise ValueError("调整行号后起始行大于结束行，请检查行号范围")

            print(f"调整行号: {start_row}-{end_row} -> {adjusted_start_row}-{adjusted_end_row}")

            # 读取临时XLSX文件
            result = read_excel_data(temp_xlsx_path, adjusted_start_row, adjusted_end_row,
                                     start_col, end_col, sheet_name, header)
            return result

        finally:
            # 清理临时文件
            if delete_temp_file and os.path.exists(temp_xlsx_path):
                os.unlink(temp_xlsx_path)
                print("临时文件已清理")
    else:
        raise ValueError(f"不支持的文件格式: {file_extension}，仅支持.xlsx/.xls/.csv")


def find_data_end_row_in_columns(
        file_path: str,
        start_col: int,
        end_col: int,
        start_row: int = 1,
        sheet_name: Union[str, int] = 0,
        header: Optional[int] = None
) -> Dict[str, Union[str, int]]:
    """
    识别指定列范围内的数据结束行（遇到空值的前一行）

    参数:
    ----------
    file_path : str
        文件路径（支持.xlsx/.xls/.csv）
    start_col : int
        起始列编号（从1开始）
    end_col : int
        结束列编号（从1开始）
    start_row : int, default=1
        开始检查的行编号（从1开始）
    sheet_name : Union[str, int], default=0
        工作表名称或索引
    header : Optional[int], default=None
        表头行，None表示无表头

    返回:
    ----------
    Dict[str, Union[str, int]]
        包含以下键的字典：
        - 'converted_file': 转换后的XLSX文件路径（如果是CSV会转换）
        - 'original_file': 原始文件路径
        - 'start_row': 起始行编号
        - 'end_row': 数据结束行编号（在指定列范围内遇到空值的前一行）
        - 'start_col': 起始列编号
        - 'end_col': 结束列编号
        - 'is_converted': 是否进行了CSV到XLSX的转换
    """
    # 标准化路径 + 检查文件存在性
    file_path = os.path.normpath(file_path)
    if not os.path.exists(file_path):
        raise FileNotFoundError(f"文件不存在: {file_path}")

    # 提取扩展名
    file_extension = os.path.splitext(file_path)[1].lower()

    result = {
        'original_file': file_path,
        'converted_file': file_path,
        'start_row': start_row,
        'end_row': -1,
        'start_col': start_col,
        'end_col': end_col,
        'is_converted': False
    }

    try:
        # CSV文件：先转换再识别结束行
        if file_extension == '.csv':
            print("检测到CSV文件，正在转换为XLSX格式并识别结束行...")

            # 创建临时XLSX文件
            with tempfile.NamedTemporaryFile(suffix='.xlsx', delete=False) as temp_file:
                temp_xlsx_path = temp_file.name

            try:
                # 读取CSV文件（跳过注释行）
                df = pd.read_csv(file_path, comment='#')
                print(f"CSV文件读取成功，数据形状: {df.shape}")

                # 保存为临时XLSX文件
                df.to_excel(temp_xlsx_path, index=False, header=header is not None)
                print(f"已创建临时XLSX文件: {temp_xlsx_path}")

                # 计算注释行数并调整行号
                with open(file_path, 'r', encoding='utf-8') as f:
                    lines = f.readlines()
                comment_lines = sum(1 for line in lines if line.strip().startswith('#'))
                print(f"检测到 {comment_lines} 行注释")

                # 调整行号（补偿注释行）
                adjusted_start_row = max(1, start_row + comment_lines)
                print(f"调整后的起始行: {adjusted_start_row}")

                # 在转换后的XLSX文件中识别结束行
                end_row = find_end_row_by_columns(temp_xlsx_path, start_col, end_col,
                                                  adjusted_start_row, sheet_name)

                result['converted_file'] = temp_xlsx_path
                result['is_converted'] = True
                result['end_row'] = end_row
                result['start_row'] = adjusted_start_row

            except Exception as e:
                # 如果转换失败，清理临时文件
                if os.path.exists(temp_xlsx_path):
                    os.unlink(temp_xlsx_path)
                raise e

        # Excel文件：直接识别结束行
        elif file_extension in ['.xlsx', '.xls']:
            print("检测到Excel文件，直接识别结束行...")

            # 直接识别结束行
            end_row = find_end_row_by_columns(file_path, start_col, end_col, start_row, sheet_name)

            result['converted_file'] = file_path
            result['is_converted'] = False
            result['end_row'] = end_row

        else:
            raise ValueError(f"不支持的文件格式: {file_extension}，仅支持.xlsx/.xls/.csv")

        print(f"识别完成 - 起始行: {result['start_row']}, 结束行: {result['end_row']}, "
              f"起始列: {result['start_col']}, 结束列: {result['end_col']}")

        return result

    except Exception as e:
        raise Exception(f"识别数据结束行时出错: {str(e)}")


def find_end_row_by_columns(
        xlsx_path: str,
        start_col: int,
        end_col: int,
        start_row: int,
        sheet_name: Union[str, int] = 0
) -> int:
    """
    在指定列范围内查找数据结束行（遇到空值的前一行）

    逻辑：从起始行开始向下检查，直到找到指定列范围内全部为空的行，返回该行的前一行

    参数:
    ----------
    xlsx_path : str
        Excel文件路径
    start_col : int
        起始列编号（从1开始）
    end_col : int
        结束列编号（从1开始）
    start_row : int
        开始检查的行编号（从1开始）
    sheet_name : Union[str, int], default=0
        工作表名称或索引

    返回:
    ----------
    int
        数据结束行编号（从1开始），遇到空值的前一行
    """
    try:
        # 读取Excel文件
        df = pd.read_excel(xlsx_path, sheet_name=sheet_name, header=None)
        print(f"Excel文件读取成功，数据形状: {df.shape}")

        # 转换为0-based索引
        start_row_idx = start_row - 1
        start_col_idx = start_col - 1
        end_col_idx = end_col - 1

        # 验证列范围
        if start_col_idx < 0 or end_col_idx >= len(df.columns) or start_col_idx > end_col_idx:
            raise ValueError(f"列范围无效: {start_col}-{end_col}, 数据列数={len(df.columns)}")

        # 验证起始行
        if start_row_idx < 0 or start_row_idx >= len(df):
            raise ValueError(f"起始行无效: {start_row}, 数据行数={len(df)}")

        # 选择指定的列范围
        df_selected = df.iloc[start_row_idx:, start_col_idx:end_col_idx + 1]
        print(f"选择的列范围数据形状: {df_selected.shape}")

        # 从起始行开始向下检查，找到第一个全部为空的行
        end_row_idx = start_row_idx  # 默认结束行为起始行

        for i in range(len(df_selected)):
            row_idx = i
            row = df_selected.iloc[row_idx]

            # 检查该行在指定列范围内是否全部为空
            if row.isnull().all():
                # 找到第一个全部为空的行，结束行为前一行的1-based编号
                if row_idx == 0:
                    # 如果第一行就是空行，返回起始行前一行
                    end_row = start_row - 1 if start_row > 1 else 1
                else:
                    # 返回前一行的1-based编号
                    end_row = row_idx + start_row - 1

                print(f"在第{row_idx + start_row}行发现空行，数据结束行: {end_row}")
                return end_row

        # 如果所有行都有数据，返回最后一行
        end_row = len(df_selected) + start_row - 1
        print(f"所有行都有数据，返回最后一行: {end_row}")
        return end_row

    except Exception as e:
        raise Exception(f"在XLSX文件中查找结束行时出错: {str(e)}")


def read_data_with_end_row_detection(
        file_path: str,
        start_col: int,
        end_col: int,
        start_row: int = 1,
        sheet_name: Union[str, int] = 0,
        header: Optional[int] = None
) -> Tuple[List[List[Union[float, int, str]]], Dict[str, Union[str, int]]]:
    """
    自动检测数据结束行并读取数据的完整函数

    返回读取的数据和文件信息
    """
    # 第一步：识别数据结束行和文件转换
    file_info = find_data_end_row_in_columns(
        file_path=file_path,
        start_col=start_col,
        end_col=end_col,
        start_row=start_row,
        sheet_name=sheet_name,
        header=header
    )

    # 第二步：使用识别出的范围读取数据
    try:
        data = read_data_auto_convert(
            file_path=file_info['converted_file'],
            start_row=file_info['start_row'],
            end_row=file_info['end_row'],
            start_col=file_info['start_col'],
            end_col=file_info['end_col'],
            sheet_name=sheet_name,
            header=header,
            delete_temp_file=False  # 不删除临时文件，由调用方处理
        )

        return data, file_info

    finally:
        # 如果是转换的临时文件，在使用后清理
        if file_info['is_converted'] and os.path.exists(file_info['converted_file']):
            os.unlink(file_info['converted_file'])
            print("临时文件已清理")


def cleanup_converted_file(file_info: Dict[str, Union[str, int]]):
    """
    清理转换的临时文件
    """
    if file_info.get('is_converted') and os.path.exists(file_info['converted_file']):
        try:
            os.unlink(file_info['converted_file'])
            print(f"已清理临时文件: {file_info['converted_file']}")
        except Exception as e:
            print(f"清理临时文件失败: {e}")





def calculate_cosines_from_manual(manual_angles: List[List[float]] = None) -> List[List[float]]:
    """
    从手动指定的角度数据计算余弦值

    参数:
    ----------
    manual_angles : List[List[float]], optional
        手动指定的3x3角度数据

    返回:
    ----------
    List[List[float]]
        3x3格式的余弦值数据
    """
    print("使用的手动角度数据:")
    for i, row in enumerate(manual_angles):
        print(f"  第{i + 1}行: {row}")

    cosine_data = []

    for row in manual_angles:
        cosine_row = []
        for angle in row:
            cosine_value = math.cos(math.radians(angle))
            cosine_row.append(cosine_value)
        cosine_data.append(cosine_row)

    return manual_angles, cosine_data


def convert_to_numeric(data_list: List[List]) -> List[List]:
    """
    将读取的数据转换为数值类型（如果可能）

    参数:
    ----------
    data_list : List[List]
        原始数据列表

    返回:
    ----------
    List[List]
        转换后的数据列表
    """
    converted_data = []

    for column in data_list:
        converted_column = []
        for value in column:
            if value is None:
                converted_column.append(None)
            else:
                # 尝试转换为数值
                try:
                    if isinstance(value, (int, float, np.integer, np.floating)):
                        converted_column.append(float(value))
                    else:
                        # 尝试从字符串转换
                        converted_column.append(float(str(value).replace(',', '')))
                except (ValueError, TypeError):
                    # 无法转换，保留原值
                    converted_column.append(value)
        converted_data.append(converted_column)

    return converted_data

def integrated_process(file_path: str,
                       excel_range: Tuple[int, int, int, int],
                       angle_data: List[List[float]] = None) -> dict:
    """
    集成流程函数：将文件读取、角度输入、余弦计算和分解计算整合到一个函数中

    参数:
    ----------
    file_path : str
        Excel文件路径
    excel_range : Tuple[int, int, int, int]
        Excel数据范围 (start_row, end_row, start_col, end_col)
    angle_data : List[List[float]], optional
        角度数据，如果为None则使用默认值

    返回:
    ----------
    dict
        包含所有结果和信息的字典
    """
    try:
        # 1. 读取Excel数据
        start_row, end_row, start_col, end_col = excel_range
        print("=" * 60)
        print("开始集成处理流程")
        print("=" * 60)

        print(f"1. 读取Excel数据: {file_path}")
        print(f"   范围: 行{start_row}-{end_row}, 列{start_col}-{end_col}")

        raw_excel_data = read_data(
            file_path=file_path,
            start_row=start_row,
            end_row=end_row,
            start_col=start_col,
            end_col=end_col
        )

        # 转换为数值类型
        excel_data = convert_to_numeric(raw_excel_data)

        if not excel_data or len(excel_data) == 0:
            raise ValueError("Excel数据为空")

        print(f"   Excel数据形状: {len(excel_data)}列 × {len(excel_data[0]) if excel_data[0] else 0}行")

        # 2. 使用角度数据
        print("\n2. 使用角度数据")

        # 3. 计算余弦值
        print("\n3. 计算余弦值")
        _, cosine_data = calculate_cosines_from_manual(angle_data)

        # 4. 执行分解计算
        print("\n4. 执行分解计算")
        result = fenjie_simplified(excel_data, cosine_data)

        return result

    except Exception as e:
        raise Exception(f"集成处理流程出错: {str(e)}")


def fenjie_simplified(excel_data: List[List[Union[float, int, str]]],
                      cosine_data: List[List[float]]) -> dict:
    """
    简化版分解函数：只需要Excel数据和余弦值数据

    参数:
    ----------
    excel_data : List[List[Union[float, int, str]]]
        从Excel读取的数据
    cosine_data : List[List[float]]
        余弦值数据，必须是3x3格式

    返回:
    ----------
    dict
        包含所有结果和信息的字典
    """
    try:
        # 验证余弦值数据是否为3x3格式
        if len(cosine_data) != 3 or any(len(row) != 3 for row in cosine_data):
            raise ValueError(
                f"余弦值数据必须是3x3格式，当前形状: {len(cosine_data)}x{len(cosine_data[0]) if cosine_data else 0}")

        # 验证Excel数据
        if not excel_data or len(excel_data) == 0:
            raise ValueError("Excel数据为空")

        print("余弦值数据:")
        for i, row in enumerate(cosine_data):
            print(f"  第{i + 1}行: {[f'{x:.6f}' for x in row]}")

        print("232423511531515151515151515155",excel_data)
        # 执行分解计算
        result_3d = []
        total_calculations = 0
        successful_calculations = 0

        for copy_idx in range(3):
            copy_result = []

            # 获取当前副本对应的余弦值行
            cosine_row = cosine_data[copy_idx]

            print(f"\n处理第{copy_idx + 1}个副本，使用余弦值行{cosine_row}")

            # 遍历Excel数据的每一列
            for col_idx, column in enumerate(excel_data):
                multiplied_column = []

                # 遍历列中的每个元素
                for row_idx, value in enumerate(column):
                    total_calculations += 1

                    # 处理None值
                    if value is None:
                        multiplied_column.append(None)
                        continue

                    try:
                        # 转换为数值
                        if isinstance(value, (int, float, np.integer, np.floating)):
                            numeric_value = float(value)
                        else:
                            numeric_value = float(str(value).replace(',', ''))

                        # 使用对应位置的角度余弦值相乘
                        angle_idx = row_idx % len(cosine_row)  # 循环使用角度值
                        result_value = numeric_value * cosine_row[angle_idx]
                        multiplied_column.append(result_value)
                        successful_calculations += 1

                    except (ValueError, TypeError) as e:
                        print(f"  警告: 第{col_idx + 1}列第{row_idx + 1}行数据转换失败: {value}")
                        multiplied_column.append(None)

                copy_result.append(multiplied_column)

            result_3d.append(copy_result)

        # 统计信息
        stats = {
            'excel_data_shape': f"{len(excel_data)}列×{len(excel_data[0]) if excel_data[0] else 0}行",
            'cosine_data_shape': f"{len(cosine_data)}行×{len(cosine_data[0])}列",
            'result_shape': f"{len(result_3d)}副本×{len(result_3d[0])}列×{len(result_3d[0][0]) if result_3d[0] else 0}行",
            'total_calculations': total_calculations,
            'successful_calculations': successful_calculations,
            'success_rate': successful_calculations / total_calculations * 100 if total_calculations > 0 else 0
        }
        print("88888888888888888888888888888888",result_3d)
        return {
            'excel_data': excel_data,
            'cosine_data': cosine_data,
            'result_3d': result_3d,
            'statistics': stats
        }

    except Exception as e:
        raise Exception(f"简化版分解计算时出错: {str(e)}")


def display_integrated_results(result_dict: dict, show_details: bool = False):
    """
    显示集成处理结果

    参数:
    ----------
    result_dict : dict
        integrated_process函数的返回结果
    show_details : bool
        是否显示详细结果
    """
    excel_data = result_dict['excel_data']
    cosine_data = result_dict['cosine_data']
    result_3d = result_dict['result_3d']
    stats = result_dict['statistics']

    print("\n" + "=" * 100)
    print("集成处理结果")
    print("=" * 100)

    print(f"Excel数据形状: {stats['excel_data_shape']}")
    print(f"余弦值数据形状: {stats['cosine_data_shape']}")
    print(f"结果数据形状: {stats['result_shape']}")
    print(f"计算成功率: {stats['successful_calculations']}/{stats['total_calculations']} "
          f"({stats['success_rate']:.1f}%)")

    # 显示每个副本的结果摘要
    for copy_idx, copy_data in enumerate(result_3d):
        print(f"\n第{copy_idx + 1}个副本结果:")
        print("-" * 80)

        # 显示前3列的前5行
        for col_idx in range(min(3, len(copy_data))):
            preview_values = [f'{x:.6f}' if x is not None else 'None' for x in copy_data[col_idx][:5]]
            print(f"  第{col_idx + 1}列前5个值: {preview_values}")

        if show_details:
            print(f"  详细数据:")
            for col_idx, col_data in enumerate(copy_data):
                print(f"    第{col_idx + 1}列: {[f'{x:.6f}' if x is not None else 'None' for x in col_data]}")


def save_integrated_results(result_dict: dict, filename: str = "integrated_results.txt"):
    """
    保存集成处理结果到文件
    """
    with open(filename, 'w', encoding='utf-8') as f:
        f.write("集成处理结果\n")
        f.write("=" * 50 + "\n\n")

        f.write("数据信息:\n")
        f.write(f"  Excel数据形状: {result_dict['statistics']['excel_data_shape']}\n")
        f.write(f"  余弦值数据形状: {result_dict['statistics']['cosine_data_shape']}\n")
        f.write(f"  计算成功率: {result_dict['statistics']['success_rate']:.1f}%\n\n")

        f.write("余弦值数据:\n")
        for i, row in enumerate(result_dict['cosine_data']):
            f.write(f"  第{i + 1}行: {[f'{x:.6f}' for x in row]}\n")

        f.write("\n分解结果:\n")
        for copy_idx, copy_data in enumerate(result_dict['result_3d']):
            f.write(f"\n第{copy_idx + 1}个副本:\n")
            for col_idx, col_data in enumerate(copy_data):
                f.write(f"  第{col_idx + 1}列: {[f'{x:.6f}' if x is not None else 'None' for x in col_data]}\n")


def sum_fenjie_result(result_3d: List[List[List[float]]]) -> List[List[float]]:
    """
    对分解函数的结果进行求和

    参数:
    ----------
    result_3d : List[List[List[float]]]
        分解函数返回的三维数组，格式为 [[[],[],[]],[[],[],[]],[[],[],[]]]

    返回:
    ----------
    List[List[float]]
        求和后的二维数组，格式为 [[副本1的列和], [副本2的列和], [副本3的列和]]
    """
    try:
        # 验证输入数据
        if not result_3d or len(result_3d) == 0:
            raise ValueError("输入的三维数组为空")

        print("开始对分解结果进行求和计算")
        print(
            f"输入数据形状: {len(result_3d)}副本 × {len(result_3d[0])}列 × {len(result_3d[0][0]) if result_3d[0] else 0}行")

        # 创建结果数组
        sum_result = []

        # 遍历每个副本
        for copy_idx, copy_data in enumerate(result_3d):
            copy_sum = []

            print(f"\n处理第{copy_idx + 1}个副本:")

            # 遍历副本中的每一列
            for col_idx, column in enumerate(copy_data):
                # 对当前列的所有元素求和
                column_sum = 0.0
                valid_count = 0

                for value in column:
                    if value is not None:
                        try:
                            column_sum += float(value)
                            valid_count += 1
                        except (ValueError, TypeError):
                            # 无法转换为数值，跳过
                            pass

                copy_sum.append(column_sum)
                print(f"  第{col_idx + 1}列: 求和 = {column_sum:.6f} (有效值: {valid_count}/{len(column)})")

            sum_result.append(copy_sum)

        print(f"\n求和结果形状: {len(sum_result)}副本 × {len(sum_result[0])}列")
        return sum_result

    except Exception as e:
        raise Exception(f"求和计算时出错: {str(e)}")


def integrated_sum_process(file_path: str,
                           excel_range: Tuple[int, int, int, int],
                           angle_data: List[List[float]] = None) -> dict:
    """
    集成求和处理流程：包含文件读取、角度输入、余弦计算、分解计算和求和计算

    参数:
    ----------
    file_path : str
        Excel文件路径
    excel_range : Tuple[int, int, int, int]
        Excel数据范围 (start_row, end_row, start_col, end_col)
    angle_data : List[List[float]], optional
        角度数据，如果为None则使用默认值

    返回:
    ----------
    dict
        包含所有结果和信息的字典
    """
    try:
        # 1. 执行集成处理流程
        print("=" * 60)
        print("开始集成求和处理流程")
        print("=" * 60)

        # 修改这里：传递 angle_data 参数
        fenjie_result = integrated_process(file_path, excel_range, angle_data)

        # 2. 对分解结果进行求和
        print("\n" + "=" * 60)
        print("执行求和计算")
        print("=" * 60)

        sum_result = sum_fenjie_result(fenjie_result['result_3d'])

        # 3. 将求和结果添加到原字典中
        fenjie_result['sum_result'] = sum_result

        # 4. 添加求和统计信息
        fenjie_result['statistics']['sum_shape'] = f"{len(sum_result)}副本×{len(sum_result[0]) if sum_result else 0}列"

        # 计算总和统计
        total_sum = 0.0
        for copy_sum in sum_result:
            for col_sum in copy_sum:
                total_sum += col_sum

        fenjie_result['statistics']['total_sum'] = total_sum
        fenjie_result['statistics']['average_sum_per_column'] = total_sum / (
                    len(sum_result) * len(sum_result[0])) if sum_result and len(sum_result[0]) > 0 else 0

        return fenjie_result

    except Exception as e:
        raise Exception(f"集成求和处理流程出错: {str(e)}")


def display_sum_results(result_dict: dict, show_details: bool = False):
    """
    显示求和结果

    参数:
    ----------
    result_dict : dict
        integrated_sum_process函数的返回结果
    show_details : bool
        是否显示详细结果
    """
    if 'sum_result' not in result_dict:
        print("错误: 结果字典中不包含求和结果")
        return

    sum_result = result_dict['sum_result']
    stats = result_dict['statistics']

    print("\n" + "=" * 100)
    print("求和计算结果")
    print("=" * 100)

    print(f"求和结果形状: {stats['sum_shape']}")
    print(f"总和: {stats['total_sum']:.6f}")
    print(f"每列平均值: {stats['average_sum_per_column']:.6f}")

    # 显示每个副本的求和结果
    for copy_idx, copy_sum in enumerate(sum_result):
        print(f"\n第{copy_idx + 1}个副本的列和:")
        print("-" * 50)

        for col_idx, col_sum in enumerate(copy_sum):
            print(f"  第{col_idx + 1}列: {col_sum:.6f}")

        # 计算副本总和
        copy_total = sum(copy_sum)
        print(f"  副本{copy_idx + 1}总和: {copy_total:.6f}")

    if show_details:
        # 显示原始分解结果
        print(f"\n原始分解结果:")
        result_3d = result_dict['result_3d']
        for copy_idx, copy_data in enumerate(result_3d):
            print(f"\n第{copy_idx + 1}个副本原始数据:")
            for col_idx, col_data in enumerate(copy_data):
                preview_values = [f'{x:.6f}' if x is not None else 'None' for x in col_data[:5]]
                print(f"  第{col_idx + 1}列前5个值: {preview_values}")


def save_sum_results(result_dict: dict, filename: str = "sum_results.txt"):
    """
    保存求和结果到文件
    """
    if 'sum_result' not in result_dict:
        print("错误: 结果字典中不包含求和结果")
        return

    with open(filename, 'w', encoding='utf-8') as f:
        f.write("求和计算结果\n")
        f.write("=" * 50 + "\n\n")

        f.write("统计信息:\n")
        f.write(f"  求和结果形状: {result_dict['statistics']['sum_shape']}\n")
        f.write(f"  总和: {result_dict['statistics']['total_sum']:.6f}\n")
        f.write(f"  每列平均值: {result_dict['statistics']['average_sum_per_column']:.6f}\n\n")

        f.write("各副本列和:\n")
        for copy_idx, copy_sum in enumerate(result_dict['sum_result']):
            f.write(f"\n第{copy_idx + 1}个副本:\n")
            for col_idx, col_sum in enumerate(copy_sum):
                f.write(f"  第{col_idx + 1}列: {col_sum:.6f}\n")
            copy_total = sum(copy_sum)
            f.write(f"  副本总和: {copy_total:.6f}\n")

        f.write("\n原始分解结果摘要:\n")
        result_3d = result_dict['result_3d']
        for copy_idx, copy_data in enumerate(result_3d):
            f.write(f"\n第{copy_idx + 1}个副本原始数据:\n")
            for col_idx, col_data in enumerate(copy_data):
                preview_values = [f'{x:.6f}' if x is not None else 'None' for x in col_data[:3]]
                f.write(f"  第{col_idx + 1}列前3个值: {preview_values}\n")


def calculate_radial_array(sum_result: List[List[float]]) -> List[List[float]]:
    """
    计算径向数组：对索引1和索引2的数组进行平方和开根号计算

    参数:
    ----------
    sum_result : List[List[float]]
        求和函数返回的二维数组，格式为 [[副本1的列和], [副本2的列和], [副本3的列和]]

    返回:
    ----------
    List[List[float]]
        计算后的二维数组，格式为 [[副本1的列和], [径向数组]]
    """
    try:
        # 验证输入数据
        if not sum_result or len(sum_result) != 3:
            raise ValueError("求和结果必须包含3个副本的数据")

        print("开始计算径向数组")
        print(f"输入数据形状: {len(sum_result)}副本 × {len(sum_result[0])}列")

        # 提取副本2和副本3的数据（索引1和2）
        copy_1_data = sum_result[1]  # 索引1
        copy_2_data = sum_result[2]  # 索引2

        # 验证数组长度一致
        if len(copy_1_data) != len(copy_2_data):
            raise ValueError(f"副本2和副本3的列数不一致: {len(copy_1_data)} vs {len(copy_2_data)}")

        # 计算平方和开根号
        radial_array = []
        for i in range(len(copy_1_data)):
            value1 = copy_1_data[i]
            value2 = copy_2_data[i]
            # 计算平方和开根号: sqrt(value1^2 + value2^2)
            radial_value = math.sqrt(value1 ** 2 + value2 ** 2)
            radial_array.append(radial_value)

        print(f"副本2数据: {copy_1_data}")
        print(f"副本3数据: {copy_2_data}")
        print(f"径向计算数组: {[f'{x:.6f}' for x in radial_array]}")

        # 返回结果：副本1的数据和径向数组
        result = [sum_result[0], radial_array]
        print(f"径向数组结果形状: {len(result)}数组 × {len(result[0])}列")
        print("111111111111111111",result)
        return result

    except Exception as e:
        raise Exception(f"计算径向数组时出错: {str(e)}")


def calculate_axial_radial_max(radial_result: List[List[float]]) -> dict:
    """
    计算轴向和径向最大值

    参数:
    ----------
    radial_result : List[List[float]]
        径向数组计算结果，格式为 [[副本1的列和], [径向数组]]

    返回:
    ----------
    dict
        包含轴向和径向最大值的字典
    """
    try:
        # 验证输入数据
        if not radial_result or len(radial_result) != 2:
            raise ValueError("径向数组结果必须包含2个数组")

        print("开始计算轴向和径向最大值")
        print(f"输入数据形状: {len(radial_result)}数组 × {len(radial_result[0])}列")

        # 提取数据
        axial_data = radial_result[0]  # 轴向数据（副本1）
        radial_data = radial_result[1]  # 径向数据

        # 1. 计算轴向最大值（索引0的数组）
        axial_max = max(axial_data) if axial_data else 0.0
        axial_max_index = axial_data.index(axial_max) if axial_max in axial_data else -1

        print(f"\n轴向数据（索引0）: {axial_data}")
        print(f"轴向最大值: {axial_max:.6f} (位置: 第{axial_max_index + 1}列)")

        # 2. 计算径向最大值（索引1的数组）
        radial_max = max(radial_data) if radial_data else 0.0
        radial_max_index = radial_data.index(radial_max) if radial_max in radial_data else -1

        print(f"径向数据（索引1）: {radial_data}")
        print(f"径向最大值: {radial_max:.6f} (位置: 第{radial_max_index + 1}列)")

        # 返回结果
        return {
            'axial_max': {
                'value': axial_max,
                'index': axial_max_index,
                'position': f"第{axial_max_index + 1}列",
                'description': '轴向最大'
            },
            'radial_max': {
                'value': radial_max,
                'index': radial_max_index,
                'position': f"第{radial_max_index + 1}列",
                'description': '径向最大'
            },
            'axial_data': axial_data,
            'radial_data': radial_data,
            'max_values': [axial_max, radial_max]  # 返回轴向和径向最大值的列表
        }

    except Exception as e:
        raise Exception(f"计算轴向和径向最大值时出错: {str(e)}")


def integrated_axial_radial_process(file_path: str,
                                    excel_range: Tuple[int, int, int, int],
                                    angle_data: List[List[float]] = None) -> dict:
    """
    集成轴向径向处理流程：包含文件读取、角度输入、余弦计算、分解计算、求和计算、径向数组计算和最大值计算

    参数:
    ----------
    file_path : str
        Excel文件路径
    excel_range : Tuple[int, int, int, int]
        Excel数据范围 (start_row, end_row, start_col, end_col)
    angle_data : List[List[float]], optional
        角度数据，如果为None则使用默认值

    返回:
    ----------
    dict
        包含所有结果和信息的字典
    """
    try:
        # 1. 执行集成求和处理流程
        print("=" * 60)
        print("开始集成轴向径向处理流程")
        print("=" * 60)

        # 执行集成求和处理
        sum_result_dict = integrated_sum_process(file_path, excel_range, angle_data)

        # 2. 计算径向数组
        print("\n" + "=" * 60)
        print("执行径向数组计算")
        print("=" * 60)

        radial_array_result = calculate_radial_array(sum_result_dict['sum_result'])

        # 3. 计算轴向和径向最大值
        print("\n" + "=" * 60)
        print("执行轴向径向最大值计算")
        print("=" * 60)

        max_values_result = calculate_axial_radial_max(radial_array_result)

        # 4. 合并结果
        final_result = {**sum_result_dict, **max_values_result}

        # 5. 添加最大值统计信息
        final_result['statistics']['axial_max'] = final_result['axial_max']['value']
        final_result['statistics']['radial_max'] = final_result['radial_max']['value']
        final_result['statistics']['max_values'] = final_result['max_values']

        return final_result

    except Exception as e:
        raise Exception(f"集成轴向径向处理流程出错: {str(e)}")


def display_axial_radial_results(result_dict: dict, show_details: bool = False):
    """
    显示轴向径向计算结果

    参数:
    ----------
    result_dict : dict
        integrated_axial_radial_process函数的返回结果
    show_details : bool
        是否显示详细结果
    """
    if 'axial_max' not in result_dict or 'radial_max' not in result_dict:
        print("错误: 结果字典中不包含轴向径向计算结果")
        return

    axial_max = result_dict['axial_max']
    radial_max = result_dict['radial_max']
    axial_data = result_dict['axial_data']
    radial_data = result_dict['radial_data']
    max_values = result_dict['max_values']

    print("\n" + "=" * 100)
    print("轴向径向计算结果")
    print("=" * 100)

    # 显示轴向最大值
    print(f"\n轴向最大值 ({axial_max['description']}):")
    print(f"  值: {axial_max['value']:.6f}")
    print(f"  位置: {axial_max['position']} (索引: {axial_max['index']})")

    # 显示径向最大值
    print(f"\n径向最大值 ({radial_max['description']}):")
    print(f"  值: {radial_max['value']:.6f}")
    print(f"  位置: {radial_max['position']} (索引: {radial_max['index']})")

    # 显示最大值列表
    print(f"\n最大值列表: {[f'{x:.6f}' for x in max_values]}")

    # 显示轴向数据和径向数据
    print(f"\n轴向数据 (副本1列和): {[f'{x:.6f}' for x in axial_data]}")
    print(f"径向数据 (副本2和副本3的平方和开根号): {[f'{x:.6f}' for x in radial_data]}")

    if show_details:
        # 显示详细的求和结果
        print(f"\n详细的求和结果:")
        sum_result = result_dict['sum_result']
        for copy_idx, copy_sum in enumerate(sum_result):
            print(f"\n副本{copy_idx + 1}的列和:")
            for col_idx, col_sum in enumerate(copy_sum):
                print(f"  第{col_idx + 1}列: {col_sum:.6f}")


def save_axial_radial_results(result_dict: dict, filename: str = "axial_radial_results.txt"):
    """
    保存轴向径向计算结果到文件
    """
    if 'axial_max' not in result_dict or 'radial_max' not in result_dict:
        print("错误: 结果字典中不包含轴向径向计算结果")
        return

    with open(filename, 'w', encoding='utf-8') as f:
        f.write("轴向径向计算结果\n")
        f.write("=" * 50 + "\n\n")

        f.write("最大值统计:\n")
        f.write(f"  轴向最大值: {result_dict['axial_max']['value']:.6f} ({result_dict['axial_max']['position']})\n")
        f.write(f"  径向最大值: {result_dict['radial_max']['value']:.6f} ({result_dict['radial_max']['position']})\n")
        f.write(f"  最大值列表: {[f'{x:.6f}' for x in result_dict['max_values']]}\n\n")

        f.write("轴向数据 (副本1列和):\n")
        for i, value in enumerate(result_dict['axial_data']):
            f.write(f"  第{i + 1}列: {value:.6f}\n")

        f.write("\n径向数据 (副本2和副本3的平方和开根号):\n")
        for i, value in enumerate(result_dict['radial_data']):
            f.write(f"  第{i + 1}列: {value:.6f}\n")

        f.write("\n各副本列和:\n")
        for copy_idx, copy_sum in enumerate(result_dict['sum_result']):
            f.write(f"\n副本{copy_idx + 1}:\n")
            for col_idx, col_sum in enumerate(copy_sum):
                f.write(f"  第{col_idx + 1}列: {col_sum:.6f}\n")

        f.write("\n原始分解结果摘要:\n")
        result_3d = result_dict['result_3d']
        for copy_idx, copy_data in enumerate(result_3d):
            f.write(f"\n副本{copy_idx + 1}原始数据:\n")
            for col_idx, col_data in enumerate(copy_data):
                preview_values = [f'{x:.6f}' if x is not None else 'None' for x in col_data[:3]]
                f.write(f"  第{col_idx + 1}列前3个值: {preview_values}\n")


def input_projection_areas() -> tuple:
    """
    输入三个投影面值：轴拉投影面、轴压投影面、径向投影面

    返回:
    ----------
    tuple
        包含三个投影面值的元组 (a, b, c)
    """
    print("=" * 60)
    print("投影面值输入系统")
    print("=" * 60)
    print("请输入三个投影面值：")
    print("  a: 轴拉投影面")
    print("  b: 轴压投影面")
    print("  c: 径向投影面")

    while True:
        try:
            a = float(input("请输入轴拉投影面 (a): ").strip())
            b = float(input("请输入轴压投影面 (b): ").strip())
            c = float(input("请输入径向投影面 (c): ").strip())

            # 验证输入值是否为正数
            if a <= 0 or b <= 0 or c <= 0:
                print("错误：投影面值必须为正数，请重新输入")
                continue

            print(f"\n输入的投影面值:")
            print(f"  轴拉投影面 (a): {a}")
            print(f"  轴压投影面 (b): {b}")
            print(f"  径向投影面 (c): {c}")

            return a, b, c

        except ValueError:
            print("输入格式错误，请确保输入的是数字")
        except Exception as e:
            print(f"发生错误: {e}")


def calculate_mianya(radial_array_result: List[List[float]],
                     a: float, b: float, c: float) -> dict:
    """
    计算面压值

    参数:
    ----------
    radial_array_result : List[List[float]]
        calculate_radial_array函数的返回结果，格式为 [[轴向数据], [径向数据]]
    a : float
        轴拉投影面
    b : float
        轴压投影面
    c : float
        径向投影面

    返回:
    ----------
    dict
        包含面压计算结果的字典
    """
    try:
        # 验证输入数据
        if not radial_array_result or len(radial_array_result) != 2:
            raise ValueError("径向数组结果必须包含2个数组")

        print("=" * 60)
        print("开始面压计算")
        print("=" * 60)

        print(f"投影面值: a={a}, b={b}, c={c}")
        print(f"输入数据形状: {len(radial_array_result)}数组 × {len(radial_array_result[0])}列")

        # 提取数据
        axial_data = radial_array_result[0]  # 索引0：轴向数据
        radial_data = radial_array_result[1]  # 索引1：径向数据

        print(f"轴向数据: {axial_data}")
        print(f"径向数据: {radial_data}")

        # 1. 计算轴向面压
        axial_mianya = []
        axial_positive_count = 0
        axial_negative_count = 0

        print("\n计算轴向面压:")
        for i, value in enumerate(axial_data):
            if value > 0:
                # 正值：除以轴拉投影面 (a)
                result = value / a
                axial_mianya.append(result)
                axial_positive_count += 1
                print(f"  第{i + 1}列: {value} > 0, 除以a={a}, 结果={result:.6f}")
            elif value < 0:
                # 负值：除以轴压投影面 (b)
                result = value / b
                axial_mianya.append(result)
                axial_negative_count += 1
                print(f"  第{i + 1}列: {value} < 0, 除以b={b}, 结果={result:.6f}")
            else:
                # 零值：保持不变
                axial_mianya.append(0.0)
                print(f"  第{i + 1}列: {value} = 0, 保持不变, 结果=0.000000")

        # 2. 计算径向面压
        radial_mianya = []
        radial_count = 0

        print("\n计算径向面压:")
        for i, value in enumerate(radial_data):
            # 径向数据：不管正负都除以径向投影面 (c)
            result = value / c
            radial_mianya.append(result)
            radial_count += 1
            print(f"  第{i + 1}列: {value} / c={c}, 结果={result:.6f}")

        # 3. 统计信息
        stats = {
            'axial_positive_count': axial_positive_count,
            'axial_negative_count': axial_negative_count,
            'axial_zero_count': len(axial_data) - axial_positive_count - axial_negative_count,
            'radial_count': radial_count,
            'axial_max': max(axial_mianya) if axial_mianya else 0.0,
            'axial_min': min(axial_mianya) if axial_mianya else 0.0,
            'radial_max': max(radial_mianya) if radial_mianya else 0.0,
            'radial_min': min(radial_mianya) if radial_mianya else 0.0
        }

        # 返回结果
        result_dict = {
            'projection_areas': {'a': a, 'b': b, 'c': c},
            'axial_data': axial_data,
            'radial_data': radial_data,
            'axial_mianya': axial_mianya,
            'radial_mianya': radial_mianya,
            'mianya_result': [axial_mianya, radial_mianya],
            'statistics': stats
        }

        print(f"\n面压计算结果:")
        print(f"  轴向面压: {[f'{x:.6f}' for x in axial_mianya]}")
        print(f"  径向面压: {[f'{x:.6f}' for x in radial_mianya]}")
        print(f"  轴向正值数量: {stats['axial_positive_count']}")
        print(f"  轴向负值数量: {stats['axial_negative_count']}")
        print(f"  轴向零值数量: {stats['axial_zero_count']}")
        print(f"  轴向面压最大值: {stats['axial_max']:.6f}")
        print(f"  轴向面压最小值: {stats['axial_min']:.6f}")
        print(f"  径向面压最大值: {stats['radial_max']:.6f}")
        print(f"  径向面压最小值: {stats['radial_min']:.6f}")

        return result_dict

    except Exception as e:
        raise Exception(f"面压计算时出错: {str(e)}")


def integrated_mianya_process(file_path: str,
                              excel_range: Tuple[int, int, int, int],
                              angle_data: List[List[float]] = None,
                              projection_areas: tuple = None) -> dict:
    """
    集成面压处理流程：包含文件读取、角度输入、余弦计算、分解计算、求和计算、径向数组计算和面压计算

    参数:
    ----------
    file_path : str
        Excel文件路径
    excel_range : Tuple[int, int, int, int]
        Excel数据范围 (start_row, end_row, start_col, end_col)
    angle_data : List[List[float]], optional
        角度数据，如果为None则使用默认值
    projection_areas : tuple, optional
        投影面值元组 (a, b, c)，如果为None则通过输入函数获取

    返回:
    ----------
    dict
        包含所有结果和信息的字典
    """
    try:
        # 1. 执行集成轴向径向处理流程
        print("=" * 60)
        print("开始集成面压处理流程")
        print("=" * 60)

        # 执行集成轴向径向处理
        axial_radial_result = integrated_axial_radial_process(file_path, excel_range, angle_data)

        # 2. 获取投影面值
        print("\n" + "=" * 60)
        print("获取投影面值")
        print("=" * 60)

        if projection_areas is None:
            a, b, c = input_projection_areas()
        else:
            a, b, c = projection_areas
            print(f"使用提供的投影面值: a={a}, b={b}, c={c}")

        # 3. 计算面压
        print("\n" + "=" * 60)
        print("执行面压计算")
        print("=" * 60)

        # 从轴向径向结果中提取径向数组结果
        radial_array = [axial_radial_result['axial_data'], axial_radial_result['radial_data']]

        mianya_result = calculate_mianya(radial_array, a, b, c)

        # 4. 合并结果
        final_result = {**axial_radial_result, **mianya_result}

        return final_result

    except Exception as e:
        raise Exception(f"集成面压处理流程出错: {str(e)}")


def display_mianya_results(result_dict: dict, show_details: bool = False):
    """
    显示面压计算结果

    参数:
    ----------
    result_dict : dict
        integrated_mianya_process函数的返回结果
    show_details : bool
        是否显示详细结果
    """
    if 'axial_mianya' not in result_dict or 'radial_mianya' not in result_dict:
        print("错误: 结果字典中不包含面压计算结果")
        return

    a = result_dict['projection_areas']['a']
    b = result_dict['projection_areas']['b']
    c = result_dict['projection_areas']['c']
    axial_mianya = result_dict['axial_mianya']
    radial_mianya = result_dict['radial_mianya']
    stats = result_dict['statistics']

    print("\n" + "=" * 100)
    print("面压计算结果")
    print("=" * 100)

    print(f"投影面值: a={a}, b={b}, c={c}")

    # 显示轴向面压结果
    print(f"\n轴向面压结果 (索引0数组):")
    print("-" * 60)
    for i, value in enumerate(axial_mianya):
        original_value = result_dict['axial_data'][i]
        if original_value > 0:
            operation = f"{original_value} / {a}"
        elif original_value < 0:
            operation = f"{original_value} / {b}"
        else:
            operation = "0 (保持不变)"

        print(f"  第{i + 1}列: {operation} = {value:.6f}")

    # 显示径向面压结果
    print(f"\n径向面压结果 (索引1数组):")
    print("-" * 60)
    for i, value in enumerate(radial_mianya):
        original_value = result_dict['radial_data'][i]
        print(f"  第{i + 1}列: {original_value} / {c} = {value:.6f}")

    # 显示统计信息
    print(f"\n统计信息:")
    print(f"  轴向面压最大值: {stats['axial_max']:.6f}")
    print(f"  轴向面压最小值: {stats['axial_min']:.6f}")
    print(f"  径向面压最大值: {stats['radial_max']:.6f}")
    print(f"  径向面压最小值: {stats['radial_min']:.6f}")
    print(f"  轴向正值数量: {stats['axial_positive_count']}")
    print(f"  轴向负值数量: {stats['axial_negative_count']}")
    print(f"  轴向零值数量: {stats['axial_zero_count']}")

    if show_details:
        # 显示详细的面压计算结果
        print(f"\n详细面压计算结果:")
        print(f"  轴向面压数组: {[f'{x:.6f}' for x in axial_mianya]}")
        print(f"  径向面压数组: {[f'{x:.6f}' for x in radial_mianya]}")


def save_mianya_results(result_dict: dict, filename: str = "mianya_results.txt"):
    """
    保存面压计算结果到文件
    """
    if 'axial_mianya' not in result_dict or 'radial_mianya' not in result_dict:
        print("错误: 结果字典中不包含面压计算结果")
        return

    with open(filename, 'w', encoding='utf-8') as f:
        f.write("面压计算结果\n")
        f.write("=" * 50 + "\n\n")

        f.write("投影面值:\n")
        f.write(f"  轴拉投影面 (a): {result_dict['projection_areas']['a']}\n")
        f.write(f"  轴压投影面 (b): {result_dict['projection_areas']['b']}\n")
        f.write(f"  径向投影面 (c): {result_dict['projection_areas']['c']}\n\n")

        f.write("轴向面压结果:\n")
        axial_data = result_dict['axial_data']
        axial_mianya = result_dict['axial_mianya']
        for i, (orig, mianya) in enumerate(zip(axial_data, axial_mianya)):
            if orig > 0:
                operation = f"{orig} / {result_dict['projection_areas']['a']}"
            elif orig < 0:
                operation = f"{orig} / {result_dict['projection_areas']['b']}"
            else:
                operation = "0 (保持不变)"
            f.write(f"  第{i + 1}列: {operation} = {mianya:.6f}\n")

        f.write("\n径向面压结果:\n")
        radial_data = result_dict['radial_data']
        radial_mianya = result_dict['radial_mianya']
        for i, (orig, mianya) in enumerate(zip(radial_data, radial_mianya)):
            f.write(f"  第{i + 1}列: {orig} / {result_dict['projection_areas']['c']} = {mianya:.6f}\n")

        f.write("\n统计信息:\n")
        stats = result_dict['statistics']
        f.write(f"  轴向面压最大值: {stats['axial_max']:.6f}\n")
        f.write(f"  轴向面压最小值: {stats['axial_min']:.6f}\n")
        f.write(f"  径向面压最大值: {stats['radial_max']:.6f}\n")
        f.write(f"  径向面压最小值: {stats['radial_min']:.6f}\n")
        f.write(f"  轴向正值数量: {stats['axial_positive_count']}\n")
        f.write(f"  轴向负值数量: {stats['axial_negative_count']}\n")
        f.write(f"  轴向零值数量: {stats['axial_zero_count']}\n")



def read_time(
        file_path: str,
        time_col: int,
        start_row: int,
        end_row: int,
        sheet_name: Union[str, int] = 0,
        header: Optional[int] = None
) -> List[Union[float, int, str]]:
    """
    读取文件中的时间列数据，返回一维数组

    参数:
    ----------
    file_path : str
        数据文件路径（支持CSV和XLSX）
    time_col : int
        时间列编号（从1开始）
    start_row : int
        起始行编号（从1开始）
    end_row : int
        结束行编号（包含该行，从1开始）
    sheet_name : Union[str, int], default=0
        工作表名称或索引
    header : Optional[int], default=None
        表头行，None表示无表头

    返回:
    ----------
    List[Union[float, int, str]]
        时间列的数据列表（一维数组）
    """
    file_extension = os.path.splitext(file_path)[1].lower()

    # 根据文件扩展名选择处理方式
    if file_extension in ['.xlsx', '.xls']:
        # 直接读取Excel文件的时间列
        return read_time_from_excel(file_path, time_col, start_row, end_row, sheet_name, header)
    elif file_extension == '.csv':
        # 读取CSV文件的时间列
        return read_time_from_csv(file_path, time_col, start_row, end_row, header)
    else:
        raise ValueError(f"不支持的文件格式: {file_extension}，仅支持.xlsx, .xls和.csv文件")


def read_time_from_excel(
        file_path: str,
        time_col: int,
        start_row: int,
        end_row: int,
        sheet_name: Union[str, int] = 0,
        header: Optional[int] = None
) -> List[Union[float, int, str]]:
    """
    从Excel文件中读取时间列数据

    参数:
    ----------
    file_path : str
        Excel文件路径
    time_col : int
        时间列编号（从1开始）
    start_row : int
        起始行编号（从1开始）
    end_row : int
        结束行编号（包含该行，从1开始）
    sheet_name : Union[str, int], default=0
        工作表名称或索引
    header : Optional[int], default=None
        表头行，None表示无表头

    返回:
    ----------
    List[Union[float, int, str]]
        时间列的数据列表
    """
    try:
        # 读取整个工作表
        df = pd.read_excel(file_path, sheet_name=sheet_name, header=header)

        # 将Excel行列编号(1-based)转换为Python索引(0-based)
        start_row_idx = start_row - 1
        end_row_idx = end_row - 1
        time_col_idx = time_col - 1

        # 验证行列范围是否有效
        if start_row_idx < 0 or end_row_idx >= len(df) or start_row_idx > end_row_idx:
            raise ValueError(f"行范围无效: start_row={start_row}, end_row={end_row}, 数据行数={len(df)}")

        if time_col_idx < 0 or time_col_idx >= len(df.columns):
            raise ValueError(f"时间列无效: time_col={time_col}, 数据列数={len(df.columns)}")

        # 计算需要读取的数据行
        data_rows = []
        current_row = start_row_idx

        while current_row <= end_row_idx:
            # 计算当前行相对于起始行的偏移量
            row_offset = current_row - start_row_idx + 1
            data_rows.append(current_row)
            current_row += 1

        print(f"检测到 {len(data_rows)} 个数据行: {[r + 1 for r in data_rows]}")

        # 创建空列表来存储时间数据
        time_data = []

        # 读取时间列数据
        for row_idx in data_rows:
            value = df.iloc[row_idx, time_col_idx]

            # 处理NaN值（空单元格）
            if pd.isna(value):
                time_data.append(None)
            else:
                time_data.append(value)

        print(f"读取的时间列数据: {time_data}")
        return time_data

    except FileNotFoundError:
        raise FileNotFoundError(f"文件未找到: {file_path}")
    except Exception as e:
        raise Exception(f"读取Excel文件时间列时出错: {str(e)}")


def read_time_from_csv(
        file_path: str,
        time_col: int,
        start_row: int,
        end_row: int,
        header: Optional[int] = None
) -> List[Union[float, int, str]]:
    """
    从CSV文件中读取时间列数据

    参数:
    ----------
    file_path : str
        CSV文件路径
    time_col : int
        时间列编号（从1开始）
    start_row : int
        起始行编号（从1开始）
    end_row : int
        结束行编号（包含该行，从1开始）
    header : Optional[int], default=None
        表头行，None表示无表头

    返回:
    ----------
    List[Union[float, int, str]]
        时间列的数据列表
    """
    # 创建临时XLSX文件
    with tempfile.NamedTemporaryFile(suffix='.xlsx', delete=False) as temp_file:
        temp_xlsx_path = temp_file.name

    try:
        # 读取CSV文件并转换为XLSX
        print("检测到CSV文件，正在转换为XLSX格式...")

        # 读取CSV文件（跳过注释行）
        df = pd.read_csv(file_path, comment='#')

        # 保存为临时XLSX文件
        df.to_excel(temp_xlsx_path, index=False, header=True)
        print(f"已创建临时XLSX文件: {temp_xlsx_path}")

        # 计算原始CSV文件中的有效数据行
        with open(file_path, 'r', encoding='utf-8') as f:
            lines = f.readlines()

        # 统计注释行数
        comment_lines = sum(1 for line in lines if line.strip().startswith('#'))
        print(f"检测到 {comment_lines} 行注释")

        # 调整行号：跳过注释行
        adjusted_start_row = max(1, start_row - comment_lines)
        adjusted_end_row = end_row - comment_lines

        print(f"调整行号: {start_row}-{end_row} -> {adjusted_start_row}-{adjusted_end_row}")

        # 使用Excel读取函数读取时间列
        result = read_time_from_excel(temp_xlsx_path, time_col, adjusted_start_row, adjusted_end_row, header=header)

        return result

    finally:
        # 清理临时文件
        if os.path.exists(temp_xlsx_path):
            os.unlink(temp_xlsx_path)
            print("临时文件已清理")


def integrated_full_process(file_path: str,
                            excel_range: Tuple[int, int, int, int],  # 这个参数已经存在
                            angle_data: List[List[float]] = None,
                            projection_areas: tuple = None,
                            output_file: str = None,
                            condition_col: int = None) -> dict:
    """
    完整处理流程：包含所有计算步骤并将结果保存到Excel，最大值标黄
    """
    try:
        # 执行集成面压处理
        result = integrated_mianya_process(
            file_path=file_path,
            excel_range=excel_range,  # 传递excel_range
            angle_data=angle_data,
            projection_areas=projection_areas
        )

        # 将结果保存到Excel（现在传递excel_range参数）
        saved_file = save_results_to_excel(
            result,
            file_path,
            output_file,
            condition_col,
            excel_range  # 新增：传递excel_range参数
        )

        # 在结果字典中添加保存的文件路径和工况名称列
        result['saved_file'] = saved_file
        result['condition_col'] = condition_col
        result['excel_range'] = excel_range  # 也保存excel_range到结果中

        return result

    except Exception as e:
        raise Exception(f"完整处理流程出错: {str(e)}")


def save_results_to_excel(result_dict: dict,
                          file_path: str,
                          output_file: str = None,
                          condition_col: int = None,
                          excel_range: Tuple[int, int, int, int] = None) -> str:
    """
    将结果保存到Excel文件，将统计结果放在右侧与数据并排排列
    修正：为除了时间列之外的每一列数据分别找到最大值并标黄
    """
    try:
        # 导入openpyxl的样式模块
        from openpyxl.styles import PatternFill, Font
        from openpyxl import Workbook

        # 确定输出文件路径
        if output_file is None:
            import os
            base_name = os.path.splitext(file_path)[0]
            output_file = f"{base_name}_结果.xlsx"

        print(f"开始将结果保存到Excel文件: {output_file}")

        # 读取时间数据作为第一列 - 使用与数据读取相同的行范围
        time_data = []
        try:
            # 从result_dict中获取excel_range，如果没有则使用默认值
            if excel_range is None:
                # 尝试从结果字典中获取范围信息
                if 'excel_range' in result_dict:
                    excel_range = result_dict['excel_range']
                else:
                    # 使用默认范围
                    excel_range = (2, 20, 3, 5)
                    print(f"警告: 未提供excel_range，使用默认范围: {excel_range}")

            # 使用与数据读取相同的行范围
            start_row, end_row, start_col, end_col = excel_range
            print(f"使用与数据读取相同的行范围: 行{start_row}-{end_row}")

            time_data = read_time(
                file_path=file_path,
                time_col=condition_col if condition_col else 1,  # 默认为第1列
                start_row=start_row,  # 使用数据读取的起始行
                end_row=end_row  # 使用数据读取的结束行
            )
            print(f"成功读取时间数据: 共{len(time_data)}个时间点 (行{start_row}-{end_row})")
        except Exception as e:
            print(f"读取时间数据时出错: {e}")
            # 如果读取失败，使用空列表
            time_data = []

        # 获取所需数据
        sum_result = result_dict.get('sum_result', [])
        radial_data = result_dict.get('radial_data', [])
        axial_mianya = result_dict.get('axial_mianya', [])
        radial_mianya = result_dict.get('radial_mianya', [])

        # 获取径向1合力和径向2合力（sum_result索引1和2的部分）
        radial1_sum = []
        radial2_sum = []

        if sum_result and len(sum_result) >= 3:
            # 径向1合力：sum_result索引1的部分
            radial1_sum = sum_result[1] if len(sum_result) > 1 else []
            # 径向2合力：sum_result索引2的部分
            radial2_sum = sum_result[2] if len(sum_result) > 2 else []

            print(f"径向1合力数据: {radial1_sum}")
            print(f"径向2合力数据: {radial2_sum}")

        # 获取轴向合力（sum_result索引0的部分）
        axial_sum = []
        if sum_result and len(sum_result) > 0:
            axial_sum = sum_result[0]
            print(f"轴向合力数据: {axial_sum}")

        # 确定行数 - 使用所有数组的最大长度
        max_length = max(
            len(radial1_sum) if radial1_sum else 0,
            len(radial2_sum) if radial2_sum else 0,
            len(axial_sum) if axial_sum else 0,
            len(radial_data) if radial_data else 0,
            len(axial_mianya) if axial_mianya else 0,
            len(radial_mianya) if radial_mianya else 0,
            len(time_data) if time_data else 0
        )

        # 如果时间数据长度不够，用None填充
        if time_data and len(time_data) < max_length:
            time_data.extend([None] * (max_length - len(time_data)))
        elif not time_data:
            time_data = [None] * max_length

        print(f"最终确定的数据行数: {max_length}")

        # 创建新的工作簿
        wb = Workbook()
        # 使用默认工作表
        ws = wb.active
        ws.title = "结果汇总"
        print("创建工作表: 结果汇总")

        # 设置标题行 - 修改后的列
        headers = ['时间', '径向1合力', '径向2合力', '轴向合力', '径向合力', '轴向面压计算结果',
                   '径向面压计算结果']
        for col_idx, header in enumerate(headers, 1):
            ws.cell(row=1, column=col_idx, value=header)
            ws.cell(row=1, column=col_idx).font = Font(bold=True)

        # 填充数据
        for row_idx in range(max_length):
            # 第一列：时间数据
            if row_idx < len(time_data):
                ws.cell(row=row_idx + 2, column=1, value=time_data[row_idx])
            else:
                ws.cell(row=row_idx + 2, column=1, value=None)

            # 第二列：径向1合力
            if row_idx < len(radial1_sum):
                ws.cell(row=row_idx + 2, column=2, value=radial1_sum[row_idx])
            else:
                ws.cell(row=row_idx + 2, column=2, value=None)

            # 第三列：径向2合力
            if row_idx < len(radial2_sum):
                ws.cell(row=row_idx + 2, column=3, value=radial2_sum[row_idx])
            else:
                ws.cell(row=row_idx + 2, column=3, value=None)

            # 第四列：轴向合力
            if row_idx < len(axial_sum):
                ws.cell(row=row_idx + 2, column=4, value=axial_sum[row_idx])
            else:
                ws.cell(row=row_idx + 2, column=4, value=None)

            # 第五列：径向合力
            if radial_data and row_idx < len(radial_data):
                ws.cell(row=row_idx + 2, column=5, value=radial_data[row_idx])
            else:
                ws.cell(row=row_idx + 2, column=5, value=None)

            # 第六列：轴向面压计算结果
            if axial_mianya and row_idx < len(axial_mianya):
                ws.cell(row=row_idx + 2, column=6, value=axial_mianya[row_idx])
            else:
                ws.cell(row=row_idx + 2, column=6, value=None)

            # 第七列：径向面压计算结果
            if radial_mianya and row_idx < len(radial_mianya):
                ws.cell(row=row_idx + 2, column=7, value=radial_mianya[row_idx])
            else:
                ws.cell(row=row_idx + 2, column=7, value=None)

        # 设置列宽
        column_widths = [20, 15, 15, 15, 15, 18, 18]
        for i, width in enumerate(column_widths, 1):
            col_letter = chr(64 + i)
            ws.column_dimensions[col_letter].width = width

        # 为最大值添加黄色背景
        yellow_fill = PatternFill(start_color='FFFF00', end_color='FFFF00', fill_type='solid')

        # 修正：为除了时间列之外的每一列数据分别找到最大值并标黄
        print("\n开始标黄最大值...")

        # 遍历B到G列（索引2到7） - 除了时间列之外的所有列
        for col_idx in range(2, 8):  # B到G列
            max_value = None
            max_rows = []

            # 找到当前列的最大值
            for row_idx in range(2, max_length + 2):  # 从第2行开始（跳过标题行）
                cell_value = ws.cell(row=row_idx, column=col_idx).value
                if cell_value is not None:
                    try:
                        num_value = float(cell_value)
                        if max_value is None or num_value > max_value:
                            max_value = num_value
                            max_rows = [row_idx]
                        elif num_value == max_value:
                            max_rows.append(row_idx)
                    except (ValueError, TypeError):
                        continue

            # 标记所有等于当前列最大值的单元格
            if max_value is not None:
                for row_idx in max_rows:
                    ws.cell(row=row_idx, column=col_idx).fill = yellow_fill
                print(f"  第{col_idx}列({headers[col_idx - 1]})最大值: {max_value:.6f} (位置: 行{max_rows})")
            else:
                print(f"  第{col_idx}列({headers[col_idx - 1]})无有效数据")

        # 在右侧添加统计结果（与数据并排）
        stats_start_col = 9  # 从第9列开始（数据列到第7列，中间空一列）

        # 统计结果标题
        ws.cell(row=1, column=stats_start_col, value="统计结果")
        ws.cell(row=1, column=stats_start_col).font = Font(bold=True, size=14)

        # 统计结果表头
        stats_headers = ['统计项', '数值', '说明']
        for col_idx, header in enumerate(stats_headers, stats_start_col):
            ws.cell(row=2, column=col_idx, value=header)
            ws.cell(row=2, column=col_idx).font = Font(bold=True)

        # 添加统计信息
        row_idx = 3  # 从第3行开始

        # 收集所有数值用于找到最大值
        all_values = []

        # 添加轴向合力的统计（新增）
        if axial_sum:
            # 过滤掉None值
            axial_filtered = [x for x in axial_sum if x is not None]
            if axial_filtered:
                axial_max = max(axial_filtered)
                axial_min = min(axial_filtered)
                axial_avg = sum(axial_filtered) / len(axial_filtered)

                ws.cell(row=row_idx, column=stats_start_col, value='轴向合力最大值')
                ws.cell(row=row_idx, column=stats_start_col + 1, value=axial_max)
                ws.cell(row=row_idx, column=stats_start_col + 2, value='轴向合力结果中的最大值')
                all_values.append(axial_max)
                row_idx += 1

                ws.cell(row=row_idx, column=stats_start_col, value='轴向合力最小值')
                ws.cell(row=row_idx, column=stats_start_col + 1, value=axial_min)
                ws.cell(row=row_idx, column=stats_start_col + 2, value='轴向合力结果中的最小值')
                all_values.append(axial_min)
                row_idx += 1

                ws.cell(row=row_idx, column=stats_start_col, value='轴向合力平均值')
                ws.cell(row=row_idx, column=stats_start_col + 1, value=axial_avg)
                ws.cell(row=row_idx, column=stats_start_col + 2, value='轴向合力结果的平均值')
                row_idx += 1

                ws.cell(row=row_idx, column=stats_start_col, value='轴向合力数据量')
                ws.cell(row=row_idx, column=stats_start_col + 1, value=len(axial_filtered))
                ws.cell(row=row_idx, column=stats_start_col + 2, value='有效的轴向合力数据点数')
                row_idx += 1

        # 添加径向合力的统计（新增）
        if radial_data:
            radial_filtered = [x for x in radial_data if x is not None]
            if radial_filtered:
                radial_max = max(radial_filtered)
                radial_min = min(radial_filtered)
                radial_avg = sum(radial_filtered) / len(radial_filtered)

                ws.cell(row=row_idx, column=stats_start_col, value='径向合力最大值')
                ws.cell(row=row_idx, column=stats_start_col + 1, value=radial_max)
                ws.cell(row=row_idx, column=stats_start_col + 2, value='径向合力结果中的最大值')
                all_values.append(radial_max)
                row_idx += 1

                ws.cell(row=row_idx, column=stats_start_col, value='径向合力最小值')
                ws.cell(row=row_idx, column=stats_start_col + 1, value=radial_min)
                ws.cell(row=row_idx, column=stats_start_col + 2, value='径向合力结果中的最小值')
                all_values.append(radial_min)
                row_idx += 1

                ws.cell(row=row_idx, column=stats_start_col, value='径向合力平均值')
                ws.cell(row=row_idx, column=stats_start_col + 1, value=radial_avg)
                ws.cell(row=row_idx, column=stats_start_col + 2, value='径向合力结果的平均值')
                row_idx += 1

                ws.cell(row=row_idx, column=stats_start_col, value='径向合力数据量')
                ws.cell(row=row_idx, column=stats_start_col + 1, value=len(radial_filtered))
                ws.cell(row=row_idx, column=stats_start_col + 2, value='有效的径向合力数据点数')
                row_idx += 1

        # 添加径向1合力的统计
        if radial1_sum:
            # 过滤掉None值
            radial1_filtered = [x for x in radial1_sum if x is not None]
            if radial1_filtered:
                radial1_max = max(radial1_filtered)
                radial1_min = min(radial1_filtered)
                radial1_avg = sum(radial1_filtered) / len(radial1_filtered)

                ws.cell(row=row_idx, column=stats_start_col, value='径向1合力最大值')
                ws.cell(row=row_idx, column=stats_start_col + 1, value=radial1_max)
                ws.cell(row=row_idx, column=stats_start_col + 2, value='径向1合力结果中的最大值')
                all_values.append(radial1_max)
                row_idx += 1

                ws.cell(row=row_idx, column=stats_start_col, value='径向1合力最小值')
                ws.cell(row=row_idx, column=stats_start_col + 1, value=radial1_min)
                ws.cell(row=row_idx, column=stats_start_col + 2, value='径向1合力结果中的最小值')
                all_values.append(radial1_min)
                row_idx += 1

                ws.cell(row=row_idx, column=stats_start_col, value='径向1合力平均值')
                ws.cell(row=row_idx, column=stats_start_col + 1, value=radial1_avg)
                ws.cell(row=row_idx, column=stats_start_col + 2, value='径向1合力结果的平均值')
                row_idx += 1

                ws.cell(row=row_idx, column=stats_start_col, value='径向1合力数据量')
                ws.cell(row=row_idx, column=stats_start_col + 1, value=len(radial1_filtered))
                ws.cell(row=row_idx, column=stats_start_col + 2, value='有效的径向1合力数据点数')
                row_idx += 1

        # 添加径向2合力的统计
        if radial2_sum:
            radial2_filtered = [x for x in radial2_sum if x is not None]
            if radial2_filtered:
                radial2_max = max(radial2_filtered)
                radial2_min = min(radial2_filtered)
                radial2_avg = sum(radial2_filtered) / len(radial2_filtered)

                ws.cell(row=row_idx, column=stats_start_col, value='径向2合力最大值')
                ws.cell(row=row_idx, column=stats_start_col + 1, value=radial2_max)
                ws.cell(row=row_idx, column=stats_start_col + 2, value='径向2合力结果中的最大值')
                all_values.append(radial2_max)
                row_idx += 1

                ws.cell(row=row_idx, column=stats_start_col, value='径向2合力最小值')
                ws.cell(row=row_idx, column=stats_start_col + 1, value=radial2_min)
                ws.cell(row=row_idx, column=stats_start_col + 2, value='径向2合力结果中的最小值')
                all_values.append(radial2_min)
                row_idx += 1

                ws.cell(row=row_idx, column=stats_start_col, value='径向2合力平均值')
                ws.cell(row=row_idx, column=stats_start_col + 1, value=radial2_avg)
                ws.cell(row=row_idx, column=stats_start_col + 2, value='径向2合力结果的平均值')
                row_idx += 1

                ws.cell(row=row_idx, column=stats_start_col, value='径向2合力数据量')
                ws.cell(row=row_idx, column=stats_start_col + 1, value=len(radial2_filtered))
                ws.cell(row=row_idx, column=stats_start_col + 2, value='有效的径向2合力数据点数')
                row_idx += 1

        # 添加面压结果的统计
        if axial_mianya:
            axial_mianya_filtered = [x for x in axial_mianya if x is not None]
            if axial_mianya_filtered:
                axial_mianya_max = max(axial_mianya_filtered)
                axial_mianya_min = min(axial_mianya_filtered)
                axial_mianya_avg = sum(axial_mianya_filtered) / len(axial_mianya_filtered)

                ws.cell(row=row_idx, column=stats_start_col, value='轴向面压最大值')
                ws.cell(row=row_idx, column=stats_start_col + 1, value=axial_mianya_max)
                ws.cell(row=row_idx, column=stats_start_col + 2, value='轴向面压计算结果中的最大值')
                all_values.append(axial_mianya_max)
                row_idx += 1

                ws.cell(row=row_idx, column=stats_start_col, value='轴向面压最小值')
                ws.cell(row=row_idx, column=stats_start_col + 1, value=axial_mianya_min)
                ws.cell(row=row_idx, column=stats_start_col + 2, value='轴向面压计算结果中的最小值')
                all_values.append(axial_mianya_min)
                row_idx += 1

                ws.cell(row=row_idx, column=stats_start_col, value='轴向面压平均值')
                ws.cell(row=row_idx, column=stats_start_col + 1, value=axial_mianya_avg)
                ws.cell(row=row_idx, column=stats_start_col + 2, value='轴向面压结果的平均值')
                row_idx += 1

        if radial_mianya:
            radial_mianya_filtered = [x for x in radial_mianya if x is not None]
            if radial_mianya_filtered:
                radial_mianya_max = max(radial_mianya_filtered)
                radial_mianya_min = min(radial_mianya_filtered)
                radial_mianya_avg = sum(radial_mianya_filtered) / len(radial_mianya_filtered)

                ws.cell(row=row_idx, column=stats_start_col, value='径向面压最大值')
                ws.cell(row=row_idx, column=stats_start_col + 1, value=radial_mianya_max)
                ws.cell(row=row_idx, column=stats_start_col + 2, value='径向面压计算结果中的最大值')
                all_values.append(radial_mianya_max)
                row_idx += 1

                ws.cell(row=row_idx, column=stats_start_col, value='径向面压最小值')
                ws.cell(row=row_idx, column=stats_start_col + 1, value=radial_mianya_min)
                ws.cell(row=row_idx, column=stats_start_col + 2, value='径向面压计算结果中的最小值')
                all_values.append(radial_mianya_min)
                row_idx += 1

                ws.cell(row=row_idx, column=stats_start_col, value='径向面压平均值')
                ws.cell(row=row_idx, column=stats_start_col + 1, value=radial_mianya_avg)
                ws.cell(row=row_idx, column=stats_start_col + 2, value='径向面压结果的平均值')
                row_idx += 1

        # 为统计结果中的每个列的最大值统计项标黄
        print("\n开始标黄统计结果中的最大值...")

        # 创建一个字典来存储每个数据列的最大值统计项
        max_stat_rows = {}

        # 遍历统计结果行，找到每个列的最大值统计项
        for row in range(3, row_idx):
            stat_name = ws.cell(row=row, column=stats_start_col).value
            if stat_name and '最大值' in stat_name:
                # 提取列名，现在包括轴向合力和径向合力
                for col_name in ['轴向合力', '径向合力', '径向1合力', '径向2合力', '轴向面压', '径向面压']:
                    if col_name in stat_name:
                        if col_name not in max_stat_rows:
                            max_stat_rows[col_name] = []
                        max_stat_rows[col_name].append(row)
                        break

        # 为每个列的最大值统计项标黄
        for col_name, rows in max_stat_rows.items():
            for row in rows:
                ws.cell(row=row, column=stats_start_col + 1).fill = yellow_fill
            print(f"  {col_name}最大值统计项已标黄: 行{rows}")

        # 设置统计结果列的列宽
        stats_widths = [20, 15, 25]
        for i, width in enumerate(stats_widths, stats_start_col):
            col_letter = chr(64 + i)
            ws.column_dimensions[col_letter].width = width

        # 保存工作簿
        wb.save(output_file)

        print(f"结果已成功保存到: {output_file}")
        print(f"注意: 时间数据已使用与数据读取相同的行范围: 行{start_row}-{end_row}")
        print("注意: 时间数据已作为第一列")
        print("注意: 保留了修改后的列：时间、径向1合力、径向2合力、轴向合力、径向合力、轴向面压计算结果、径向面压计算结果")
        print("注意: 统计结果已放在右侧与数据并排排列")
        print("注意: 每一列的最大值已用黄色背景标记")
        print("注意: 已添加轴向合力和径向合力的最大值统计")
        return output_file

    except Exception as e:
        raise Exception(f"保存结果到Excel时出错: {str(e)}")


def save_single_file_to_workbook(result_dict: dict, worksheet, file_path: str,
                                 excel_range: Tuple[int, int, int, int]):
    """
    将单个文件的结果保存到工作簿的指定工作表中
    """
    try:
        # 导入必要的模块
        from openpyxl.styles import Font, PatternFill

        # 设置工作表标题
        worksheet.cell(row=1, column=1, value=f"文件: {file_path}")
        worksheet.cell(row=2, column=1, value=f"数据范围: {excel_range}")

        # 获取数据
        sum_result = result_dict.get('sum_result', [])
        radial_data = result_dict.get('radial_data', [])
        axial_mianya = result_dict.get('axial_mianya', [])
        radial_mianya = result_dict.get('radial_mianya', [])

        # 读取时间数据
        time_data = []
        try:
            start_row, end_row, start_col, end_col = excel_range
            time_data = read_time(
                file_path=file_path,
                time_col=result_dict.get('condition_col', 1),
                start_row=start_row,
                end_row=end_row
            )
        except Exception as e:
            print(f"读取时间数据失败: {e}")

        # 确定最大行数
        max_length = max(
            len(sum_result[0]) if sum_result and len(sum_result) > 0 and sum_result[0] else 0,
            len(radial_data) if radial_data else 0,
            len(axial_mianya) if axial_mianya else 0,
            len(radial_mianya) if radial_mianya else 0,
            len(time_data) if time_data else 0
        )

        # 设置标题行
        headers = ['时间', '径向1合力', '径向2合力', '轴向合力', '径向合力',
                   '轴向面压计算结果', '径向面压计算结果']

        for col_idx, header in enumerate(headers, 1):
            cell = worksheet.cell(row=4, column=col_idx, value=header)
            cell.font = Font(bold=True)

        # 填充数据
        for row_idx in range(max_length):
            # 时间数据
            if row_idx < len(time_data):
                worksheet.cell(row=row_idx + 5, column=1, value=time_data[row_idx])

            # 径向1合力 (sum_result索引1)
            if sum_result and len(sum_result) > 1 and row_idx < len(sum_result[1]):
                worksheet.cell(row=row_idx + 5, column=2, value=sum_result[1][row_idx])

            # 径向2合力 (sum_result索引2)
            if sum_result and len(sum_result) > 2 and row_idx < len(sum_result[2]):
                worksheet.cell(row=row_idx + 5, column=3, value=sum_result[2][row_idx])

            # 轴向合力 (sum_result索引0)
            if sum_result and len(sum_result) > 0 and row_idx < len(sum_result[0]):
                worksheet.cell(row=row_idx + 5, column=4, value=sum_result[0][row_idx])

            # 径向合力
            if radial_data and row_idx < len(radial_data):
                worksheet.cell(row=row_idx + 5, column=5, value=radial_data[row_idx])

            # 轴向面压
            if axial_mianya and row_idx < len(axial_mianya):
                worksheet.cell(row=row_idx + 5, column=6, value=axial_mianya[row_idx])

            # 径向面压
            if radial_mianya and row_idx < len(radial_mianya):
                worksheet.cell(row=row_idx + 5, column=7, value=radial_mianya[row_idx])

        # 设置列宽
        column_widths = [20, 15, 15, 15, 15, 18, 18]
        for i, width in enumerate(column_widths, 1):
            col_letter = worksheet.cell(row=1, column=i).column_letter
            worksheet.column_dimensions[col_letter].width = width

        # 标记最大值（黄色背景）
        yellow_fill = PatternFill(start_color='FFFF00', end_color='FFFF00', fill_type='solid')

        # 为每列（除时间列外）标记最大值
        for col_idx in range(2, 8):  # B到G列
            max_value = None
            max_rows = []

            for row_idx in range(5, max_length + 5):
                cell_value = worksheet.cell(row=row_idx, column=col_idx).value
                if cell_value is not None:
                    try:
                        num_value = float(cell_value)
                        if max_value is None or num_value > max_value:
                            max_value = num_value
                            max_rows = [row_idx]
                        elif num_value == max_value:
                            max_rows.append(row_idx)
                    except (ValueError, TypeError):
                        continue

            if max_value is not None:
                for row_idx in max_rows:
                    worksheet.cell(row=row_idx, column=col_idx).fill = yellow_fill

        # 添加统计信息到右侧
        stats_col = 9  # 从第9列开始

        # 统计标题
        worksheet.cell(row=4, column=stats_col, value="统计结果").font = Font(bold=True)

        # 添加关键统计信息
        stats_data = [
            ("轴向最大值", result_dict.get('axial_max', {}).get('value')),
            ("径向最大值", result_dict.get('radial_max', {}).get('value')),
            ("轴向面压最大值", result_dict.get('statistics', {}).get('axial_max')),
            ("径向面压最大值", result_dict.get('statistics', {}).get('radial_max'))
        ]

        for i, (label, value) in enumerate(stats_data, 1):
            worksheet.cell(row=4 + i, column=stats_col, value=label)
            if value is not None:
                worksheet.cell(row=4 + i, column=stats_col + 1, value=value)

        print(f"✓ 工作表创建完成")

    except Exception as e:
        raise Exception(f"保存工作表失败: {str(e)}")


def create_summary_sheet(workbook, all_results: dict, file_configs: List[dict]):
    """
    创建汇总表，显示所有文件的处理结果摘要
    """
    try:
        # 导入必要的模块
        from openpyxl.styles import Font

        ws = workbook.create_sheet(title="汇总表")

        # 汇总表标题
        headers = [
            "文件名", "状态", "数据范围", "轴向最大值", "径向最大值",
            "轴向面压最大值", "径向面压最大值", "处理时间"
        ]

        for col_idx, header in enumerate(headers, 1):
            ws.cell(row=1, column=col_idx, value=header).font = Font(bold=True)

        # 填充汇总数据
        for row_idx, (file_path, result_info) in enumerate(all_results.items(), 2):
            config = next((cfg for cfg in file_configs if cfg['file_path'] == file_path), {})

            # 文件名
            import os
            file_name = os.path.basename(file_path)
            ws.cell(row=row_idx, column=1, value=file_name)

            # 状态
            status = result_info['status']
            ws.cell(row=row_idx, column=2, value=status)

            # 数据范围
            excel_range = config.get('excel_range', ())
            ws.cell(row=row_idx, column=3, value=str(excel_range))

            if result_info['result']:
                result = result_info['result']
                # 轴向最大值
                axial_max = result.get('axial_max', {}).get('value')
                ws.cell(row=row_idx, column=4, value=axial_max)

                # 径向最大值
                radial_max = result.get('radial_max', {}).get('value')
                ws.cell(row=row_idx, column=5, value=radial_max)

                # 轴向面压最大值
                axial_mianya_max = result.get('statistics', {}).get('axial_max')
                ws.cell(row=row_idx, column=6, value=axial_mianya_max)

                # 径向面压最大值
                radial_mianya_max = result.get('statistics', {}).get('radial_max')
                ws.cell(row=row_idx, column=7, value=radial_mianya_max)

            # 处理时间
            import datetime
            ws.cell(row=row_idx, column=8, value=datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"))

        # 设置列宽
        column_widths = [30, 15, 20, 15, 15, 15, 15, 20]
        for i, width in enumerate(column_widths, 1):
            col_letter = ws.cell(row=1, column=i).column_letter
            ws.column_dimensions[col_letter].width = width

        print("✓ 汇总表创建完成")

    except Exception as e:
        raise Exception(f"创建汇总表失败: {str(e)}")


def save_results_to_excel(result_dict: dict,
                          file_path: str,
                          output_file: str = None,
                          condition_col: int = None,
                          excel_range: Tuple[int, int, int, int] = None) -> str:
    """
    将结果保存到Excel文件，将统计结果放在右侧与数据并排排列
    修正：为除了时间列之外的每一列数据分别找到最大值并标黄
    """
    try:
        # 导入openpyxl的样式模块
        from openpyxl.styles import PatternFill, Font
        from openpyxl import Workbook

        # 确定输出文件路径
        if output_file is None:
            import os
            base_name = os.path.splitext(file_path)[0]
            output_file = f"{base_name}_结果.xlsx"

        print(f"开始将结果保存到Excel文件: {output_file}")

        # 读取时间数据作为第一列 - 使用与数据读取相同的行范围
        time_data = []
        try:
            # 从result_dict中获取excel_range，如果没有则使用默认值
            if excel_range is None:
                # 尝试从结果字典中获取范围信息
                if 'excel_range' in result_dict:
                    excel_range = result_dict['excel_range']
                else:
                    # 使用默认范围
                    excel_range = (2, 20, 3, 5)
                    print(f"警告: 未提供excel_range，使用默认范围: {excel_range}")

            # 使用与数据读取相同的行范围
            start_row, end_row, start_col, end_col = excel_range
            print(f"使用与数据读取相同的行范围: 行{start_row}-{end_row}")

            time_data = read_time(
                file_path=file_path,
                time_col=condition_col if condition_col else 1,  # 默认为第1列
                start_row=start_row,  # 使用数据读取的起始行
                end_row=end_row  # 使用数据读取的结束行
            )
            print(f"成功读取时间数据: 共{len(time_data)}个时间点 (行{start_row}-{end_row})")
        except Exception as e:
            print(f"读取时间数据时出错: {e}")
            # 如果读取失败，使用空列表
            time_data = []

        # 获取所需数据
        sum_result = result_dict.get('sum_result', [])
        radial_data = result_dict.get('radial_data', [])
        axial_mianya = result_dict.get('axial_mianya', [])
        radial_mianya = result_dict.get('radial_mianya', [])

        # 获取径向1合力和径向2合力（sum_result索引1和2的部分）
        radial1_sum = []
        radial2_sum = []

        if sum_result and len(sum_result) >= 3:
            # 径向1合力：sum_result索引1的部分
            radial1_sum = sum_result[1] if len(sum_result) > 1 else []
            # 径向2合力：sum_result索引2的部分
            radial2_sum = sum_result[2] if len(sum_result) > 2 else []

            print(f"径向1合力数据: {radial1_sum}")
            print(f"径向2合力数据: {radial2_sum}")

        # 获取轴向合力（sum_result索引0的部分）
        axial_sum = []
        if sum_result and len(sum_result) > 0:
            axial_sum = sum_result[0]
            print(f"轴向合力数据: {axial_sum}")

        # 确定行数 - 使用所有数组的最大长度
        max_length = max(
            len(radial1_sum) if radial1_sum else 0,
            len(radial2_sum) if radial2_sum else 0,
            len(axial_sum) if axial_sum else 0,
            len(radial_data) if radial_data else 0,
            len(axial_mianya) if axial_mianya else 0,
            len(radial_mianya) if radial_mianya else 0,
            len(time_data) if time_data else 0
        )

        # 如果时间数据长度不够，用None填充
        if time_data and len(time_data) < max_length:
            time_data.extend([None] * (max_length - len(time_data)))
        elif not time_data:
            time_data = [None] * max_length

        print(f"最终确定的数据行数: {max_length}")

        # 创建新的工作簿
        wb = Workbook()
        # 使用默认工作表
        ws = wb.active
        ws.title = "结果汇总"
        print("创建工作表: 结果汇总")

        # 设置标题行 - 修改后的列
        headers = ['时间', '径向1合力', '径向2合力', '轴向合力', '径向合力', '轴向面压计算结果',
                   '径向面压计算结果']
        for col_idx, header in enumerate(headers, 1):
            ws.cell(row=1, column=col_idx, value=header)
            ws.cell(row=1, column=col_idx).font = Font(bold=True)

        # 填充数据
        for row_idx in range(max_length):
            # 第一列：时间数据
            if row_idx < len(time_data):
                ws.cell(row=row_idx + 2, column=1, value=time_data[row_idx])
            else:
                ws.cell(row=row_idx + 2, column=1, value=None)

            # 第二列：径向1合力
            if row_idx < len(radial1_sum):
                ws.cell(row=row_idx + 2, column=2, value=radial1_sum[row_idx])
            else:
                ws.cell(row=row_idx + 2, column=2, value=None)

            # 第三列：径向2合力
            if row_idx < len(radial2_sum):
                ws.cell(row=row_idx + 2, column=3, value=radial2_sum[row_idx])
            else:
                ws.cell(row=row_idx + 2, column=3, value=None)

            # 第四列：轴向合力
            if row_idx < len(axial_sum):
                ws.cell(row=row_idx + 2, column=4, value=axial_sum[row_idx])
            else:
                ws.cell(row=row_idx + 2, column=4, value=None)

            # 第五列：径向合力
            if radial_data and row_idx < len(radial_data):
                ws.cell(row=row_idx + 2, column=5, value=radial_data[row_idx])
            else:
                ws.cell(row=row_idx + 2, column=5, value=None)

            # 第六列：轴向面压计算结果
            if axial_mianya and row_idx < len(axial_mianya):
                ws.cell(row=row_idx + 2, column=6, value=axial_mianya[row_idx])
            else:
                ws.cell(row=row_idx + 2, column=6, value=None)

            # 第七列：径向面压计算结果
            if radial_mianya and row_idx < len(radial_mianya):
                ws.cell(row=row_idx + 2, column=7, value=radial_mianya[row_idx])
            else:
                ws.cell(row=row_idx + 2, column=7, value=None)

        # 设置列宽
        column_widths = [20, 15, 15, 15, 15, 18, 18]
        for i, width in enumerate(column_widths, 1):
            col_letter = chr(64 + i)
            ws.column_dimensions[col_letter].width = width

        # 为最大值添加黄色背景
        yellow_fill = PatternFill(start_color='FFFF00', end_color='FFFF00', fill_type='solid')

        # 修正：为除了时间列之外的每一列数据分别找到最大值并标黄
        print("\n开始标黄最大值...")

        # 遍历B到G列（索引2到7） - 除了时间列之外的所有列
        for col_idx in range(2, 8):  # B到G列
            max_value = None
            max_rows = []

            # 找到当前列的最大值
            for row_idx in range(2, max_length + 2):  # 从第2行开始（跳过标题行）
                cell_value = ws.cell(row=row_idx, column=col_idx).value
                if cell_value is not None:
                    try:
                        num_value = float(cell_value)
                        if max_value is None or num_value > max_value:
                            max_value = num_value
                            max_rows = [row_idx]
                        elif num_value == max_value:
                            max_rows.append(row_idx)
                    except (ValueError, TypeError):
                        continue

            # 标记所有等于当前列最大值的单元格
            if max_value is not None:
                for row_idx in max_rows:
                    ws.cell(row=row_idx, column=col_idx).fill = yellow_fill
                print(f"  第{col_idx}列({headers[col_idx - 1]})最大值: {max_value:.6f} (位置: 行{max_rows})")
            else:
                print(f"  第{col_idx}列({headers[col_idx - 1]})无有效数据")

        # 在右侧添加统计结果（与数据并排）
        stats_start_col = 9  # 从第9列开始（数据列到第7列，中间空一列）

        # 统计结果标题
        ws.cell(row=1, column=stats_start_col, value="统计结果")
        ws.cell(row=1, column=stats_start_col).font = Font(bold=True, size=14)

        # 统计结果表头
        stats_headers = ['统计项', '数值', '说明']
        for col_idx, header in enumerate(stats_headers, stats_start_col):
            ws.cell(row=2, column=col_idx, value=header)
            ws.cell(row=2, column=col_idx).font = Font(bold=True)

        # 添加统计信息
        row_idx = 3  # 从第3行开始

        # 收集所有数值用于找到最大值
        all_values = []

        # 添加轴向合力的统计（新增）
        if axial_sum:
            # 过滤掉None值
            axial_filtered = [x for x in axial_sum if x is not None]
            if axial_filtered:
                axial_max = max(axial_filtered)
                axial_min = min(axial_filtered)
                axial_avg = sum(axial_filtered) / len(axial_filtered)

                ws.cell(row=row_idx, column=stats_start_col, value='轴向合力最大值')
                ws.cell(row=row_idx, column=stats_start_col + 1, value=axial_max)
                ws.cell(row=row_idx, column=stats_start_col + 2, value='轴向合力结果中的最大值')
                all_values.append(axial_max)
                row_idx += 1

                ws.cell(row=row_idx, column=stats_start_col, value='轴向合力最小值')
                ws.cell(row=row_idx, column=stats_start_col + 1, value=axial_min)
                ws.cell(row=row_idx, column=stats_start_col + 2, value='轴向合力结果中的最小值')
                all_values.append(axial_min)
                row_idx += 1

                ws.cell(row=row_idx, column=stats_start_col, value='轴向合力平均值')
                ws.cell(row=row_idx, column=stats_start_col + 1, value=axial_avg)
                ws.cell(row=row_idx, column=stats_start_col + 2, value='轴向合力结果的平均值')
                row_idx += 1

                ws.cell(row=row_idx, column=stats_start_col, value='轴向合力数据量')
                ws.cell(row=row_idx, column=stats_start_col + 1, value=len(axial_filtered))
                ws.cell(row=row_idx, column=stats_start_col + 2, value='有效的轴向合力数据点数')
                row_idx += 1

        # 添加径向合力的统计（新增）
        if radial_data:
            radial_filtered = [x for x in radial_data if x is not None]
            if radial_filtered:
                radial_max = max(radial_filtered)
                radial_min = min(radial_filtered)
                radial_avg = sum(radial_filtered) / len(radial_filtered)

                ws.cell(row=row_idx, column=stats_start_col, value='径向合力最大值')
                ws.cell(row=row_idx, column=stats_start_col + 1, value=radial_max)
                ws.cell(row=row_idx, column=stats_start_col + 2, value='径向合力结果中的最大值')
                all_values.append(radial_max)
                row_idx += 1

                ws.cell(row=row_idx, column=stats_start_col, value='径向合力最小值')
                ws.cell(row=row_idx, column=stats_start_col + 1, value=radial_min)
                ws.cell(row=row_idx, column=stats_start_col + 2, value='径向合力结果中的最小值')
                all_values.append(radial_min)
                row_idx += 1

                ws.cell(row=row_idx, column=stats_start_col, value='径向合力平均值')
                ws.cell(row=row_idx, column=stats_start_col + 1, value=radial_avg)
                ws.cell(row=row_idx, column=stats_start_col + 2, value='径向合力结果的平均值')
                row_idx += 1

                ws.cell(row=row_idx, column=stats_start_col, value='径向合力数据量')
                ws.cell(row=row_idx, column=stats_start_col + 1, value=len(radial_filtered))
                ws.cell(row=row_idx, column=stats_start_col + 2, value='有效的径向合力数据点数')
                row_idx += 1

        # 添加径向1合力的统计
        if radial1_sum:
            # 过滤掉None值
            radial1_filtered = [x for x in radial1_sum if x is not None]
            if radial1_filtered:
                radial1_max = max(radial1_filtered)
                radial1_min = min(radial1_filtered)
                radial1_avg = sum(radial1_filtered) / len(radial1_filtered)

                ws.cell(row=row_idx, column=stats_start_col, value='径向1合力最大值')
                ws.cell(row=row_idx, column=stats_start_col + 1, value=radial1_max)
                ws.cell(row=row_idx, column=stats_start_col + 2, value='径向1合力结果中的最大值')
                all_values.append(radial1_max)
                row_idx += 1

                ws.cell(row=row_idx, column=stats_start_col, value='径向1合力最小值')
                ws.cell(row=row_idx, column=stats_start_col + 1, value=radial1_min)
                ws.cell(row=row_idx, column=stats_start_col + 2, value='径向1合力结果中的最小值')
                all_values.append(radial1_min)
                row_idx += 1

                ws.cell(row=row_idx, column=stats_start_col, value='径向1合力平均值')
                ws.cell(row=row_idx, column=stats_start_col + 1, value=radial1_avg)
                ws.cell(row=row_idx, column=stats_start_col + 2, value='径向1合力结果的平均值')
                row_idx += 1

                ws.cell(row=row_idx, column=stats_start_col, value='径向1合力数据量')
                ws.cell(row=row_idx, column=stats_start_col + 1, value=len(radial1_filtered))
                ws.cell(row=row_idx, column=stats_start_col + 2, value='有效的径向1合力数据点数')
                row_idx += 1

        # 添加径向2合力的统计
        if radial2_sum:
            radial2_filtered = [x for x in radial2_sum if x is not None]
            if radial2_filtered:
                radial2_max = max(radial2_filtered)
                radial2_min = min(radial2_filtered)
                radial2_avg = sum(radial2_filtered) / len(radial2_filtered)

                ws.cell(row=row_idx, column=stats_start_col, value='径向2合力最大值')
                ws.cell(row=row_idx, column=stats_start_col + 1, value=radial2_max)
                ws.cell(row=row_idx, column=stats_start_col + 2, value='径向2合力结果中的最大值')
                all_values.append(radial2_max)
                row_idx += 1

                ws.cell(row=row_idx, column=stats_start_col, value='径向2合力最小值')
                ws.cell(row=row_idx, column=stats_start_col + 1, value=radial2_min)
                ws.cell(row=row_idx, column=stats_start_col + 2, value='径向2合力结果中的最小值')
                all_values.append(radial2_min)
                row_idx += 1

                ws.cell(row=row_idx, column=stats_start_col, value='径向2合力平均值')
                ws.cell(row=row_idx, column=stats_start_col + 1, value=radial2_avg)
                ws.cell(row=row_idx, column=stats_start_col + 2, value='径向2合力结果的平均值')
                row_idx += 1

                ws.cell(row=row_idx, column=stats_start_col, value='径向2合力数据量')
                ws.cell(row=row_idx, column=stats_start_col + 1, value=len(radial2_filtered))
                ws.cell(row=row_idx, column=stats_start_col + 2, value='有效的径向2合力数据点数')
                row_idx += 1

        # 添加面压结果的统计
        if axial_mianya:
            axial_mianya_filtered = [x for x in axial_mianya if x is not None]
            if axial_mianya_filtered:
                axial_mianya_max = max(axial_mianya_filtered)
                axial_mianya_min = min(axial_mianya_filtered)
                axial_mianya_avg = sum(axial_mianya_filtered) / len(axial_mianya_filtered)

                ws.cell(row=row_idx, column=stats_start_col, value='轴向面压最大值')
                ws.cell(row=row_idx, column=stats_start_col + 1, value=axial_mianya_max)
                ws.cell(row=row_idx, column=stats_start_col + 2, value='轴向面压计算结果中的最大值')
                all_values.append(axial_mianya_max)
                row_idx += 1

                ws.cell(row=row_idx, column=stats_start_col, value='轴向面压最小值')
                ws.cell(row=row_idx, column=stats_start_col + 1, value=axial_mianya_min)
                ws.cell(row=row_idx, column=stats_start_col + 2, value='轴向面压计算结果中的最小值')
                all_values.append(axial_mianya_min)
                row_idx += 1

                ws.cell(row=row_idx, column=stats_start_col, value='轴向面压平均值')
                ws.cell(row=row_idx, column=stats_start_col + 1, value=axial_mianya_avg)
                ws.cell(row=row_idx, column=stats_start_col + 2, value='轴向面压结果的平均值')
                row_idx += 1

        if radial_mianya:
            radial_mianya_filtered = [x for x in radial_mianya if x is not None]
            if radial_mianya_filtered:
                radial_mianya_max = max(radial_mianya_filtered)
                radial_mianya_min = min(radial_mianya_filtered)
                radial_mianya_avg = sum(radial_mianya_filtered) / len(radial_mianya_filtered)

                ws.cell(row=row_idx, column=stats_start_col, value='径向面压最大值')
                ws.cell(row=row_idx, column=stats_start_col + 1, value=radial_mianya_max)
                ws.cell(row=row_idx, column=stats_start_col + 2, value='径向面压计算结果中的最大值')
                all_values.append(radial_mianya_max)
                row_idx += 1

                ws.cell(row=row_idx, column=stats_start_col, value='径向面压最小值')
                ws.cell(row=row_idx, column=stats_start_col + 1, value=radial_mianya_min)
                ws.cell(row=row_idx, column=stats_start_col + 2, value='径向面压计算结果中的最小值')
                all_values.append(radial_mianya_min)
                row_idx += 1

                ws.cell(row=row_idx, column=stats_start_col, value='径向面压平均值')
                ws.cell(row=row_idx, column=stats_start_col + 1, value=radial_mianya_avg)
                ws.cell(row=row_idx, column=stats_start_col + 2, value='径向面压结果的平均值')
                row_idx += 1

        # 为统计结果中的每个列的最大值统计项标黄
        print("\n开始标黄统计结果中的最大值...")

        # 创建一个字典来存储每个数据列的最大值统计项
        max_stat_rows = {}

        # 遍历统计结果行，找到每个列的最大值统计项
        for row in range(3, row_idx):
            stat_name = ws.cell(row=row, column=stats_start_col).value
            if stat_name and '最大值' in stat_name:
                # 提取列名，现在包括轴向合力和径向合力
                for col_name in ['轴向合力', '径向合力', '径向1合力', '径向2合力', '轴向面压', '径向面压']:
                    if col_name in stat_name:
                        if col_name not in max_stat_rows:
                            max_stat_rows[col_name] = []
                        max_stat_rows[col_name].append(row)
                        break

        # 为每个列的最大值统计项标黄
        for col_name, rows in max_stat_rows.items():
            for row in rows:
                ws.cell(row=row, column=stats_start_col + 1).fill = yellow_fill
            print(f"  {col_name}最大值统计项已标黄: 行{rows}")

        # 设置统计结果列的列宽
        stats_widths = [20, 15, 25]
        for i, width in enumerate(stats_widths, stats_start_col):
            col_letter = chr(64 + i)
            ws.column_dimensions[col_letter].width = width

        # 保存工作簿
        wb.save(output_file)

        print(f"结果已成功保存到: {output_file}")
        print(f"注意: 时间数据已使用与数据读取相同的行范围: 行{start_row}-{end_row}")
        print("注意: 时间数据已作为第一列")
        print("注意: 保留了修改后的列：时间、径向1合力、径向2合力、轴向合力、径向合力、轴向面压计算结果、径向面压计算结果")
        print("注意: 统计结果已放在右侧与数据并排排列")
        print("注意: 每一列的最大值已用黄色背景标记")
        print("注意: 已添加轴向合力和径向合力的最大值统计")
        return output_file

    except Exception as e:
        raise Exception(f"保存结果到Excel时出错: {str(e)}")


import os
from openpyxl import load_workbook
from openpyxl.styles import PatternFill, Font

def display_batch_results(results: dict, show_details: bool = False):
    """
    显示批量处理结果

    参数:
    ----------
    results : dict
        batch_process_files函数的返回结果
    show_details : bool
        是否显示详细结果
    """
    print("\n" + "=" * 100)
    print("批量处理结果汇总")
    print("=" * 100)

    for file_path, result in results.items():
        print(f"\n文件: {file_path}")
        print("-" * 80)

        if 'error' in result:
            print(f"  状态: 失败")
            print(f"  错误信息: {result['error']}")
        else:
            print(f"  状态: 成功")
            print(f"  输出文件: {result.get('saved_file', '未知')}")

            # 显示统计信息
            if 'statistics' in result:
                stats = result['statistics']
                print(f"  数据形状: {stats.get('excel_data_shape', '未知')}")
                print(f"  计算成功率: {stats.get('success_rate', 0):.1f}%")

                if 'axial_max' in stats:
                    print(f"  轴向最大值: {stats['axial_max']:.6f}")
                if 'radial_max' in stats:
                    print(f"  径向最大值: {stats['radial_max']:.6f}")

            if show_details:
                # 显示详细结果
                if 'axial_mianya' in result and 'radial_mianya' in result:
                    print(f"  轴向面压结果: {[f'{x:.6f}' for x in result['axial_mianya'][:3]]}...")
                    print(f"  径向面压结果: {[f'{x:.6f}' for x in result['radial_mianya'][:3]]}...")


def save_batch_results(results: dict, filename: str = "batch_results_summary.txt"):
    """
    保存批量处理结果到文件

    参数:
    ----------
    results : dict
        batch_process_files函数的返回结果
    filename : str
        输出文件名
    """
    with open(filename, 'w', encoding='utf-8') as f:
        f.write("批量处理结果汇总\n")
        f.write("=" * 50 + "\n\n")

        successful_count = 0
        failed_count = 0

        for file_path, result in results.items():
            f.write(f"文件: {file_path}\n")

            if 'error' in result:
                f.write(f"  状态: 失败\n")
                f.write(f"  错误信息: {result['error']}\n")
                failed_count += 1
            else:
                f.write(f"  状态: 成功\n")
                f.write(f"  输出文件: {result.get('saved_file', '未知')}\n")

                # 保存统计信息
                if 'statistics' in result:
                    stats = result['statistics']
                    f.write(f"  数据形状: {stats.get('excel_data_shape', '未知')}\n")
                    f.write(f"  计算成功率: {stats.get('success_rate', 0):.1f}%\n")

                    if 'axial_max' in stats:
                        f.write(f"  轴向最大值: {stats['axial_max']:.6f}\n")
                    if 'radial_max' in stats:
                        f.write(f"  径向最大值: {stats['radial_max']:.6f}\n")

                successful_count += 1

            f.write("\n" + "-" * 50 + "\n\n")

        # 汇总统计
        f.write("处理统计:\n")
        f.write(f"  总文件数: {len(results)}\n")
        f.write(f"  成功处理: {successful_count}\n")
        f.write(f"  处理失败: {failed_count}\n")
        f.write(f"  成功率: {successful_count / len(results) * 100:.1f}%\n")

def batch_process_files(files_config: dict, combined_output: str = None) -> dict:
    """
    批量处理多个文件的函数，依次对不同文件调用integrated_full_process函数
    可以将结果汇总到一个Excel文件中

    参数:
    ----------
    files_config : dict
        嵌套字典，键为文件路径，值为参数字典
    combined_output : str, optional
        汇总输出文件路径，如果提供则将所有结果汇总到一个Excel文件中

    返回:
    ----------
    dict
        包含每个文件处理结果的字典
    """
    try:
        results = {}

        print("=" * 80)
        print("开始批量处理文件")
        print("=" * 80)

        # 如果指定了汇总输出，检查输出目录是否存在
        if combined_output:
            output_dir = os.path.dirname(combined_output)
            if output_dir and not os.path.exists(output_dir):
                os.makedirs(output_dir)
                print(f"创建输出目录: {output_dir}")

        # 遍历所有文件配置
        for file_path, params in files_config.items():
            print(f"\n处理文件: {file_path}")
            print("-" * 60)

            # 检查文件是否存在
            if not os.path.exists(file_path):
                print(f"警告: 文件不存在，跳过处理: {file_path}")
                results[file_path] = {"error": f"文件不存在: {file_path}"}
                continue

            try:
                # 提取参数，使用get方法避免KeyError
                excel_range = params.get('excel_range')
                condition_col = params.get('condition_col')
                angle_data = params.get('angle_data')
                projection_areas = params.get('projection_areas')
                output_file = params.get('output_file')

                # 确保输出文件目录存在
                if output_file:
                    output_dir = os.path.dirname(output_file)
                    if output_dir and not os.path.exists(output_dir):
                        os.makedirs(output_dir)
                        print(f"创建输出目录: {output_dir}")

                # 打印参数信息
                print(f"参数配置:")
                print(f"  excel_range: {excel_range}")
                print(f"  condition_col: {condition_col}")
                print(f"  angle_data: {'已提供' if angle_data else '使用默认值'}")
                print(f"  projection_areas: {projection_areas}")
                print(f"  output_file: {output_file}")

                # 调用integrated_full_process函数
                result = integrated_full_process(
                    file_path=file_path,
                    excel_range=excel_range,
                    angle_data=angle_data,
                    projection_areas=projection_areas,
                    output_file=output_file,
                    condition_col=condition_col
                )

                results[file_path] = result
                print(f"✓ 文件处理完成: {file_path}")

            except Exception as e:
                error_msg = f"处理文件时出错: {str(e)}"
                print(f"✗ {error_msg}")
                results[file_path] = {"error": error_msg}

        # 如果指定了汇总输出，将结果汇总到一个Excel文件中
        if combined_output and any('error' not in result for result in results.values()):
            print(f"\n开始汇总结果到: {combined_output}")
            combine_results_to_excel(results, combined_output)

        print("\n" + "=" * 80)
        print("批量处理完成")
        print("=" * 80)

        # 打印处理统计
        total_files = len(files_config)
        successful_files = sum(1 for result in results.values() if 'error' not in result)
        failed_files = total_files - successful_files

        print(f"处理统计:")
        print(f"  总文件数: {total_files}")
        print(f"  成功处理: {successful_files}")
        print(f"  处理失败: {failed_files}")

        return results

    except Exception as e:
        raise Exception(f"批量处理过程中出错: {str(e)}")


def combine_results_to_excel(results: dict, output_file: str):
    """
    将多个处理结果汇总到一个Excel文件中，每个文件一个工作表

    参数:
    ----------
    results : dict
        批量处理结果字典
    output_file : str
        汇总输出文件路径
    """
    try:
        from openpyxl import Workbook

        print(f"开始汇总 {len(results)} 个文件的结果到: {output_file}")

        # 创建新的工作簿
        wb = Workbook()

        # 删除默认创建的工作表
        wb.remove(wb.active)

        # 为每个成功处理的文件创建一个工作表
        for file_path, result in results.items():
            if 'error' in result:
                print(f"跳过失败文件: {file_path}")
                continue

            # 获取保存的单个结果文件路径
            saved_file = result.get('saved_file')
            if not saved_file or not os.path.exists(saved_file):
                print(f"警告: 未找到结果文件: {saved_file}")
                continue

            try:
                # 创建工作表名称（使用文件名，确保不超过31个字符且不包含非法字符）
                sheet_name = create_valid_sheet_name(file_path)

                print(f"添加工作表: {sheet_name} (来自: {saved_file})")

                # 读取单个结果文件
                source_wb = load_workbook(saved_file)
                source_ws = source_wb.active

                # 复制工作表到汇总工作簿
                target_ws = wb.create_sheet(title=sheet_name)

                # 复制所有单元格
                for row in source_ws.iter_rows():
                    for cell in row:
                        target_cell = target_ws.cell(row=cell.row, column=cell.column, value=cell.value)

                        # 复制样式
                        if cell.font:
                            target_cell.font = Font(
                                name=cell.font.name,
                                size=cell.font.size,
                                bold=cell.font.bold,
                                italic=cell.font.italic,
                                color=cell.font.color
                            )

                        if cell.fill:
                            target_cell.fill = PatternFill(
                                start_color=cell.fill.start_color,
                                end_color=cell.fill.end_color,
                                fill_type=cell.fill.fill_type
                            )

                # 复制列宽
                for col_idx, column_dim in enumerate(source_ws.column_dimensions.values(), 1):
                    if column_dim.width:
                        target_ws.column_dimensions[get_column_letter(col_idx)].width = column_dim.width

                source_wb.close()

            except Exception as e:
                print(f"复制工作表时出错 {file_path}: {str(e)}")
                continue

        # 如果没有任何工作表，创建一个空的工作表
        if len(wb.sheetnames) == 0:
            wb.create_sheet("汇总结果")

        # 保存汇总工作簿
        wb.save(output_file)
        print(f"汇总结果已保存到: {output_file}")

    except Exception as e:
        raise Exception(f"汇总结果到Excel时出错: {str(e)}")


def create_valid_sheet_name(file_path: str, max_length: int = 31) -> str:
    """
    根据文件路径创建有效的工作表名称

    参数:
    ----------
    file_path : str
        文件路径
    max_length : int
        工作表名称最大长度

    返回:
    ----------
    str
        有效的工作表名称
    """
    # 获取文件名（不含扩展名）
    file_name = os.path.splitext(os.path.basename(file_path))[0]

    # 替换非法字符
    invalid_chars = ['\\', '/', '*', '?', ':', '[', ']']
    for char in invalid_chars:
        file_name = file_name.replace(char, '_')

    # 截断到最大长度
    if len(file_name) > max_length:
        file_name = file_name[:max_length - 3] + "..."

    # 确保名称不以数字开头且不为空
    if file_name and file_name[0].isdigit():
        file_name = "文件_" + file_name

    if not file_name:
        file_name = "未命名文件"

    return file_name


def get_column_letter(col_idx: int) -> str:
    """
    将列索引转换为列字母（A, B, C, ...）

    参数:
    ----------
    col_idx : int
        列索引（从1开始）

    返回:
    ----------
    str
        列字母
    """
    letters = ''
    while col_idx > 0:
        col_idx, remainder = divmod(col_idx - 1, 26)
        letters = chr(65 + remainder) + letters
    return letters


def create_simple_config(file_paths: list, base_output_dir: str = None) -> dict:
    """
    创建简单的配置文件，使用相同的参数处理多个文件

    参数:
    ----------
    file_paths : list
        文件路径列表
    base_output_dir : str, optional
        基础输出目录

    返回:
    ----------
    dict
        配置文件
    """
    config = {}

    for file_path in file_paths:
        if base_output_dir:
            # 基于输入文件名生成输出文件名
            base_name = os.path.splitext(os.path.basename(file_path))[0]
            output_file = os.path.join(base_output_dir, f"{base_name}_结果.xlsx")
        else:
            # 使用与输入文件相同的目录
            base_name = os.path.splitext(file_path)[0]
            output_file = f"{base_name}_结果.xlsx"

        config[file_path] = {
            'excel_range': (9, 10248, 3, 5),  # 默认范围，可根据需要修改
            'condition_col': 2,  # 默认时间列
            'angle_data': [[68.175, 79.013, 24.694],
                           [111.825, 100.987, 155.306],
                           [62.991, 152.997, 89.939]],
            'projection_areas': (100.0, 150.0, 200.0),
            'output_file': output_file
        }

    return config


# 使用示例
if __name__ == "__main__":
    try:
        # 1. 直接使用详细配置（不要用create_simple_config覆盖）
        files_config = {
            # 第一个文件
            r"E:\项目二22222222222222222\代码\项目三\RSP\QBED_S0_JXPG_Road_1_1_R_droplink_out.csv": {
                'excel_range': (9, 10248, 3, 5),
                'condition_col': 2,
                'angle_data': [[68.175, 79.013, 24.694],
                               [111.825, 100.987, 155.306],
                               [62.991, 152.997, 89.939]],
                'projection_areas': (100.0, 150.0, 200.0),
                'output_file': r"E:\项目二22222222222222222\代码\项目三\RSP\结果1.xlsx"
            },

            # 第二个文件 - 使用不同的参数
            r"E:\项目二22222222222222222\代码\项目三\RSP\QBED_S0_JXPG_Road_1_2_R_droplink_out.csv": {
                'excel_range': (9, 5000, 3, 5),  # 不同的数据范围
                'condition_col': 2,  # 不同的时间列
                'angle_data': [[35.937, 65.656, 114.694],  # 不同的角度数据
                               [111.825, 100.987, 155.306],
                               [111.825, 100.987, 155.306]],
                'projection_areas': (120.0, 180.0, 220.0),  # 不同的投影面
                'output_file': r"E:\项目二22222222222222222\代码\项目三\RSP\结果2.xlsx"
            }
        }

        # 2. 创建输出目录
        output_dir = r"E:\项目二22222222222222222\代码\项目三\RSP\批量结果"
        if not os.path.exists(output_dir):
            os.makedirs(output_dir)

        # 3. 创建汇总输出文件路径
        combined_output = os.path.join(output_dir, "所有结果汇总.xlsx")

        # 4. 直接执行批量处理（不要重新创建files_config）
        results = batch_process_files(files_config, combined_output)

        # 5. 显示结果
        display_batch_results(results, show_details=True)

        # 6. 保存结果汇总文本文件
        save_batch_results(results, os.path.join(output_dir, "处理汇总.txt"))

        print("批量处理完成！")

    except Exception as e:
        print(f"批量处理出错: {e}")









