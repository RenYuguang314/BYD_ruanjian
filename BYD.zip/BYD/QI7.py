"""
统一管理系统UI - 集成五个功能模块
通过导入方式管理各个功能模块，提供统一入口界面
"""

import os
from tkinter import ttk
import threading
import importlib.util
import tkinter as tk
from tkinter import simpledialog, messagebox
import utils
import sys

# ======== 直接导入子模块（关键修改点） ========

import FUI2
import UI2
import UIRSPDAC333
import FUIH
import UIH

def resource_path(relative_path):
    """获取打包后资源路径"""
    if hasattr(sys, '_MEIPASS'):
        return os.path.join(sys._MEIPASS, relative_path)
    return os.path.join(os.path.abspath("."), relative_path)

class UnifiedManagerUI:
    def __init__(self, root):

        self.root = root

        # 先进行验证
        if not self.verify_license():
            return

        self.root.title("载荷处理与面压计算")
        self.root.geometry("600x450")

        # 设置你自己的图片作为程序图标
        # self.set_custom_icon("7.ico")  # 替换为你的图片路径
        self.set_custom_icon(resource_path("7.ico"))

        # ======== 修改模块管理方式（关键） ========

        self.modules_info = {
            "整车转局部(BYD)": {
                "module": FUI2,
                "description": "整车转局部(BYD)"
            },
            "面压计算(BYD)": {
                "module": UI2,
                "description": "面压计算(BYD)"
            },
            "耐久载荷面压计算": {
                "module": UIRSPDAC333,
                "description": "耐久载荷面压计算"
            },
            "整车转局部(上汽)": {
                "module": FUIH,
                "description": "整车转局部(上汽)"
            },
            "面压计算(上汽)": {
                "module": UIH,
                "description": "面压计算(上汽)"
            },
        }

        self.current_process = None

        self.create_widgets()

    # ================= 图标逻辑（完全不动） =================

    def set_custom_icon(self, image_path):
        """设置自定义图片作为程序图标"""
        try:
            # 检查图片文件是否存在
            if not os.path.exists(image_path):
                print(f"警告: 图片文件不存在: {image_path}")
                return

            # 使用PIL库处理图片（支持多种格式）
            from PIL import Image, ImageTk

            # 打开并处理图片
            image = Image.open(image_path)

            # 调整图片大小
            icon_size = (32, 32)
            image = image.resize(icon_size, Image.Resampling.LANCZOS)

            # 转换为Tkinter可用的格式
            icon = ImageTk.PhotoImage(image)

            # 设置窗口图标
            self.root.iconphoto(True, icon)

            # 保存引用，防止被垃圾回收
            self.app_icon = icon

            print(f"成功设置自定义图标: {image_path}")

        except ImportError:
            # 如果PIL未安装，直接使用ICO文件
            print("PIL库未安装，尝试使用ICO文件")
            try:
                # 直接尝试设置ICO图标，不调用try_ico_icon方法
                if os.path.exists("7.ico"):
                    self.root.iconbitmap("7.ico")
                    print("使用ICO图标: 7.ico")
                elif os.path.exists("app_icon.ico"):
                    self.root.iconbitmap("app_icon.ico")
                    print("使用ICO图标: app_icon.ico")
            except Exception as e:
                print(f"设置ICO图标失败: {e}")
        except Exception as e:
            print(f"设置自定义图标失败: {e}")

    def try_ico_icon(self):
        try:
            ico_paths = ["app_icon.ico", "icon.ico", "logo.ico"]
            for ico_path in ico_paths:
                if os.path.exists(ico_path):
                    self.root.iconbitmap(ico_path)
                    print(f"使用ICO图标: {ico_path}")
                    return
        except Exception as e:
            print(f"设置ICO图标失败: {e}")

    # ================= 授权逻辑（不动） =================

    def verify_license(self):

        self.set_custom_icon("7.ico")  # 一定要先设图标！！！

        self.root.withdraw()

        rule_config = utils.load_rule_config()
        local_serial = utils.get_device_fingerprint()

        if not local_serial:
            messagebox.showerror(
                "错误",
                "无法读取序列号！",
                parent=self.root
            )
            self.root.quit()
            return False

        input_key = simpledialog.askstring(
            "密钥验证",
            "请输入设备密钥：",
            show="*",
            parent=self.root
        )

        if not input_key:
            messagebox.showwarning(
                "提示",
                "未输入密钥，程序退出！",
                parent=self.root
            )
            self.root.quit()
            return False

        correct_key = utils.encrypt_serial(local_serial, rule_config)

        if input_key == correct_key:
            self.root.deiconify()
            messagebox.showinfo(
                "成功",
                "密钥验证通过！",
                parent=self.root
            )
            return True

        else:
            messagebox.showerror(
                "错误",
                "密钥错误！程序退出。",
                parent=self.root
            )
            self.root.quit()
            return False

    # ================= UI部分（不动） =================

    def create_widgets(self):

        main_frame = ttk.Frame(self.root, padding=10)
        main_frame.pack(fill=tk.BOTH, expand=True)

        title_frame = ttk.Frame(main_frame)
        title_frame.pack(fill=tk.X, pady=(0, 10))

        ttk.Label(title_frame, text="载荷处理与面压计算",
                  font=("Arial", 14, "bold")).pack(side=tk.LEFT)

        ttk.Label(title_frame, text="选择功能模块",
                  font=("Arial", 9)).pack(side=tk.RIGHT)

        module_frame = ttk.LabelFrame(main_frame, text="功能模块", padding=10)
        module_frame.pack(fill=tk.BOTH, expand=True, pady=5)

        self.create_compact_module_grid(module_frame)

        status_frame = ttk.Frame(main_frame)
        status_frame.pack(fill=tk.X, pady=5)

        self.status_label = ttk.Label(status_frame, text="就绪",
                                      relief="sunken", padding=5)
        self.status_label.pack(fill=tk.X)

        button_frame = ttk.Frame(main_frame)
        button_frame.pack(fill=tk.X, pady=5)

        ttk.Button(button_frame, text="刷新模块",
                   command=self.refresh_modules).pack(side=tk.LEFT, padx=5)

        ttk.Button(button_frame, text="查看日志",
                   command=self.show_log).pack(side=tk.LEFT, padx=5)

        ttk.Button(button_frame, text="退出系统",
                   command=self.quit_system).pack(side=tk.RIGHT, padx=5)

    def create_compact_module_grid(self, parent):

        left_frame = ttk.Frame(parent)
        left_frame.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=(0, 5))

        right_frame = ttk.Frame(parent)
        right_frame.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True, padx=(5, 0))

        modules = list(self.modules_info.items())
        mid_point = (len(modules) + 1) // 2

        for i, (module_name, info) in enumerate(modules[:mid_point]):
            self.create_module_button(left_frame, module_name, info, i)

        for i, (module_name, info) in enumerate(modules[mid_point:], mid_point):
            self.create_module_button(right_frame, module_name, info, i - mid_point)

    def create_module_button(self, parent, module_name, info, index):

        module_frame = ttk.Frame(parent, relief="solid", borderwidth=1, padding=8)
        module_frame.pack(fill=tk.X, pady=3)

        name_label = ttk.Label(module_frame, text=module_name,
                               font=("Arial", 10, "bold"))
        name_label.pack(anchor=tk.W)

        desc_label = ttk.Label(module_frame, text=info["description"],
                               font=("Arial", 8), wraplength=250)
        desc_label.pack(anchor=tk.W, pady=(2, 5))

        run_btn = ttk.Button(
            module_frame,
            text="运行",
            command=lambda name=module_name: self.run_module(name)
        )
        run_btn.pack(fill=tk.X)

    # ================= 关键修改：内存运行模块 =================

    def run_module(self, module_name):

        if module_name not in self.modules_info:
            messagebox.showerror("错误", f"未找到模块: {module_name}")
            return

        module = self.modules_info[module_name]["module"]

        self.status_label.config(text=f"正在启动 {module_name}...")

        self._run_module_thread(module, module_name)

    def _run_module_thread(self, module, module_name):
        try:
            import importlib
            module = importlib.reload(module)

            if hasattr(module, "main"):
                module.main()
            else:
                messagebox.showwarning(
                    "警告",
                    f"{module_name} 中未找到 main() 函数"
                )

            self.root.after(
                0,
                lambda: self.status_label.config(
                    text=f"{module_name} 已结束运行"
                )
            )

        except Exception as e:
            # 修复：避免lambda函数中的变量捕获问题
            error_msg = str(e)

            self.root.after(
                0,
                lambda msg=error_msg: messagebox.showerror(
                    "错误",
                    f"运行模块失败: {msg}"
                )
            )

            self.root.after(
                0,
                lambda: self.status_label.config(text="运行失败")
            )

    # ================= 其它功能（不动） =================

    def refresh_modules(self):
        self.status_label.config(text="正在刷新模块...")
        self.root.after(1000, lambda: self.status_label.config(text="模块刷新完成"))

    def show_log(self):

        log_window = tk.Toplevel(self.root)
        log_window.title("系统日志")
        log_window.geometry("500x300")

        log_frame = ttk.Frame(log_window, padding=10)
        log_frame.pack(fill=tk.BOTH, expand=True)

        ttk.Label(log_frame, text="系统运行日志",
                  font=("Arial", 10, "bold")).pack(anchor=tk.W, pady=(0, 5))

        text_frame = ttk.Frame(log_frame)
        text_frame.pack(fill=tk.BOTH, expand=True)

        log_text = tk.Text(text_frame, wrap=tk.WORD, font=("Arial", 9))
        scrollbar = ttk.Scrollbar(text_frame, orient="vertical", command=log_text.yview)
        log_text.configure(yscrollcommand=scrollbar.set)

        log_text.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)

        log_content = """系统启动完成
模块管理器已初始化
所有功能模块已加载
就绪等待用户操作
"""

        log_text.insert(tk.END, log_content)
        log_text.config(state=tk.DISABLED)

        ttk.Button(log_frame, text="关闭",
                   command=log_window.destroy).pack(pady=5)

    def quit_system(self):

        if messagebox.askokcancel("确认退出", "确定要退出系统吗？"):
            self.root.quit()


def main():
    root = tk.Tk()
    app = UnifiedManagerUI(root)
    root.mainloop()


if __name__ == "__main__":
    main()
