import tkinter as tk
from tkinter import simpledialog, messagebox
import utils
import sys
from tkinter.messagebox import showinfo, showerror, askyesno, showwarning

def main_function():
    """你的EXE核心功能（示例：弹窗提示）"""
    root = tk.Tk()
    root.withdraw()  # 隐藏主窗口
    messagebox.showinfo("成功", "密钥验证通过！\n现在执行EXE核心功能...")
    # -------------- 替换为你的核心代码 --------------
    # 例如：调用你的业务函数、启动其他程序等
    # -----------------------------------------------


if __name__ == "__main__":
    # 1. 加载加密规则（需与密码计算器使用的规则一致）
    rule_config = utils.load_rule_config()

    # 2. 读取本机主板序列号
    local_serial = utils.get_motherboard_serial()
    if not local_serial:
        messagebox.showerror("错误", "无法读取主板序列号！")
        sys.exit(1)

    # 3. 弹窗输入密钥
    root = tk.Tk()
    root.withdraw()  # 隐藏tkinter主窗口
    input_key = simpledialog.askstring("密钥验证", "请输入设备密钥：", show="*")

    if not input_key:
        messagebox.showwarning("提示", "未输入密钥，程序退出！")
        sys.exit(0)

    # 4. 验证密钥
    correct_key = utils.encrypt_serial(local_serial, rule_config)
    if input_key == correct_key:
        main_function()
    else:
        messagebox.showerror("错误", "密钥错误！程序退出。")
        sys.exit(1)



# 在现有导入后面添加
import utils

#步骤2：在UI类的 __init__方法开头添加验证逻辑
class ExcelDataProcessorUI:
    def __init__(self, root):
        self.root = root  # 先保存root引用

        # 先进行验证
        if not self.verify_license():
            # 如果验证失败，直接退出
            return

        # 验证通过后继续初始化UI
        self.root.title("Excel数据处理系统 - 优化版")
        self.root.geometry("1000x800")

        # 存储变量（原有的变量初始化代码）
        self.file_path = tk.StringVar()
        self.start_row = tk.StringVar(value="2")
        self.end_row = tk.StringVar(value="100")
        self.start_col = tk.StringVar(value="1")
        self.end_col = tk.StringVar(value="10")
        self.condition_row = tk.StringVar(value="1")  # 工况名称行

        # 角度数据变量 - 9个角度
        self.angle_vars = []
        for i in range(9):
            self.angle_vars.append(tk.StringVar(value="0.0"))

        # 投影面值变量
        self.proj_a = tk.StringVar(value="100.0")
        self.proj_b = tk.StringVar(value="150.0")
        self.proj_c = tk.StringVar(value="200.0")

        # 输出文件路径
        self.output_file = tk.StringVar()

        # 处理状态
        self.processing = False
        self.current_result = None

        # 创建UI组件
        self.create_widgets()  # 这行放在验证通过后，其他初始化代码之后

        # 初始日志
        self.log("系统启动完成")

#步骤3：在UI类中添加验证方法
def verify_license(self):
    """验证许可证"""
    # 隐藏主窗口，只显示验证对话框
    self.root.withdraw()

    # 1. 加载加密规则
    rule_config = utils.load_rule_config()

    # # 2. 读取本机主板序列号
    # local_serial = utils.get_motherboard_serial()
    # # 2. 读取本机CPU序列号
    # local_serial = utils.get_cpu_serial()
    # 2. 读取本机CPU,硬盘，主板序列号
    local_serial = utils.get_device_fingerprint()


    if not local_serial:
        messagebox.showerror("错误", "无法读取序列号！")
        self.root.quit()
        return False

    # 3. 弹窗输入密钥
    input_key = simpledialog.askstring("密钥验证", "请输入设备密钥：", show="*")

    if not input_key:
        messagebox.showwarning("提示", "未输入密钥，程序退出！")
        self.root.quit()
        return False

    # 4. 验证密钥
    correct_key = utils.encrypt_serial(local_serial, rule_config)
    if input_key == correct_key:
        # 验证通过，显示主窗口
        self.root.deiconify()
        messagebox.showinfo("成功", "密钥验证通过！")
        return True
    else:
        messagebox.showerror("错误", "密钥错误！程序退出。")
        self.root.quit()
        return False

if __name__ == "__main__":
    # 删除原有的验证代码，直接调用main()
    main()