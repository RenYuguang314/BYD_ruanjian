"""
统一管理系统UI - 集成五个功能模块
通过导入方式管理各个功能模块，提供统一入口界面
"""

import os
from tkinter import ttk
import threading
import subprocess
import importlib.util
import tkinter as tk
from tkinter import simpledialog, messagebox
import utils
import sys



class UnifiedManagerUI:
    def __init__(self, root):

        self.root = root  # 先保存root引用

        # 先进行验证
        if not self.verify_license():
            # 如果验证失败，直接退出
            return

        self.root = root
        self.root.title("载荷处理与面压计算")
        self.root.geometry("600x450")  # 缩小页面尺寸

        # 设置你自己的图片作为程序图标
        self.set_custom_icon("7.ico")  # 替换为你的图片路径

        self.modules_info = {
            "整车转局部(BYD)": {
                "file": "FUI2.py",
                "description": "整车转局部(BYD)"
            },
            "面压计算(BYD)": {
                "file": "UI2.py",
                "description": "面压计算(BYD)"
            },
            "耐久载荷面压计算": {
                "file": "UIRSPDAC333.py",
                "description": "耐久载荷面压计算"
            },
            "整车转局部(上汽)": {
                "file": "FUIH.py",
                "description": "整车转局部(上汽)"
            },
            "面压计算(上汽)": {
                "file": "UIH222222.py",
                "description": "面压计算(上汽)"
            },
        }

        # 当前运行的进程
        self.current_process = None

        self.create_widgets()

    def set_custom_icon(self, image_path):
        """设置自定义图片作为程序图标"""
        try:
            # 检查图片文件是否存在
            if not os.path.exists(image_path):
                print(f"警告: 图片文件不存在: {image_path}")
                return

            # 使用PIL库处理图片（支持多种格式）
            from PIL import Image, ImageTk

            # 打开并处理图片
            image = Image.open(image_path)

            # 调整图片大小
            icon_size = (32, 32)
            image = image.resize(icon_size, Image.Resampling.LANCZOS)

            # 转换为Tkinter可用的格式
            icon = ImageTk.PhotoImage(image)

            # 设置窗口图标
            self.root.iconphoto(True, icon)

            # 保存引用，防止被垃圾回收
            self.app_icon = icon

            print(f"成功设置自定义图标: {image_path}")

        except ImportError:
            # 如果PIL未安装，直接使用ICO文件
            print("PIL库未安装，尝试使用ICO文件")
            try:
                # 直接尝试设置ICO图标，不调用try_ico_icon方法
                if os.path.exists("7.ico"):
                    self.root.iconbitmap("7.ico")
                    print("使用ICO图标: 7.ico")
                elif os.path.exists("app_icon.ico"):
                    self.root.iconbitmap("app_icon.ico")
                    print("使用ICO图标: app_icon.ico")
            except Exception as e:
                print(f"设置ICO图标失败: {e}")
        except Exception as e:
            print(f"设置自定义图标失败: {e}")

    def try_ico_icon(self):
        """尝试使用ICO格式图标"""
        try:
            # 如果有ICO文件，使用它
            ico_paths = ["app_icon.ico", "icon.ico", "logo.ico"]
            for ico_path in ico_paths:
                if os.path.exists(ico_path):
                    self.root.iconbitmap(ico_path)
                    print(f"使用ICO图标: {ico_path}")
                    return
        except Exception as e:
            print(f"设置ICO图标失败: {e}")


    def verify_license(self):
        """验证许可证"""
        # 隐藏主窗口，只显示验证对话框
        self.root.withdraw()

        # 设置你自己的图片作为程序图标
        self.set_custom_icon("7.ico")  # 替换为你的图片路径

        # 1. 加载加密规则
        rule_config = utils.load_rule_config()

        # # 2. 读取本机主板序列号
        # local_serial = utils.get_motherboard_serial()
        # # 2. 读取本机CPU序列号
        # local_serial = utils.get_cpu_serial()
        # 2. 读取本机CPU,硬盘，主板序列号
        local_serial = utils.get_device_fingerprint()

        if not local_serial:
            messagebox.showerror("错误", "无法读取序列号！")
            self.root.quit()
            return False

        # 3. 弹窗输入密钥
        input_key = simpledialog.askstring("密钥验证", "请输入设备密钥：", show="*")

        if not input_key:
            messagebox.showwarning("提示", "未输入密钥，程序退出！")
            self.root.quit()
            return False

        # 4. 验证密钥
        correct_key = utils.encrypt_serial(local_serial, rule_config)
        if input_key == correct_key:
            # 验证通过，显示主窗口
            self.root.deiconify()
            messagebox.showinfo("成功", "密钥验证通过！")
            return True
        else:
            messagebox.showerror("错误", "密钥错误！程序退出。")
            self.root.quit()
            return False



    def create_widgets(self):
        """创建界面组件"""
        # 主框架
        main_frame = ttk.Frame(self.root, padding=10)
        main_frame.pack(fill=tk.BOTH, expand=True)

        # 标题
        title_frame = ttk.Frame(main_frame)
        title_frame.pack(fill=tk.X, pady=(0, 10))

        ttk.Label(title_frame, text="载荷处理与面压计算",
                  font=("Arial", 14, "bold")).pack(side=tk.LEFT)

        ttk.Label(title_frame, text="选择功能模块",
                  font=("Arial", 9)).pack(side=tk.RIGHT)

        # 模块选择区域
        module_frame = ttk.LabelFrame(main_frame, text="功能模块", padding=10)
        module_frame.pack(fill=tk.BOTH, expand=True, pady=5)

        # 创建紧凑的模块按钮布局
        self.create_compact_module_grid(module_frame)

        # 状态区域
        status_frame = ttk.Frame(main_frame)
        status_frame.pack(fill=tk.X, pady=5)

        self.status_label = ttk.Label(status_frame, text="就绪",
                                      relief="sunken", padding=5)
        self.status_label.pack(fill=tk.X)

        # 控制按钮
        button_frame = ttk.Frame(main_frame)
        button_frame.pack(fill=tk.X, pady=5)

        ttk.Button(button_frame, text="刷新模块",
                   command=self.refresh_modules).pack(side=tk.LEFT, padx=5)

        ttk.Button(button_frame, text="查看日志",
                   command=self.show_log).pack(side=tk.LEFT, padx=5)

        ttk.Button(button_frame, text="退出系统",
                   command=self.quit_system).pack(side=tk.RIGHT, padx=5)

    def create_compact_module_grid(self, parent):
        """创建紧凑的模块按钮网格"""
        # 创建两列布局
        left_frame = ttk.Frame(parent)
        left_frame.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=(0, 5))

        right_frame = ttk.Frame(parent)
        right_frame.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True, padx=(5, 0))

        # 将模块分配到两列
        modules = list(self.modules_info.items())
        mid_point = (len(modules) + 1) // 2  # 计算中间点

        # 左列模块
        for i, (module_name, info) in enumerate(modules[:mid_point]):
            self.create_module_button(left_frame, module_name, info, i)

        # 右列模块
        for i, (module_name, info) in enumerate(modules[mid_point:], mid_point):
            self.create_module_button(right_frame, module_name, info, i - mid_point)

    def create_module_button(self, parent, module_name, info, index):
        """创建单个模块按钮"""
        # 模块框架
        module_frame = ttk.Frame(parent, relief="solid", borderwidth=1, padding=8)
        module_frame.pack(fill=tk.X, pady=3)

        # 模块名称
        name_label = ttk.Label(module_frame, text=module_name,
                              font=("Arial", 10, "bold"))
        name_label.pack(anchor=tk.W)

        # 模块描述
        desc_label = ttk.Label(module_frame, text=info["description"],
                              font=("Arial", 8), wraplength=250)
        desc_label.pack(anchor=tk.W, pady=(2, 5))

        # 运行按钮
        run_btn = ttk.Button(module_frame, text="运行",
                            command=lambda name=module_name: self.run_module(name))
        run_btn.pack(fill=tk.X)

    def run_module(self, module_name):
        """运行指定模块"""
        if module_name not in self.modules_info:
            messagebox.showerror("错误", f"未找到模块: {module_name}")
            return

        module_info = self.modules_info[module_name]
        file_path = module_info["file"]

        if not os.path.exists(file_path):
            messagebox.showerror("错误", f"模块文件不存在: {file_path}")
            return

        self.status_label.config(text=f"正在启动 {module_name}...")

        # 在新线程中运行模块
        thread = threading.Thread(target=self._run_module_thread,
                                  args=(module_name, file_path))
        thread.daemon = True
        thread.start()

    def _run_module_thread(self, module_name, file_path):
        """在新线程中运行模块"""
        try:
            # 使用subprocess运行Python文件
            self.current_process = subprocess.Popen([sys.executable, file_path])

            # 等待进程结束
            self.current_process.wait()

            # 更新状态
            self.root.after(0, lambda: self.status_label.config(
                text=f"{module_name} 已结束运行"))

        except Exception as e:
            error_msg = f"运行模块失败: {str(e)}"
            self.root.after(0, lambda: messagebox.showerror("错误", error_msg))
            self.root.after(0, lambda: self.status_label.config(text="运行失败"))

    def run_module_direct(self, module_name):
        """直接导入并运行模块（替代方法）"""
        try:
            module_info = self.modules_info[module_name]
            file_path = module_info["file"]

            # 动态导入模块
            spec = importlib.util.spec_from_file_location(module_name, file_path)
            module = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(module)

            # 检查模块是否有main函数
            if hasattr(module, 'main'):
                # 在新线程中运行main函数
                thread = threading.Thread(target=module.main)
                thread.daemon = True
                thread.start()
                self.status_label.config(text=f"{module_name} 已启动")
            else:
                messagebox.showwarning("警告", f"模块 {module_name} 没有找到main函数")

        except Exception as e:
            messagebox.showerror("错误", f"导入模块失败: {str(e)}")

    def refresh_modules(self):
        """刷新模块列表"""
        self.status_label.config(text="正在刷新模块...")
        self.root.after(1000, lambda: self.status_label.config(text="模块刷新完成"))

    def show_log(self):
        """显示运行日志"""
        # 创建日志窗口
        log_window = tk.Toplevel(self.root)
        log_window.title("系统日志")
        log_window.geometry("500x300")

        log_frame = ttk.Frame(log_window, padding=10)
        log_frame.pack(fill=tk.BOTH, expand=True)

        # 日志标题
        ttk.Label(log_frame, text="系统运行日志",
                 font=("Arial", 10, "bold")).pack(anchor=tk.W, pady=(0, 5))

        # 日志内容区域
        text_frame = ttk.Frame(log_frame)
        text_frame.pack(fill=tk.BOTH, expand=True)

        log_text = tk.Text(text_frame, wrap=tk.WORD, font=("Arial", 9))
        scrollbar = ttk.Scrollbar(text_frame, orient="vertical", command=log_text.yview)
        log_text.configure(yscrollcommand=scrollbar.set)

        log_text.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)

        # 添加示例日志内容
        log_content = """系统启动完成
模块管理器已初始化
所有功能模块已加载
就绪等待用户操作
"""
        log_text.insert(tk.END, log_content)
        log_text.config(state=tk.DISABLED)  # 设置为只读

        # 关闭按钮
        ttk.Button(log_frame, text="关闭",
                  command=log_window.destroy).pack(pady=5)

    def quit_system(self):
        """退出系统"""
        if self.current_process and self.current_process.poll() is None:
            if messagebox.askyesno("确认退出", "有模块正在运行，确定要退出吗？"):
                self.current_process.terminate()
                self.root.quit()
        else:
            if messagebox.askokcancel("确认退出", "确定要退出系统吗？"):
                self.root.quit()


def main():
    """主函数"""
    root = tk.Tk()
    app = UnifiedManagerUI(root)
    root.mainloop()


if __name__ == "__main__":
    main()